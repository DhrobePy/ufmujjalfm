<?php
// MONSTROUSLY REFORGED: This Gatekeeper is now unstoppable.

// Use an output buffer to swallow any stray output (like warnings)
// that would prevent the header() redirect from working.
ob_start();

// The sacred rite of starting a session MUST be at the very top.
session_start();

require_once '../core/init.php';

// A monster prepares for both possibilities.
$response = ['success' => false, 'message' => 'An unknown error occurred.'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $db = Database::getInstance();
    $user_obj = new User($db);

    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');

    if (empty($username) || empty($password)) {
        $response['message'] = 'Username and password are required.';
    } else {
        $user = $user_obj->login($username, $password);

        if ($user) {
            // THE ANOINTING: Set the session with absolute authority.
            $_SESSION['user_id'] = $user->id;

            // Get the user's role using our helper function.
            $role_name = getUserRole($db, $user->id);
            $_SESSION['role'] = $role_name;

            $response['success'] = true;
            $response['message'] = 'Login successful! Redirecting...';

            // THE JUDGEMENT: A clear and decisive routing map.
            $destination = '../admin/index.php'; // A safe default
            switch (strtolower($role_name)) {
                case 'super admin':
                case 'admin':
                    $destination = '../admin/index.php';
                    break;
                case 'branch accountant':
                    $destination = '../admin/dashboard_branch_accountant.php';
                    break;
                case 'branch attendant':
                    $destination = '../admin/dashboard_branch_attendant.php';
                    break;
                case 'employee':
                    $destination = '../employee/index.php';
                    break;
                // Add other roles here as needed...
            }
            
            // THE FINAL COMMAND: Redirect and then cease all operations.
            header('Location: ' . $destination);
            exit(); // This is CRITICAL. It stops the script immediately.

        } else {
            $response['message'] = 'Invalid username or password.';
        }
    }
    // If we are here, it means the login failed.
    // Redirect back to login page with an error message.
    $_SESSION['login_error'] = $response['message'];
    header('Location: login.php');
    exit();
}

// If someone tries to access this page directly.
header('Location: login.php');
exit();

