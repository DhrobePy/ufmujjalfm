<?php
// new_ufmhrm/auth/login_handler.php

// This file now gets the $db variable from init.php
require_once '../core/init.php';

if (isset($_POST['login'])) {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    // Pass the globally available $db object to the User class
    $user = new User($db); 
    $login = $user->login($username, $password);

    if ($login) {
        // Success: Set the session and redirect to the admin dashboard
        $_SESSION['success_flash'] = 'Login successful!';
        header('Location: ../admin/index.php');
        exit();
    } else {
        // Failure: Set an error and redirect back to the login page
        $_SESSION['error_flash'] = 'Invalid credentials. Please try again.';
        header('Location: login.php');
        exit();
    }
} else {
    // Redirect if someone tries to access this page directly
    header('Location: login.php');
    exit();
}

// MONSTROUS REPLACEMENT: REPLACE THE ENTIRETY OF login_handler.php WITH THIS CODE

require_once '../core/init.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    if (empty($username) || empty($password)) {
        $_SESSION['error'] = 'Username and password are required.';
        header('Location: login.php');
        exit();
    }

    try {
        $db = Database::getInstance()->getConnection();
        $user_obj = new User($db);

        // Let's find the user by their username
        $user = $user_obj->findByUsername($username);

        // Verify the user exists and the password is correct
        if ($user && password_verify($password, $user['password'])) {
            // User is authenticated! Now, let's get their powers.
            
            // Store core user info in the session
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            
            // NEW MONSTROUS LOGIC: Get Role and Branch
            $_SESSION['role'] = getUserRole($db, $user['id']); // Using our new spell
            $_SESSION['branch_id'] = $user['branch_id']; // From the new DB column

            // The Grand Redirection!
            if (!empty($_SESSION['role'])) {
                switch ($_SESSION['role']) {
                    case 'Super Admin':
                    case 'Admin':
                    case 'HR Manager':
                    case 'Accountant':
                        header('Location: ../admin/index.php');
                        exit();
                        
                    case 'Branch Accountant':
                        header('Location: ../admin/dashboard_branch_accountant.php');
                        exit();

                    case 'Branch Attendant':
                        header('Location: ../admin/dashboard_branch_attendant.php');
                        exit();
                        
                    case 'Employee':
                        header('Location: ../employee/index.php');
                        exit();

                    default:
                        // If role is unknown, send them to a safe place
                        header('Location: ../employee/index.php');
                        exit();
                }
            } else {
                // If user has no role, a monstrous error has occurred.
                $_SESSION['error'] = 'User role not configured. Contact administrator.';
                header('Location: login.php');
                exit();
            }

        } else {
            // Wrong username or password
            $_SESSION['error'] = 'Invalid username or password.';
            header('Location: login.php');
            exit();
        }

    } catch (PDOException $e) {
        $_SESSION['error'] = 'A monstrous database error occurred: ' . $e->getMessage();
        header('Location: login.php');
        exit();
    }
} else {
    // If not a POST request, banish them back to the login page
    header('Location: login.php');
    exit();
}
