<?php
// MONSTROUSLY RECTIFIED: This is the definitive login page.
// The ghost 'is_admin_logged_in()' has been slain and replaced with an
// intelligent, role-aware redirect system.

// The session MUST be started to check login status.
session_start();

require_once '../core/init.php';

// --- THE INTELLIGENT REDIRECT ---
// First, use our universal spell to see if a user is already logged in.
if (is_logged_in()) {
    // If they are, find out their rank and send them to their rightful place.
    $db = Database::getInstance();
    $role = getUserRole($db, $_SESSION['user_id']);

    // The same decisive routing map from our Gatekeeper.
    $destination = '../admin/index.php'; // Default for high command
    switch (strtolower($role)) {
        case 'branch accountant':
            $destination = '../admin/dashboard_branch_accountant.php';
            break;
        case 'branch attendant':
            $destination = '../admin/dashboard_branch_attendant.php';
            break;
        case 'employee':
            $destination = '../employee/index.php';
            break;
    }
    
    // The final command. Redirect and cease all operations.
    header('Location: ' . $destination);
    exit();
}

// If we are here, the user is not logged in. We can display the login form.
$pageTitle = 'Login - Fajracct HRM';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* A touch of the monstrous "Fajracct style" */
        body {
            background-color: #111827; /* Dark background */
        }
        .login-card {
            background-color: #1F2937;
            border: 1px solid #374151;
        }
        .form-input {
            background-color: #374151;
            border-color: #4B5563;
            color: #D1D5DB;
        }
        .form-input:focus {
            --tw-ring-color: #4F46E5;
            border-color: #4F46E5;
        }
        .submit-btn {
            background: linear-gradient(to right, #4F46E5, #818CF8);
        }
    </style>
</head>
<body class="flex items-center justify-center min-h-screen">

    <div class="w-full max-w-md p-8 space-y-8 rounded-xl login-card shadow-2xl">
        <div class="text-center">
            <h1 class="text-3xl font-bold text-white">UFM HRM</h1>
            <p class="mt-2 text-gray-400">Welcome to the HRM</p>
        </div>

        <!-- Display Login Errors Here -->
        <?php if (isset($_SESSION['login_error'])): ?>
            <div class="bg-red-500/20 border border-red-500 text-red-300 px-4 py-3 rounded-lg text-center" role="alert">
                <p><?php echo $_SESSION['login_error']; ?></p>
            </div>
            <?php unset($_SESSION['login_error']); // Clear the error after displaying it ?>
        <?php endif; ?>

        <form class="space-y-6" action="login_handler.php" method="POST">
            <div>
                <label for="username" class="sr-only">Username</label>
                <input id="username" name="username" type="text" autocomplete="username" required
                       class="w-full px-4 py-3 rounded-lg form-input focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-800"
                       placeholder="Username">
            </div>

            <div>
                <label for="password" class="sr-only">Password</label>
                <input id="password" name="password" type="password" autocomplete="current-password" required
                       class="w-full px-4 py-3 rounded-lg form-input focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-800"
                       placeholder="Password">
            </div>
            
            <div>
                <button type="submit"
                        class="w-full flex justify-center py-3 px-4 border border-transparent rounded-lg shadow-sm text-sm font-medium text-white submit-btn hover:opacity-90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-opacity">
                    <i class="fas fa-sign-in-alt mr-2"></i>
                    Sign In
                </button>
            </div>
        </form>
         <p class="text-xs text-center text-gray-500">
            <a href="employee_login.php" class="font-medium text-indigo-400 hover:text-indigo-300">Login as Employee</a>
        </p>
    </div>

</body>
</html>
