<?php
// MONSTROUS REPLACEMENT: This is the new, correct way to banish a user's session.
// It is clean, direct, and free of ghosts.

// First, we MUST awaken the core systems to manage the session.
require_once '../core/init.php';

// The sacred rites of banishment:

// 1. Unset all session variables.
$_SESSION = array();

// 2. Destroy the session itself.
session_destroy();

// 3. Banish the user back to the login page.
header('Location: login.php');
exit(); // The final, crushing blow.
