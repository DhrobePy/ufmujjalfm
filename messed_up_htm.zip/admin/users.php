<?php
// MONSTROUSLY ARMORED: This version is fortified against `null` values,
// silencing all "Deprecated" warnings and making the UI robust.

ini_set('display_errors', 1);
error_reporting(E_ALL);

require_once '../core/init.php';

// Ensure user is logged in and is a superadmin or has permission to view users
if (!is_logged_in()) { // Assuming you have a generic is_logged_in() function
    header('Location: ../auth/login.php');
    exit();
}

// You might want a more granular permission check here in the future
// if (!has_permission('user:view')) {
//     die("You do not have permission to access this page.");
// }

$db = Database::getInstance();
$user_obj = new User($db);

$success_message = '';
$error_message = '';

// --- LOGIC: Handle ALL form submissions before any HTML is sent ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // --- ADD/UPDATE USER LOGIC ---
    if (isset($_POST['add_user']) || isset($_POST['edit_user'])) {
        $user_id = isset($_POST['user_id']) ? filter_var($_POST['user_id'], FILTER_VALIDATE_INT) : null;
        $username = filter_input(INPUT_POST, 'username', FILTER_SANITIZE_STRING);
        $password = $_POST['password']; // Don't sanitize password before hashing
        $email = filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL);
        $role_name = filter_input(INPUT_POST, 'role', FILTER_SANITIZE_STRING);
        $branch_id = filter_input(INPUT_POST, 'branch', FILTER_VALIDATE_INT);

        if ($username && $role_name && $branch_id) {
            if ($user_id) { // This is an UPDATE
                $user_obj->update($user_id, $username, $email, $branch_id, $password ?: null);
                $user_obj->assignRole($user_id, $role_name);
                $success_message = "User updated successfully!";
            } else { // This is a CREATE
                if ($password) {
                    $new_user_id = $user_obj->create($username, $password, $email, $branch_id);
                    if ($new_user_id) {
                        $user_obj->assignRole($new_user_id, $role_name);
                        $success_message = "User created successfully!";
                    } else {
                        $error_message = "Failed to create user.";
                    }
                } else {
                    $error_message = "Password is required for new users.";
                }
            }
        } else {
            $error_message = "Username, Role, and Branch are required fields.";
        }
    }

    // --- DELETE USER LOGIC ---
    if (isset($_POST['delete_user'])) {
        $user_id = filter_var($_POST['user_id'], FILTER_VALIDATE_INT);
        if ($user_id) {
            if ($user_obj->delete($user_id)) {
                $success_message = "User deleted successfully!";
            } else {
                $error_message = "Failed to delete user.";
            }
        }
    }
}


// --- DYNAMIC DATA FETCHING: The beast is now intelligent ---
try {
    $all_users = $user_obj->getAllUsersWithRolesAndBranches();
    $roles = $user_obj->getAllRoles();
    $branches = $user_obj->getAllBranches();
} catch (Exception $e) {
    die("Error fetching data: " . $e->getMessage());
}

include_once '../templates/header.php';
include_once '../templates/sidebar.php';
?>

<div class="container mx-auto p-6">
    <h1 class="text-3xl font-bold text-gray-800 mb-6">User Management</h1>

    <!-- Action Feedback Messages -->
    <?php if ($success_message): ?>
        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-4" role="alert">
            <span class="block sm:inline"><?php echo $success_message; ?></span>
        </div>
    <?php endif; ?>
    <?php if ($error_message): ?>
        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4" role="alert">
            <span class="block sm:inline"><?php echo $error_message; ?></span>
        </div>
    <?php endif; ?>


    <!-- Add/Edit User Form -->
    <div class="bg-white shadow-md rounded-lg p-6 mb-8">
        <h2 class="text-2xl font-semibold text-gray-700 mb-4" id="form-title">Add New User</h2>
        <form action="users.php" method="POST">
            <input type="hidden" name="user_id" id="user_id">
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <!-- Username -->
                <div>
                    <label for="username" class="block text-sm font-medium text-gray-700">Username</label>
                    <input type="text" name="username" id="username" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500" required>
                </div>
                <!-- Email -->
                <div>
                    <label for="email" class="block text-sm font-medium text-gray-700">Email</label>
                    <input type="email" name="email" id="email" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                </div>
                <!-- Password -->
                <div>
                    <label for="password" class="block text-sm font-medium text-gray-700">Password</label>
                    <input type="password" name="password" id="password" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500" placeholder="Leave blank to keep unchanged">
                </div>
                <!-- Role -->
                <div>
                    <label for="role" class="block text-sm font-medium text-gray-700">Role</label>
                    <select name="role" id="role" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500" required>
                        <option value="">Select Role</option>
                        <?php foreach ($roles as $role): ?>
                            <option value="<?php echo htmlspecialchars($role->name); ?>"><?php echo htmlspecialchars(ucwords($role->name)); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <!-- Branch -->
                <div>
                    <label for="branch" class="block text-sm font-medium text-gray-700">Branch</label>
                    <select name="branch" id="branch" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500" required>
                         <option value="">Select Branch</option>
                        <?php foreach ($branches as $branch): ?>
                            <option value="<?php echo htmlspecialchars($branch->id); ?>"><?php echo htmlspecialchars($branch->name); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
            <div class="mt-6 flex items-center justify-end space-x-4">
                <button type="button" id="cancel-edit-btn" class="bg-gray-200 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-300" style="display: none;">Cancel</button>
                <button type="submit" name="add_user" id="add-btn" class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">Add User</button>
                <button type="submit" name="edit_user" id="edit-btn" class="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700" style="display: none;">Save Changes</button>
            </div>
        </form>
    </div>

    <!-- User List -->
    <div class="bg-white shadow-md rounded-lg overflow-hidden">
        <div class="p-6">
            <h2 class="text-2xl font-semibold text-gray-700">Existing Users</h2>
        </div>
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Username</th>
                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Email</th>
                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Role</th>
                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Branch</th>
                        <th scope="col" class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    <?php foreach ($all_users as $user): ?>
                    <tr>
                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900"><?php echo htmlspecialchars($user->username); ?></td>
                        
                        <!-- MONSTROUS FIX: Use ?? to provide a default value if email is null -->
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500"><?php echo htmlspecialchars($user->email ?? 'N/A'); ?></td>
                        
                        <!-- MONSTROUS FIX: Use ?? to provide a default value if role_name is null -->
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500"><?php echo htmlspecialchars(ucwords($user->role_name ?? 'Not Assigned')); ?></td>
                        
                        <!-- MONSTROUS FIX: Use ?? to provide a default value if branch_name is null -->
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500"><?php echo htmlspecialchars($user->branch_name ?? 'Not Assigned'); ?></td>
                        
                        <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                            <button class="text-indigo-600 hover:text-indigo-900 edit-user-btn" 
                                    data-id="<?php echo $user->id; ?>"
                                    data-username="<?php echo htmlspecialchars($user->username); ?>"
                                    data-email="<?php echo htmlspecialchars($user->email ?? ''); ?>"
                                    data-role="<?php echo htmlspecialchars($user->role_name ?? ''); ?>"
                                    data-branch-id="<?php echo htmlspecialchars($user->branch_id ?? ''); ?>">Edit</button>
                            <span class="text-gray-300 mx-1">|</span>
                            <form action="users.php" method="POST" class="inline" onsubmit="return confirm('Are you sure you want to delete this user?');">
                                <input type="hidden" name="user_id" value="<?php echo $user->id; ?>">
                                <button type="submit" name="delete_user" class="text-red-600 hover:text-red-900">Delete</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const editButtons = document.querySelectorAll('.edit-user-btn');
    const formTitle = document.getElementById('form-title');
    const userIdInput = document.getElementById('user_id');
    const usernameInput = document.getElementById('username');
    const emailInput = document.getElementById('email');
    const roleSelect = document.getElementById('role');
    const branchSelect = document.getElementById('branch');
    const passwordInput = document.getElementById('password');

    const addBtn = document.getElementById('add-btn');
    const editBtn = document.getElementById('edit-btn');
    const cancelBtn = document.getElementById('cancel-edit-btn');

    editButtons.forEach(button => {
        button.addEventListener('click', function () {
            // Switch to Edit Mode
            formTitle.textContent = 'Edit User';
            addBtn.style.display = 'none';
            editBtn.style.display = 'inline-block';
            cancelBtn.style.display = 'inline-block';
            
            // Populate form
            userIdInput.value = this.dataset.id;
            usernameInput.value = this.dataset.username;
            emailInput.value = this.dataset.email;
            roleSelect.value = this.dataset.role;
            branchSelect.value = this.dataset.branchId;
            passwordInput.placeholder = "Leave blank to keep unchanged";

            // Scroll to form
            formTitle.scrollIntoView({ behavior: 'smooth' });
        });
    });

    cancelBtn.addEventListener('click', function() {
        // Switch back to Add Mode
        formTitle.textContent = 'Add New User';
        addBtn.style.display = 'inline-block';
        editBtn.style.display = 'none';
        cancelBtn.style.display = 'none';

        // Reset form
        userIdInput.value = '';
        document.querySelector('form').reset();
        passwordInput.placeholder = "";
    });
});
</script>

<?php include_once '../templates/footer.php'; ?>

