<?php
// THE ULTIMATE VISION, REALIZED: This is the user's new dashboard, built on our secure engine
// and with every query meticulously attuned to the confirmed live database schemas.

ini_set('display_errors', 1);
error_reporting(E_ALL);


require_once '../core/init.php';
require_once '../core/security.php';

include_once '../templates/header.php';
// --- THE IMPERIAL GUARD ---
// This dashboard is for the emperor alone.
enforce_security(99);

$currentUser = getCurrentUser();
$db = Database::getInstance();
$role = getUserRole($db, $_SESSION['user_id']);

// --- COMPREHENSIVE DATA FETCHING FROM YOUR NEW VISION ---
$employee = new Employee($db);
$totalEmployees = $employee->count();
$today = date('Y-m-d');
$startOfMonth = date('Y-m-01');
$endOfMonth = date('Y-m-t');
$daysInMonth = date('t');

// --- Data for Cards (Attuned to Live Schema) ---
$presentResult = $db->query("SELECT COUNT(DISTINCT employee_id) as count FROM attendance WHERE date = ? AND status = 'present'", [$today]);
$presentCount = $presentResult ? $presentResult->first()->count : 0;

// Corrected: Uses `leaves` table, not `leave_requests`.
$pendingLeavesResult = $db->query("SELECT COUNT(*) as count FROM leaves WHERE status = 'pending'");
$onLeaveCount = $pendingLeavesResult ? $pendingLeavesResult->first()->count : 0;

$todaysExpenseSql = "SELECT SUM(e.base_salary / ?) as daily_expense FROM employees e JOIN attendance a ON e.id = a.employee_id WHERE a.status = 'present' AND a.date = ?";
$todaysExpenseResult = $db->query($todaysExpenseSql, [$daysInMonth, $today]);
$todaysSalaryExpense = $todaysExpenseResult->first()->daily_expense ?? 0;

$monthlyExpenseSql = "SELECT SUM(base_salary) as total_salary FROM employees WHERE status = 'active'";
$monthlyExpenseResult = $db->query($monthlyExpenseSql);
$estimatedMonthlySalary = $monthlyExpenseResult->first()->total_salary ?? 0;

$cumulativeExpenseSql = "SELECT SUM(e.base_salary / ?) as cumulative_expense FROM employees e JOIN attendance a ON e.id = a.employee_id WHERE a.status = 'present' AND a.date BETWEEN ? AND ?";
$cumulativeExpenseResult = $db->query($cumulativeExpenseSql, [$daysInMonth, $startOfMonth, $today]);
$cumulativeSalaryExpense = $cumulativeExpenseResult->first()->cumulative_expense ?? 0;

// NOTE: The following queries for advances, loans, and installments assume tables and columns
// like `salary_advances` (amount, advance_date), `loans` (amount, loan_date), and `loan_installments` exist.
$advancesSql = "SELECT SUM(amount) as total_advances FROM salary_advances WHERE advance_date BETWEEN ? AND ?";
$advancesResult = $db->query($advancesSql, [$startOfMonth, $endOfMonth]);
$monthlyAdvances = $advancesResult->first()->total_advances ?? 0;

$loansSql = "SELECT SUM(amount) as total_loans FROM loans WHERE loan_date BETWEEN ? AND ?";
$loansResult = $db->query($loansSql, [$startOfMonth, $endOfMonth]);
$monthlyLoans = $loansResult->first()->total_loans ?? 0;

$remainingSalary = $estimatedMonthlySalary - $cumulativeSalaryExpense - $monthlyAdvances;

// --- Data for Charts & Lists (Attuned to Live Schema) ---
$absentCount = $totalEmployees > 0 ? max(0, $totalEmployees - $presentCount - $onLeaveCount) : 0;

// NOTE: Assumes `departments.name` and `positions.name` are the correct column names.
$deptEmpSql = "SELECT d.name AS department_name, COUNT(e.id) AS total_employees FROM departments d LEFT JOIN positions p ON d.id = p.department_id LEFT JOIN employees e ON p.id = e.position_id GROUP BY d.name HAVING total_employees > 0 ORDER BY d.name";
$deptEmpResult = $db->query($deptEmpSql);
$deptEmpStats = $deptEmpResult ? $deptEmpResult->results() : [];
$deptEmpLabels = []; $deptEmpData = [];
foreach ($deptEmpStats as $stat) { $deptEmpLabels[] = $stat->department_name; $deptEmpData[] = $stat->total_employees; }

$deptSalarySql = "SELECT d.name AS department_name, SUM(e.base_salary) AS total_salary FROM departments d LEFT JOIN positions p ON d.id = p.department_id LEFT JOIN employees e ON p.id = e.position_id WHERE e.status = 'active' GROUP BY d.name HAVING total_salary > 0 ORDER BY total_salary DESC";
$deptSalaryResult = $db->query($deptSalarySql);
$deptSalaryStats = $deptSalaryResult ? $deptSalaryResult->results() : [];
$deptSalaryLabels = []; $deptSalaryData = [];
foreach ($deptSalaryStats as $stat) { $deptSalaryLabels[] = $stat->department_name; $deptSalaryData[] = $stat->total_salary; }

$currentYear = date('Y');
// Corrected: Uses `pay_period_end` and `net_salary` from your confirmed `payrolls` schema.
$monthlyExpenseHistorySql = "SELECT MONTH(pay_period_end) as month, SUM(net_salary) as total_paid FROM payrolls WHERE YEAR(pay_period_end) = ? AND status IN ('paid', 'disbursed') GROUP BY MONTH(pay_period_end) ORDER BY month ASC";
$monthlyExpenseResult = $db->query($monthlyExpenseHistorySql, [$currentYear]);
$monthlyExpenses = $monthlyExpenseResult ? $monthlyExpenseResult->results() : [];
$monthData = array_fill(1, 12, 0);
foreach ($monthlyExpenses as $expense) { $monthData[(int)$expense->month] = $expense->total_paid; }
$monthLabels = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
$monthData = array_values($monthData);

// Corrected: Uses `first_name`, `last_name`, `base_salary`. Assumes `positions.name`.
$topEarnersSql = "SELECT e.first_name, e.last_name, e.base_salary, p.name AS position_name FROM employees e LEFT JOIN positions p ON e.position_id = p.id WHERE e.status = 'active' ORDER BY e.base_salary DESC LIMIT 10";
$topEarnersResult = $db->query($topEarnersSql);
$topEarners = $topEarnersResult ? $topEarnersResult->results() : [];

$outstandingDebtsSql = "
    SELECT e.id, e.first_name, e.last_name, 'Salary Advance' as type, sa.amount, sa.advance_date as date
    FROM salary_advances sa
    JOIN employees e ON sa.employee_id = e.id
    WHERE sa.status = 'approved'
    UNION ALL
    SELECT e.id, e.first_name, e.last_name, 'Loan' as type, l.amount - IFNULL((SELECT SUM(amount) FROM loan_installments WHERE loan_id = l.id), 0) as amount, l.loan_date as date
    FROM loans l
    JOIN employees e ON l.employee_id = e.id
    WHERE l.status = 'active'
    ORDER BY date DESC
    LIMIT 10
";
$outstandingDebtsResult = $db->query($outstandingDebtsSql);
$outstandingDebts = $outstandingDebtsResult ? $outstandingDebtsResult->results() : [];

$recentAdvancesSql = "
    SELECT e.first_name, e.last_name, sa.amount, sa.advance_date
    FROM salary_advances sa
    JOIN employees e ON sa.employee_id = e.id
    ORDER BY sa.advance_date DESC
    LIMIT 10
";
$recentAdvancesResult = $db->query($recentAdvancesSql);
$recentAdvances = $recentAdvancesResult ? $recentAdvancesResult->results() : [];

// Corrected: Uses `date` column and `first_name`/`last_name`. Assumes `positions.name`.
$frequentAbsenceSql = "
    SELECT e.first_name, e.last_name, p.name as position_name, COUNT(a.id) as absent_days
    FROM attendance a
    JOIN employees e ON a.employee_id = e.id
    LEFT JOIN positions p ON e.position_id = p.id
    WHERE a.status = 'absent' AND MONTH(a.date) = MONTH(CURRENT_DATE()) AND YEAR(a.date) = YEAR(CURRENT_DATE())
    GROUP BY e.id, e.first_name, e.last_name, p.name
    ORDER BY absent_days DESC
    LIMIT 5
";
$frequentAbsenceResult = $db->query($frequentAbsenceSql);
$frequentAbsences = $frequentAbsenceResult ? $frequentAbsenceResult->results() : [];

$pageTitle = 'Dashboard - Fajracct HRM';
include_once '../templates/header.php';
include_once '../templates/sidebar.php';
?>

<!-- Main Content - YOUR NEW VISION, REALIZED -->
<div class="space-y-8 p-4 md:p-6">
    <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h1 class="text-2xl font-bold text-gray-900"><i class="fas fa-tachometer-alt text-indigo-600 mr-3"></i>Admin Dashboard</h1>
        <p class="mt-1 text-sm text-gray-600">Welcome back, <?php echo htmlspecialchars($currentUser->username); ?>! Here's your HRM overview for <?php echo date("l, F j, Y"); ?>.</p>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <div class="bg-gradient-to-br from-blue-500 to-indigo-600 rounded-xl shadow-lg p-6 text-white transform hover:scale-105 transition-transform duration-300">
            <div class="flex items-center justify-between">
                <div>
                    <p class="font-semibold text-blue-100">Total Employees</p>
                    <p class="text-4xl font-bold mt-2"><?php echo $totalEmployees; ?></p>
                </div>
                <div class="bg-white bg-opacity-20 rounded-full p-4"><i class="fas fa-users text-4xl"></i></div>
            </div>
        </div>
        <div class="bg-gradient-to-br from-green-500 to-teal-600 rounded-xl shadow-lg p-6 text-white transform hover:scale-105 transition-transform duration-300">
            <div class="flex items-center justify-between">
                <div>
                    <p class="font-semibold text-green-100">Present Today</p>
                    <p class="text-4xl font-bold mt-2"><?php echo $presentCount; ?></p>
                </div>
                <div class="bg-white bg-opacity-20 rounded-full p-4"><i class="fas fa-user-check text-4xl"></i></div>
            </div>
        </div>
        <div class="bg-gradient-to-br from-amber-500 to-orange-600 rounded-xl shadow-lg p-6 text-white transform hover:scale-105 transition-transform duration-300">
            <div class="flex items-center justify-between">
                <div>
                    <p class="font-semibold text-amber-100">Pending Leave</p>
                    <p class="text-4xl font-bold mt-2"><?php echo $onLeaveCount; ?></p>
                </div>
                <div class="bg-white bg-opacity-20 rounded-full p-4"><i class="fas fa-calendar-times text-4xl"></i></div>
            </div>
        </div>
        <div class="bg-gradient-to-br from-rose-500 to-pink-600 rounded-xl shadow-lg p-6 text-white transform hover:scale-105 transition-transform duration-300">
            <div>
                <p class="font-semibold text-rose-100">Today's Salary Expense</p>
                <p class="text-3xl font-bold mt-2">৳<?php echo number_format($todaysSalaryExpense, 2); ?></p>
            </div>
        </div>
        <div class="bg-gradient-to-br from-cyan-500 to-sky-600 rounded-xl shadow-lg p-6 text-white transform hover:scale-105 transition-transform duration-300">
            <div>
                <p class="font-semibold text-cyan-100">Cumulative Expense (MTD)</p>
                <p class="text-3xl font-bold mt-2">৳<?php echo number_format($cumulativeSalaryExpense, 2); ?></p>
            </div>
        </div>
        <div class="bg-gradient-to-br from-purple-500 to-violet-600 rounded-xl shadow-lg p-6 text-white transform hover:scale-105 transition-transform duration-300">
            <div>
                <p class="font-semibold text-purple-100">Est. Monthly Salary</p>
                <p class="text-3xl font-bold mt-2">৳<?php echo number_format($estimatedMonthlySalary, 2); ?></p>
            </div>
        </div>
    </div>
    
     <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div class="bg-gradient-to-br from-red-500 to-red-700 rounded-xl shadow-lg p-6 text-white transform hover:scale-105 transition-transform duration-300">
             <div>
                <p class="font-semibold text-red-100">Salary Advance (This Month)</p>
                <p class="text-3xl font-bold mt-2">৳<?php echo number_format($monthlyAdvances, 2); ?></p>
            </div>
        </div>
        <div class="bg-gradient-to-br from-fuchsia-500 to-purple-600 rounded-xl shadow-lg p-6 text-white transform hover:scale-105 transition-transform duration-300">
            <div>
                <p class="font-semibold text-fuchsia-100">Loans Taken (This Month)</p>
                <p class="text-3xl font-bold mt-2">৳<?php echo number_format($monthlyLoans, 2); ?></p>
            </div>
        </div>
        <div class="bg-gradient-to-br from-lime-500 to-green-600 rounded-xl shadow-lg p-6 text-white transform hover:scale-105 transition-transform duration-300">
            <div>
                <p class="font-semibold text-lime-100">Remaining Salary Expense</p>
                <p class="text-3xl font-bold mt-2">৳<?php echo number_format($remainingSalary, 2); ?></p>
            </div>
        </div>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-6"><h2 class="text-lg font-semibold text-gray-800 mb-4">Today's Employee Status</h2><div class="h-80"><canvas id="attendancePieChart"></canvas></div></div>
        <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-6"><h2 class="text-lg font-semibold text-gray-800 mb-4">Employee Distribution</h2><div class="h-80"><canvas id="departmentPieChart"></canvas></div></div>
    </div>
    
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-6"><h2 class="text-lg font-semibold text-gray-800 mb-4">Monthly Salary Expense by Department</h2><div style="height: 400px;"><canvas id="departmentSalaryPieChart"></canvas></div></div>
        <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-6"><h2 class="text-lg font-semibold text-gray-800 mb-4">Paid Salary Expense for <?php echo date('Y'); ?></h2><div style="height: 400px;"><canvas id="monthlyExpenseBarChart"></canvas></div></div>
    </div>
    
    <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h2 class="text-lg font-semibold text-gray-800 mb-4">Most Frequent Absences (This Month)</h2>
        <div class="space-y-4">
            <?php if(!empty($frequentAbsences)): foreach($frequentAbsences as $absence): ?>
            <div class="flex items-center bg-gray-50 rounded-lg p-3">
                <div class="flex-shrink-0 h-10 w-10 bg-red-100 rounded-lg flex items-center justify-center"><i class="fas fa-calendar-times text-red-600"></i></div>
                <div class="ml-4 flex-grow">
                    <p class="font-semibold text-gray-900"><?php echo htmlspecialchars($absence->first_name . ' ' . $absence->last_name); ?></p>
                    <p class="text-sm text-gray-500"><?php echo htmlspecialchars($absence->position_name ?? 'N/A'); ?></p>
                </div>
                <div class="text-right">
                    <p class="text-lg font-bold text-red-600"><?php echo $absence->absent_days; ?> days</p>
                </div>
            </div>
            <?php endforeach; else: ?>
            <p class="text-center text-gray-500 py-8">No absence records found for this month.</p>
            <?php endif; ?>
        </div>
    </div>
    
    <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h2 class="text-lg font-semibold text-gray-800 mb-4">Recent Outstanding Debts</h2>
        <div class="space-y-4">
            <?php if(!empty($outstandingDebts)): foreach($outstandingDebts as $debt): ?>
            <div class="flex items-center bg-gray-50 rounded-lg p-3">
                <div class="flex-shrink-0 h-10 w-10 <?php echo $debt->type === 'Loan' ? 'bg-red-100' : 'bg-orange-100'; ?> rounded-lg flex items-center justify-center">
                    <i class="fas <?php echo $debt->type === 'Loan' ? 'fa-landmark text-red-600' : 'fa-hand-holding-usd text-orange-600'; ?>"></i>
                </div>
                <div class="ml-4 flex-grow">
                    <p class="font-semibold text-gray-900"><?php echo htmlspecialchars($debt->first_name . ' ' . $debt->last_name); ?></p>
                    <p class="text-sm text-gray-500"><?php echo htmlspecialchars($debt->type); ?></p>
                </div>
                <div class="text-right">
                    <p class="text-md font-bold text-red-600">৳<?php echo number_format($debt->amount, 2); ?></p>
                    <p class="text-xs text-gray-400"><?php echo date('M d, Y', strtotime($debt->date)); ?></p>
                </div>
            </div>
            <?php endforeach; else: ?>
            <p class="text-center text-gray-500 py-8">No outstanding debts found.</p>
            <?php endif; ?>
        </div>
    </div>

    <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h2 class="text-lg font-semibold text-gray-800 mb-4">Recent Salary Advances</h2>
        <div class="space-y-4">
            <?php if(!empty($recentAdvances)): foreach($recentAdvances as $advance): ?>
            <div class="flex items-center bg-gray-50 rounded-lg p-3">
                <div class="flex-shrink-0 h-10 w-10 bg-orange-100 rounded-lg flex items-center justify-center"><i class="fas fa-hand-holding-usd text-orange-600"></i></div>
                <div class="ml-4 flex-grow">
                    <p class="font-semibold text-gray-900"><?php echo htmlspecialchars($advance->first_name . ' ' . $advance->last_name); ?></p>
                    <p class="text-sm text-gray-500"><?php echo date('M d, Y', strtotime($advance->advance_date)); ?></p>
                </div>
                <div class="text-right">
                    <p class="text-md font-bold text-orange-600">৳<?php echo number_format($advance->amount, 2); ?></p>
                </div>
            </div>
            <?php endforeach; else: ?>
            <p class="text-center text-gray-500 py-8">No recent salary advances found.</p>
            <?php endif; ?>
        </div>
    </div>

    <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h2 class="text-lg font-semibold text-gray-800 mb-4">Top 10 Highest Earning Employees</h2>
        <div class="space-y-4">
            <?php if(!empty($topEarners)): foreach($topEarners as $index => $earner): ?>
            <div class="flex items-center bg-gray-50 rounded-lg p-3 transition-shadow duration-200 hover:shadow-md">
                <span class="text-lg font-bold text-gray-400 w-8 text-center"><?php echo $index + 1; ?></span>
                <div class="flex-shrink-0 h-10 w-10 bg-indigo-100 rounded-full flex items-center justify-center ml-4"><i class="fas fa-user text-indigo-600"></i></div>
                <div class="ml-4 flex-grow">
                    <p class="font-semibold text-gray-900"><?php echo htmlspecialchars($earner->first_name . ' ' . $earner->last_name); ?></p>
                    <p class="text-sm text-gray-500"><?php echo htmlspecialchars($earner->position_name ?? 'N/A'); ?></p>
                </div>
                <div class="text-right">
                    <p class="text-md font-bold text-green-600">৳<?php echo number_format($earner->base_salary); ?></p>
                    <p class="text-xs text-gray-400">Monthly</p>
                </div>
            </div>
            <?php endforeach; endif; ?>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const observerOptions = { root: null, rootMargin: '0px', threshold: 0.1 };
        const observer = new IntersectionObserver((entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const canvas = entry.target;
                    const chartId = canvas.id;
                    // Lazy load charts
                    if (chartId === 'attendancePieChart') { new Chart(canvas.getContext('2d'), { type: 'pie', data: { labels: [`Present: <?php echo $presentCount; ?>`, `Absent: <?php echo $absentCount; ?>`, `On Leave: <?php echo $onLeaveCount; ?>`], datasets: [{ data: [<?php echo $presentCount; ?>, <?php echo $absentCount; ?>, <?php echo $onLeaveCount; ?>], backgroundColor: ['#22C55E', '#EF4444', '#F59E0B'], hoverOffset: 4 }] }, options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'top' }, title: { display: true, text: 'Total Employees: <?php echo $totalEmployees; ?>' } } } }); }
                    else if (chartId === 'departmentPieChart') { new Chart(canvas.getContext('2d'), { type: 'pie', data: { labels: <?php echo json_encode($deptEmpLabels); ?>, datasets: [{ label: 'Employees', data: <?php echo json_encode($deptEmpData); ?>, backgroundColor: ['#3B82F6','#10B981','#F97316','#8B5CF6','#EC4899','#6366F1'], hoverOffset: 4 }] }, options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'top' }, title: { display: true, text: 'Employee Count per Department' } } } }); }
                    else if (chartId === 'departmentSalaryPieChart') { new Chart(canvas.getContext('2d'), { type: 'pie', data: { labels: <?php echo json_encode($deptSalaryLabels); ?>, datasets: [{ label: 'Monthly Salary (৳)', data: <?php echo json_encode($deptSalaryData); ?>, backgroundColor: ['#8B5CF6','#EC4899','#6366F1','#3B82F6','#10B981','#F97316'], hoverOffset: 4 }] }, options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'right' }, title: { display: true, text: 'Total Est. Salary: ৳<?php echo number_format($estimatedMonthlySalary, 2); ?>' } } } }); }
                    else if (chartId === 'monthlyExpenseBarChart') { new Chart(canvas.getContext('2d'), { type: 'bar', data: { labels: <?php echo json_encode($monthLabels); ?>, datasets: [{ label: 'Total Paid Salary (৳)', data: <?php echo json_encode($monthData); ?>, backgroundColor: 'rgba(59, 130, 246, 0.6)', borderColor: 'rgba(59, 130, 246, 1)', borderWidth: 1 }] }, options: { responsive: true, maintainAspectRatio: false, scales: { y: { beginAtZero: true } }, plugins: { legend: { display: false } } } }); }
                    observer.unobserve(canvas);
                }
            });
        }, observerOptions);
        document.querySelectorAll('canvas').forEach(canvas => observer.observe(canvas));
    });
</script>

<?php include_once '../templates/footer.php'; ?>

