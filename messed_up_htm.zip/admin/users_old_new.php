<?php
// MONSTROUSLY RECTIFIED: User Management Hub
// This file has been completely overhauled to be robust, secure, and intelligent.

ini_set('display_errors', 1);
error_reporting(E_ALL);

require_once '../core/init.php';

// A monster always checks for proper authority.
if (!is_admin_logged_in()) { // Assuming you have a function like this
    header('Location: ../auth/login.php');
    exit();
}

$db = Database::getInstance()->getConnection();
$user_obj = new User($db);

// --- DYNAMIC DATA FETCHING: The beast is now intelligent ---
try {
    // Fetch all manageable roles from the database
    $roles = $db->query("SELECT id, name FROM roles ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC);
    // Fetch all branches
    $branches = $db->query("SELECT id, name FROM branches ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC);
    // Fetch all users with their assigned role and branch for display
    $users = $user_obj->getAllUsersWithRolesAndBranches();
} catch (PDOException $e) {
    die("Database query failed: " . $e->getMessage());
}


// --- MONSTROUS LOGIC: Handle ALL form submissions with transactions ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // --- ADD USER LOGIC ---
    if (isset($_POST['add_user'])) {
        $username = trim($_POST['username']);
        $password = $_POST['password'];
        $email = trim($_POST['email']);
        $branch_id = filter_input(INPUT_POST, 'branch_id', FILTER_VALIDATE_INT);
        $role_id = filter_input(INPUT_POST, 'role_id', FILTER_VALIDATE_INT);

        if (empty($username) || empty($password) || !$branch_id || !$role_id) {
            $_SESSION['error'] = "Username, password, branch, and role are all required.";
        } else {
            $db->beginTransaction();
            try {
                $user_id = $user_obj->create($username, $password, $email, $branch_id);
                $user_obj->assignRole($user_id, $role_id);
                $db->commit();
                $_SESSION['success'] = "User '" . htmlspecialchars($username) . "' created and role assigned successfully!";
            } catch (Exception $e) {
                $db->rollBack();
                $_SESSION['error'] = "Failed to create user: " . $e->getMessage();
            }
        }
        header('Location: users.php');
        exit();
    }

    // --- UPDATE USER LOGIC ---
    if (isset($_POST['update_user'])) {
        $user_id = filter_input(INPUT_POST, 'user_id', FILTER_VALIDATE_INT);
        $username = trim($_POST['username']);
        $email = trim($_POST['email']);
        $password = $_POST['password']; // Will be empty if not changing
        $branch_id = filter_input(INPUT_POST, 'branch_id', FILTER_VALIDATE_INT);
        $role_id = filter_input(INPUT_POST, 'role_id', FILTER_VALIDATE_INT);

        if (!$user_id || empty($username) || !$branch_id || !$role_id) {
            $_SESSION['error'] = "Invalid data provided for user update.";
        } else {
            $db->beginTransaction();
            try {
                $user_obj->update($user_id, $username, $email, $branch_id, $password); // Pass password (even if empty)
                $user_obj->assignRole($user_id, $role_id); // The assignRole method should handle updates (delete old, insert new)
                $db->commit();
                $_SESSION['success'] = "User '" . htmlspecialchars($username) . "' updated successfully!";
            } catch (Exception $e) {
                $db->rollBack();
                $_SESSION['error'] = "Failed to update user: " . $e->getMessage();
            }
        }
        header('Location: users.php');
        exit();
    }

    // --- DELETE USER LOGIC ---
    if (isset($_POST['delete_user'])) {
        $user_id = filter_input(INPUT_POST, 'user_id', FILTER_VALIDATE_INT);
        if (!$user_id) {
            $_SESSION['error'] = "Invalid user ID for deletion.";
        } else {
            try {
                // The User class should handle deleting related data (like user_roles) via transactions or DB constraints.
                $user_obj->delete($user_id);
                $_SESSION['success'] = "User deleted successfully.";
            } catch (Exception $e) {
                $_SESSION['error'] = "Failed to delete user: " . $e->getMessage();
            }
        }
        header('Location: users.php');
        exit();
    }
}

// You must also add the corresponding methods (getAllUsersWithRolesAndBranches, assignRole, update, delete) to your User class in `core/classes/User.php`.
// Without them, this file will fail. I am assuming they exist based on your code structure.

include_once '../templates/header.php';
?>

<div class="container-fluid py-4">
    <!-- Page Title & Add User Button -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="h3 mb-0 text-gray-800">User & Role Management</h1>
        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addUserModal">
            <i class="fas fa-plus me-2"></i>Add New User
        </button>
    </div>

    <!-- Session Messages -->
    <?php if(isset($_SESSION['success'])): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    <?php if(isset($_SESSION['error'])): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>


    <!-- Users List Card -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">System Users</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Username</th>
                            <th>Email</th>
                            <th>Role</th>
                            <th>Branch</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($users as $user): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($user['username']); ?></td>
                                <td><?php echo htmlspecialchars($user['email']); ?></td>
                                <td><span class="badge bg-info text-dark"><?php echo htmlspecialchars($user['role_name']); ?></span></td>
                                <td><span class="badge bg-secondary"><?php echo htmlspecialchars($user['branch_name']); ?></span></td>
                                <td>
                                    <button class="btn btn-warning btn-sm edit-user-btn" 
                                            data-bs-toggle="modal" 
                                            data-bs-target="#editUserModal"
                                            data-user-id="<?php echo $user['id']; ?>"
                                            data-username="<?php echo htmlspecialchars($user['username']); ?>"
                                            data-email="<?php echo htmlspecialchars($user['email']); ?>"
                                            data-role-id="<?php echo $user['role_id']; ?>"
                                            data-branch-id="<?php echo $user['branch_id']; ?>">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <button class="btn btn-danger btn-sm delete-user-btn" 
                                            data-bs-toggle="modal"
                                            data-bs-target="#deleteUserModal"
                                            data-user-id="<?php echo $user['id']; ?>"
                                            data-username="<?php echo htmlspecialchars($user['username']); ?>">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Add User Modal -->
<div class="modal fade" id="addUserModal" tabindex="-1" aria-labelledby="addUserModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="users.php" method="POST">
                <div class="modal-header">
                    <h5 class="modal-title" id="addUserModalLabel">Add New User</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="username" class="form-label">Username</label>
                        <input type="text" class="form-control" id="username" name="username" required>
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label">Email Address</label>
                        <input type="email" class="form-control" id="email" name="email">
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" class="form-control" id="password" name="password" required>
                    </div>
                    <div class="mb-3">
                        <label for="role_id" class="form-label">Role</label>
                        <select class="form-select" id="role_id" name="role_id" required>
                            <option value="" selected disabled>Select a role...</option>
                            <?php foreach ($roles as $role): ?>
                                <option value="<?php echo $role['id']; ?>"><?php echo htmlspecialchars($role['name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="branch_id" class="form-label">Branch</label>
                        <select class="form-select" id="branch_id" name="branch_id" required>
                            <option value="" selected disabled>Select a branch...</option>
                             <?php foreach ($branches as $branch): ?>
                                <option value="<?php echo $branch['id']; ?>"><?php echo htmlspecialchars($branch['name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" name="add_user" class="btn btn-primary">Add User</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit User Modal -->
<div class="modal fade" id="editUserModal" tabindex="-1" aria-labelledby="editUserModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="users.php" method="POST">
                <input type="hidden" name="user_id" id="edit_user_id">
                <div class="modal-header">
                    <h5 class="modal-title" id="editUserModalLabel">Edit User</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="edit_username" class="form-label">Username</label>
                        <input type="text" class="form-control" id="edit_username" name="username" required>
                    </div>
                    <div class="mb-3">
                        <label for="edit_email" class="form-label">Email Address</label>
                        <input type="email" class="form-control" id="edit_email" name="email">
                    </div>
                    <div class="mb-3">
                        <label for="edit_password" class="form-label">New Password (leave blank to keep current)</label>
                        <input type="password" class="form-control" id="edit_password" name="password">
                    </div>
                    <div class="mb-3">
                        <label for="edit_role_id" class="form-label">Role</label>
                        <select class="form-select" id="edit_role_id" name="role_id" required>
                            <?php foreach ($roles as $role): ?>
                                <option value="<?php echo $role['id']; ?>"><?php echo htmlspecialchars($role['name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="edit_branch_id" class="form-label">Branch</label>
                        <select class="form-select" id="edit_branch_id" name="branch_id" required>
                             <?php foreach ($branches as $branch): ?>
                                <option value="<?php echo $branch['id']; ?>"><?php echo htmlspecialchars($branch['name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" name="update_user" class="btn btn-primary">Save Changes</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Delete User Modal -->
<div class="modal fade" id="deleteUserModal" tabindex="-1" aria-labelledby="deleteUserModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="users.php" method="POST">
                <input type="hidden" name="user_id" id="delete_user_id">
                <div class="modal-header">
                    <h5 class="modal-title" id="deleteUserModalLabel">Confirm Deletion</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p>Are you sure you want to delete the user <strong id="delete_username"></strong>? This action cannot be undone.</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="delete_user" class="btn btn-danger">Delete User</button>
                </div>
            </form>
        </div>
    </div>
</div>


<?php include_once '../templates/footer.php'; ?>

<script>
// MONSTROUS JAVASCRIPT: To power the edit and delete modals
document.addEventListener('DOMContentLoaded', function() {
    // Logic for Edit User Modal
    const editUserModal = document.getElementById('editUserModal');
    editUserModal.addEventListener('show.bs.modal', function (event) {
        const button = event.relatedTarget;
        const userId = button.getAttribute('data-user-id');
        const username = button.getAttribute('data-username');
        const email = button.getAttribute('data-email');
        const roleId = button.getAttribute('data-role-id');
        const branchId = button.getAttribute('data-branch-id');

        const modalTitle = editUserModal.querySelector('.modal-title');
        const userIdInput = editUserModal.querySelector('#edit_user_id');
        const usernameInput = editUserModal.querySelector('#edit_username');
        const emailInput = editUserModal.querySelector('#edit_email');
        const roleSelect = editUserModal.querySelector('#edit_role_id');
        const branchSelect = editUserModal.querySelector('#edit_branch_id');

        modalTitle.textContent = 'Edit User: ' + username;
        userIdInput.value = userId;
        usernameInput.value = username;
        emailInput.value = email;
        roleSelect.value = roleId;
        branchSelect.value = branchId;
    });

    // Logic for Delete User Modal
    const deleteUserModal = document.getElementById('deleteUserModal');
    deleteUserModal.addEventListener('show.bs.modal', function (event) {
        const button = event.relatedTarget;
        const userId = button.getAttribute('data-user-id');
        const username = button.getAttribute('data-username');
        
        const userIdInput = deleteUserModal.querySelector('#delete_user_id');
        const usernameSpan = deleteUserModal.querySelector('#delete_username');

        userIdInput.value = userId;
        usernameSpan.textContent = username;
    });
});
</script>

