<?php
require_once '../core/init.php';
// Basic security: ensure user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: ../auth/login.php');
    exit();
}

// Fetch branch name for display
$db = Database::getInstance()->getConnection();
$stmt = $db->prepare("SELECT name FROM branches WHERE id = ?");
$stmt->execute([$_SESSION['branch_id']]);
$branch = $stmt->fetch();
$branch_name = $branch ? $branch['name'] : 'Unknown Branch';


include '../templates/header.php';
?>

<div class="container mt-4">
    <div class="card">
        <div class="card-header bg-info text-white">
            <h1 class="card-title mb-0">Branch Attendant Watchpost</h1>
        </div>
        <div class="card-body">
            <h2>Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?>!</h2>
            <p class="lead">You have successfully logged into your watchpost.</p>
            <ul>
                <li><strong>Your Role:</strong> <?php echo htmlspecialchars($_SESSION['role']); ?></li>
                <li><strong>Your Domain:</strong> <?php echo htmlspecialchars($branch_name); ?></li>
            </ul>
            <hr>
            <p>This is your dedicated dashboard. From here, you will manage all attendance records for your branch.</p>
            <div class="mt-4">
                <a href="#" class="btn btn-primary">Mark Manual Attendance</a>
                <a href="#" class="btn btn-secondary">View Today's Roster</a>
            </div>
        </div>
    </div>
</div>

<?php include '../templates/footer.php'; ?>
