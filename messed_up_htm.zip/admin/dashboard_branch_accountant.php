<?php
require_once '../core/init.php';
// Basic security: ensure user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: ../auth/login.php');
    exit();
}

// Fetch branch name for display
$db = Database::getInstance()->getConnection();
$stmt = $db->prepare("SELECT name FROM branches WHERE id = ?");
$stmt->execute([$_SESSION['branch_id']]);
$branch = $stmt->fetch();
$branch_name = $branch ? $branch['name'] : 'Unknown Branch';

include '../templates/header.php';
?>

<div class="container mt-4">
    <div class="card">
        <div class="card-header bg-primary text-white">
            <h1 class="card-title mb-0">Branch Accountant Dashboard</h1>
        </div>
        <div class="card-body">
            <h2>Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?>!</h2>
            <p class="lead">You have successfully logged into your command center.</p>
            <ul>
                <li><strong>Your Role:</strong> <?php echo htmlspecialchars($_SESSION['role']); ?></li>
                <li><strong>Your Domain:</strong> <?php echo htmlspecialchars($branch_name); ?></li>
            </ul>
            <hr>
            <p>This is your dedicated dashboard. From here, you will manage all financial operations for your branch.</p>
            <div class="mt-4">
                <a href="#" class="btn btn-success">Prepare Payroll</a>
                <a href="#" class="btn btn-info">Manage Loans</a>
                <a href="#" class="btn btn-warning">Handle Leave Applications</a>
            </div>
        </div>
    </div>
</div>

<?php include '../templates/footer.php'; ?>
