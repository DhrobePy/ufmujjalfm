<?php
// MONSTROUSLY REFORGED: The complete User Class
// This warrior is now fully armed with all the spells required by the command center.

class User {
    private $_db; // This will hold the PDO connection object

    /**
     * Constructor now intelligently handles the database object.
     * It ensures it always works with the raw PDO connection for maximum power.
     */
    public function __construct($db_instance) {
        if ($db_instance instanceof Database) {
            // If the Singleton Database object is passed, get the connection from it
            $this->_db = $db_instance->getConnection(); 
        } elseif ($db_instance instanceof PDO) {
            // If a direct PDO connection is passed, use it
            $this->_db = $db_instance;
        } else {
            // If something else is passed, a monstrous error has occurred.
            throw new Exception("A valid database connection must be provided to the User class.");
        }
    }

    /**
     * ANCIENT SPELL: Logs a user in.
     * Finds a user by username and verifies their password.
     * @return object|false The user data object if successful, false otherwise.
     */
    public function login($username, $password) {
        $user = $this->find($username);
        if ($user) {
            if (password_verify($password, $user->password)) {
                return $user;
            }
        }
        return false;
    }

    /**
     * ANCIENT SPELL: Finds a user by their username.
     * @return object|false The user data object if found, false otherwise.
     */
    public function find($username = null) {
        if ($username) {
            $stmt = $this->_db->prepare("SELECT * FROM users WHERE username = ?");
            $stmt->execute([$username]);
            if ($stmt->rowCount()) {
                return $stmt->fetch(PDO::FETCH_OBJ);
            }
        }
        return false;
    }
    
    // --- ARSENAL OF NEW SPELLS ---

    /**
     * NEW POWER: Fetches all users with their associated role and branch names.
     * This is the engine for the user management table.
     * @return array An array of all users.
     */
    public function getAllUsersWithRolesAndBranches() {
        $sql = "SELECT 
                    u.id, 
                    u.username, 
                    u.email,
                    r.id as role, 
                    r.name as role_name, 
                    b.id as branch_id,
                    b.name as branch_name
                FROM users u
                LEFT JOIN user_roles ur ON u.id = ur.user_id
                LEFT JOIN roles r ON ur.role = r.id
                LEFT JOIN branches b ON u.branch_id = b.id
                ORDER BY u.username ASC";
        
        $stmt = $this->_db->query($sql);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * NEW POWER: Creates a new user in the database.
     * Securely hashes the password.
     * @return string The ID of the newly created user.
     */
    public function create($username, $password, $email, $branch_id) {
        if (empty($password)) {
            throw new Exception("Password cannot be empty for a new user.");
        }
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $this->_db->prepare(
            "INSERT INTO users (username, password, email, branch_id) VALUES (?, ?, ?, ?)"
        );
        $stmt->execute([$username, $hashed_password, $email, $branch_id]);
        return $this->_db->lastInsertId();
    }

    /**
     * NEW POWER: Assigns a role to a user.
     * This is a critical function that handles both new assignments and updates
     * by first removing any old roles.
     */
    public function assignRole($user_id, $role) {
        // First, remove any existing roles to ensure a clean slate and prevent duplicates.
        $stmt_delete = $this->_db->prepare("DELETE FROM user_roles WHERE user_id = ?");
        $stmt_delete->execute([$user_id]);

        // Now, assign the new, correct role.
        $stmt_insert = $this->_db->prepare("INSERT INTO user_roles (user_id, role) VALUES (?, ?)");
        $stmt_insert->execute([$user_id, $role]);
        return true;
    }

    /**
     * NEW POWER: Updates a user's details.
     * Intelligently handles optional password changes.
     * @return bool True on success.
     */
    public function update($user_id, $username, $email, $branch_id, $password = null) {
        if (!empty($password)) {
            // If a new password is provided, hash it and include it in the update.
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $this->_db->prepare(
                "UPDATE users SET username = ?, email = ?, branch_id = ?, password = ? WHERE id = ?"
            );
            $stmt->execute([$username, $email, $branch_id, $hashed_password, $user_id]);
        } else {
            // If no password is provided, update everything else.
            $stmt = $this->_db->prepare(
                "UPDATE users SET username = ?, email = ?, branch_id = ? WHERE id = ?"
            );
            $stmt->execute([$username, $email, $branch_id, $user_id]);
        }
        return $stmt->rowCount() > 0;
    }

    /**
     * NEW POWER: Deletes a user and their role assignments.
     * Uses a transaction to ensure complete and clean removal.
     * @return bool True on success.
     */
    public function delete($user_id) {
        // Wrap the deletion in a transaction for data integrity.
        $this->_db->beginTransaction();
        try {
            // First, delete the user's role links from the pivot table.
            $stmt_roles = $this->_db->prepare("DELETE FROM user_roles WHERE user_id = ?");
            $stmt_roles->execute([$user_id]);

            // Then, delete the user from the main table.
            $stmt_user = $this->_db->prepare("DELETE FROM users WHERE id = ?");
            $stmt_user->execute([$user_id]);

            // If all commands succeed, commit the changes.
            $this->_db->commit();
            return true;
        } catch (Exception $e) {
            // If any part fails, roll back all changes to prevent a partial deletion.
            $this->_db->rollBack();
            throw $e; // Re-throw the exception so the calling code knows something went wrong.
        }
    }
}

