<?php
// MONSTROUS GRIMOIRE: This is the complete and definitive helpers.php file.
// It contains all the essential global functions (spells) for the empire.

/**
 * Checks if a user is currently logged in by verifying the session.
 * This is the primary security ward.
 *
 * @return bool True if logged in, false otherwise.
 */
function is_logged_in() {
    return isset($_SESSION['user_id']);
}

/**
 * Gets the role name of a user directly from the database.
 * This is the Gatekeeper's eyes, custom-built for your schema.
 *
 * @param Database $db The database instance.
 * @param int $user_id The ID of the user.
 * @return string|null The role name as a string (e.g., 'Branch Accountant') or null if not found.
 */
function getUserRole(Database $db, $user_id) {
    if (!$user_id) {
        return null;
    }
    // Use the custom query method from the Database class, which is robust.
    $role_data = $db->query("SELECT role FROM user_roles WHERE user_id = ?", [$user_id])->first();

    if ($role_data && isset($role_data->role)) {
        return $role_data->role;
    }

    return null; // Return null if no role is found.
}

/**
 * A powerful spell to get the full user object for the currently logged-in user.
 * It uses a static variable to prevent re-querying the database on the same page load,
 * making the application faster and more efficient.
 *
 * @return object|null The user object or null if not logged in.
 */
function getCurrentUser() {
    static $currentUser = null; // Static variable to cache the user object

    if ($currentUser === null && is_logged_in()) {
        $db = Database::getInstance();
        $user_id = $_SESSION['user_id'];
        $currentUser = $db->get('users', ['id', '=', $user_id])->first();
    }
    
    return $currentUser;
}

/**
 * A vital spell for a multi-branch empire. Fetches branch details by ID.
 * Also uses caching for monstrous efficiency.
 *
 * @param int $branch_id The ID of the branch to fetch.
 * @return object|null The branch object or null if not found.
 */
function getBranchInfo($branch_id) {
    static $branches = []; // Cache for branch info

    if (!$branch_id) {
        return null;
    }

    if (!isset($branches[$branch_id])) {
        $db = Database::getInstance();
        $branches[$branch_id] = $db->get('branches', ['id', '=', $branch_id])->first();
    }

    return $branches[$branch_id];
}

// You can add other global helper functions here as your "Fajracct style" evolves.
// For example, a function to format currency, or to check for specific permissions.

