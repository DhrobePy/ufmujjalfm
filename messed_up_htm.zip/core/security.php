<?php
// MONSTROUSLY HARDENED EDICT: This version is now intelligent enough to detect and break redirect loops.

const ACCESS_LEVELS = [
    'super admin'       => 99,
    'admin'             => 90,
    'hr manager'        => 80,
    'accountant'        => 70,
    'branch accountant' => 20,
    'branch attendant'  => 10,
    'employee'          => 1,
    'guest'             => 0
];

// This map tells the guard where each role *should* go.
const ROLE_DASHBOARDS = [
    'super admin'       => '/hrm.ujjalfm.com/admin/index.php',
    'admin'             => '/hrm.ujjalfm.com/admin/index.php',
    'hr manager'        => '/hrm.ujjalfm.com/admin/index.php',
    'accountant'        => '/hrm.ujjalfm.com/admin/index.php',
    'branch accountant' => '/hrm.ujjalfm.com/admin/dashboard_branch_accountant.php',
    'branch attendant'  => '/hrm.ujjalfm.com/admin/dashboard_branch_attendant.php',
    'employee'          => '/hrm.ujjalfm.com/employee/index.php',
];


function enforce_security($required_level = 1) {
    if (!is_logged_in()) {
        $_SESSION['login_error'] = 'You must be logged in.';
        header('Location: /hrm.ujjalfm.com/auth/login.php');
        exit();
    }

    $db = Database::getInstance();
    $role = getUserRole($db, $_SESSION['user_id']);
    // CRITICAL: Use strtolower to match the keys in our ACCESS_LEVELS map.
    $user_level = ACCESS_LEVELS[strtolower($role ?? 'guest')];
    $user_role_key = strtolower($role ?? 'guest');

    if ($user_level < $required_level) {
        $current_page = $_SERVER['REQUEST_URI'];
        $user_dashboard = ROLE_DASHBOARDS[$user_role_key] ?? '/hrm.ujjalfm.com/auth/login.php';

        // --- THE LOOP BREAKER ---
        // If the user is being rejected from the VERY page they are supposed to be on,
        // it means something is fundamentally wrong (like a data error).
        // To prevent a loop, we must banish them completely.
        if ($current_page === $user_dashboard) {
            session_destroy(); // Total banishment
            header('Location: /hrm.ujjalfm.com/auth/login.php?error=permission_loop');
            exit();
        }

        // Otherwise, send them to their correct home.
        header('Location: ' . $user_dashboard);
        exit();
    }
}

