<?php
require_once __DIR__ . '/core/init.php';

if (is_logged_in()) {
    header('Location: admin/index.php');
    exit();
} else {
    header('Location: auth/login.php');
    exit();
}
?>
