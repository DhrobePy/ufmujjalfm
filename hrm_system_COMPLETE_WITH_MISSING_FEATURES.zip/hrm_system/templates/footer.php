    </div>
</div>
<!-- /#page-content-wrapper -->

</div>
<!-- /#wrapper -->

<script src="../assets/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/employee-search.js"></script>
<script>
// Menu Toggle Script
document.getElementById("menu-toggle").addEventListener("click", function() {
    document.getElementById("wrapper").classList.toggle("toggled");
});
</script>

</body>
</html>
