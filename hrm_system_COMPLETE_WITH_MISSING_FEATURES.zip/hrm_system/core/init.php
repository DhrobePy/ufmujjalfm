<?php
session_start();

// Include configuration
require_once __DIR__ . '/config/config.php';

// Autoload classes
spl_autoload_register(function ($class_name) {
    $file = __DIR__ . '/classes/' . $class_name . '.php';
    if (file_exists($file)) {
        require_once $file;
    }
});

// Include helper functions
require_once __DIR__ . '/functions/helpers.php';

// Get database connection
try {
    $db = Database::getInstance();
    $pdo = $db->getConnection();
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}
?>