<?php
// Database credentials
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'hrm_system');

// Application settings
define('APP_NAME', 'HRM System');
define('APP_URL', 'http://localhost/hrm_system');

// Set timezone
date_default_timezone_set('UTC');
?>
