<?php
class Employee {
    private $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

    public function create($data) {
        $stmt = $this->pdo->prepare(
            'INSERT INTO employees (first_name, last_name, email, phone, address, position_id, hire_date, base_salary, status) '
            . 'VALUES (:first_name, :last_name, :email, :phone, :address, :position_id, :hire_date, :base_salary, :status)'
        );
        return $stmt->execute($data);
    }

    public function get_all() {
        $stmt = $this->pdo->query(
            'SELECT e.*, p.name as position_name, d.name as department_name '
            . 'FROM employees e '
            . 'LEFT JOIN positions p ON e.position_id = p.id '
            . 'LEFT JOIN departments d ON p.department_id = d.id '
            . 'ORDER BY e.first_name ASC'
        );
        return $stmt->fetchAll();
    }

    public function get_by_id($id) {
        $stmt = $this->pdo->prepare('SELECT * FROM employees WHERE id = ?');
        $stmt->execute([$id]);
        return $stmt->fetch();
    }

    public function update($id, $data) {
        $data['id'] = $id;
        $stmt = $this->pdo->prepare(
            'UPDATE employees SET first_name = :first_name, last_name = :last_name, email = :email, phone = :phone, '
            . 'address = :address, position_id = :position_id, hire_date = :hire_date, base_salary = :base_salary, status = :status '
            . 'WHERE id = :id'
        );
        return $stmt->execute($data);
    }

    public function delete($id) {
        $stmt = $this->pdo->prepare('DELETE FROM employees WHERE id = ?');
        return $stmt->execute([$id]);
    }
    
    public function get_departments() {
        $stmt = $this->pdo->query('SELECT * FROM departments ORDER BY name ASC');
        return $stmt->fetchAll();
    }

    public function get_positions() {
        $stmt = $this->pdo->query('SELECT p.*, d.name as department_name FROM positions p JOIN departments d ON p.department_id = d.id ORDER BY d.name, p.name ASC');
        return $stmt->fetchAll();
    }

    public function get_all_active() {
        $stmt = $this->pdo->query(
            "SELECT e.*, d.name as department_name, p.name as position_name FROM employees e "
            . "LEFT JOIN positions p ON e.position_id = p.id "
            . "LEFT JOIN departments d ON p.department_id = d.id WHERE e.status = 'active' ORDER BY e.last_name ASC"
        );
        return $stmt->fetchAll();
    }

    public function add($data) {
        return $this->create($data);
    }
}
?>
