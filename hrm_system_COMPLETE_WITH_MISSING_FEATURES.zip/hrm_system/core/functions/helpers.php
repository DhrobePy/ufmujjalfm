<?php
function sanitize_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

function format_date($date, $format = 'Y-m-d H:i:s') {
    return date($format, strtotime($date));
}

function is_logged_in() {
    return isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true;
}

function is_superadmin() {
    return is_logged_in() && isset($_SESSION['role']) && $_SESSION['role'] === 'superadmin';
}

function is_employee_logged_in() {
    return isset($_SESSION['user_id']) && $_SESSION['role'] === 'employee';
}
?>

function number_to_words($number) {
    $ones = array(
        0 => 'zero', 1 => 'one', 2 => 'two', 3 => 'three', 4 => 'four', 5 => 'five',
        6 => 'six', 7 => 'seven', 8 => 'eight', 9 => 'nine', 10 => 'ten',
        11 => 'eleven', 12 => 'twelve', 13 => 'thirteen', 14 => 'fourteen', 15 => 'fifteen',
        16 => 'sixteen', 17 => 'seventeen', 18 => 'eighteen', 19 => 'nineteen'
    );
    
    $tens = array(
        2 => 'twenty', 3 => 'thirty', 4 => 'forty', 5 => 'fifty',
        6 => 'sixty', 7 => 'seventy', 8 => 'eighty', 9 => 'ninety'
    );
    
    if ($number < 20) {
        return $ones[$number];
    } elseif ($number < 100) {
        return $tens[intval($number / 10)] . ($number % 10 != 0 ? ' ' . $ones[$number % 10] : '');
    } elseif ($number < 1000) {
        return $ones[intval($number / 100)] . ' hundred' . ($number % 100 != 0 ? ' ' . number_to_words($number % 100) : '');
    } elseif ($number < 1000000) {
        return number_to_words(intval($number / 1000)) . ' thousand' . ($number % 1000 != 0 ? ' ' . number_to_words($number % 1000) : '');
    } else {
        return number_to_words(intval($number / 1000000)) . ' million' . ($number % 1000000 != 0 ? ' ' . number_to_words($number % 1000000) : '');
    }
}
