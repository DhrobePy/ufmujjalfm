<?php
require_once __DIR__ . '/../core/init.php';

if (!is_logged_in()) {
    header('Location: ../auth/login.php');
    exit();
}

$employee_handler = new Employee($pdo);
$attendance_handler = new Attendance($pdo);

$total_employees = count($employee_handler->get_all());
$present_today = count($attendance_handler->get_today_attendance());
$on_leave_today = 0; // Simplified for now

$page_title = 'Admin Dashboard';

include __DIR__ . '/../templates/header.php';
include __DIR__ . '/../templates/sidebar.php';
?>

<h1 class="mt-4">Dashboard</h1>

<div class="row">
    <div class="col-xl-3 col-md-6">
        <div class="card bg-primary text-white mb-4">
            <div class="card-body">Total Employees</div>
            <div class="card-footer d-flex align-items-center justify-content-between">
                <span class="huge"><?php echo $total_employees; ?></span>
                <a class="small text-white stretched-link" href="employees.php">View Details</a>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-md-6">
        <div class="card bg-success text-white mb-4">
            <div class="card-body">Present Today</div>
            <div class="card-footer d-flex align-items-center justify-content-between">
                <span class="huge"><?php echo $present_today; ?></span>
                <a class="small text-white stretched-link" href="attendance.php">View Details</a>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-md-6">
        <div class="card bg-warning text-white mb-4">
            <div class="card-body">On Leave</div>
            <div class="card-footer d-flex align-items-center justify-content-between">
                 <span class="huge"><?php echo $on_leave_today; ?></span>
                <a class="small text-white stretched-link" href="leave.php">View Details</a>
            </div>
        </div>
    </div>
</div>

<?php
include __DIR__ . '/../templates/footer.php';
?>
