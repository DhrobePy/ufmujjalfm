<?php
require_once __DIR__ . '/../core/init.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = sanitize_input($_POST['username']);
    $password = sanitize_input($_POST['password']);

    $user = new User($pdo);

    if ($user->login($username, $password)) {
        // Redirect based on role
        if (is_superadmin()) {
            header('Location: ../admin/index.php');
        } else {
            // Redirect to a general employee dashboard if needed in the future
            header('Location: ../admin/index.php');
        }
        exit();
    } else {
        header('Location: login.php?error=Invalid credentials');
        exit();
    }
} else {
    header('Location: login.php');
    exit();
}
?>
