<?php
// Database credentials
define('DB_HOST', 'localhost');
define('DB_USER', 'ujjalfmc_hr');
define('DB_PASS', 'ujjalfmhr1234');
define('DB_NAME', 'ujjalfmc_hr');

// Application settings
define('APP_NAME', 'HRM System');
define('APP_URL', 'http://hrm.ujjalfm.com');
define('APP_VERSION', '2.0.0');

// Set timezone
date_default_timezone_set('Asia/Dhaka');
?>
