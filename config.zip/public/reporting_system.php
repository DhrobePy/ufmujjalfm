<?php
// Reporting System and Document Generation

function renderAttendancePage($db, $employeeId) {
    // Get today's attendance
    $stmt = $db->prepare("SELECT * FROM attendance WHERE employee_id = ? AND DATE(check_in_time) = CURDATE()");
    $stmt->execute([$employeeId]);
    $todayAttendance = $stmt->fetch();
    
    // Get recent attendance
    $stmt = $db->prepare("SELECT * FROM attendance WHERE employee_id = ? ORDER BY check_in_time DESC LIMIT 10");
    $stmt->execute([$employeeId]);
    $recentAttendance = $stmt->fetchAll();
    ?>
    <div class="space-y-6">
        <div class="flex justify-between items-center">
            <h2 class="text-3xl font-bold text-gray-900">Attendance Management</h2>
            <div class="text-sm text-gray-500">
                <i class="fas fa-calendar mr-1"></i><?= date('F j, Y') ?>
            </div>
        </div>

        <?php if (isset($_GET['success'])): ?>
        <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 rounded">
            <i class="fas fa-check-circle mr-2"></i>
            <?php
            switch ($_GET['success']) {
                case 'clock_in': echo 'Successfully clocked in!'; break;
                case 'clock_out': echo 'Successfully clocked out!'; break;
                default: echo 'Operation completed successfully!';
            }
            ?>
        </div>
        <?php endif; ?>

        <!-- Today's Status -->
        <div class="bg-white rounded-xl shadow-lg p-6">
            <h3 class="text-xl font-bold text-gray-900 mb-4">
                <i class="fas fa-clock text-blue-500 mr-2"></i>Today's Attendance
            </h3>
            
            <?php if ($todayAttendance): ?>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div class="bg-green-50 p-4 rounded-lg border border-green-200">
                    <div class="flex items-center">
                        <i class="fas fa-play text-green-600 text-xl mr-3"></i>
                        <div>
                            <p class="text-sm text-green-600">Clock In</p>
                            <p class="text-lg font-bold text-green-800">
                                <?= date('g:i A', strtotime($todayAttendance['check_in_time'])) ?>
                            </p>
                        </div>
                    </div>
                </div>
                
                <?php if ($todayAttendance['check_out_time']): ?>
                <div class="bg-red-50 p-4 rounded-lg border border-red-200">
                    <div class="flex items-center">
                        <i class="fas fa-stop text-red-600 text-xl mr-3"></i>
                        <div>
                            <p class="text-sm text-red-600">Clock Out</p>
                            <p class="text-lg font-bold text-red-800">
                                <?= date('g:i A', strtotime($todayAttendance['check_out_time'])) ?>
                            </p>
                        </div>
                    </div>
                </div>
                
                <div class="bg-blue-50 p-4 rounded-lg border border-blue-200">
                    <div class="flex items-center">
                        <i class="fas fa-clock text-blue-600 text-xl mr-3"></i>
                        <div>
                            <p class="text-sm text-blue-600">Total Hours</p>
                            <p class="text-lg font-bold text-blue-800">
                                <?php
                                $start = new DateTime($todayAttendance['check_in_time']);
                                $end = new DateTime($todayAttendance['check_out_time']);
                                $diff = $start->diff($end);
                                echo $diff->format('%h:%I');
                                ?>
                            </p>
                        </div>
                    </div>
                </div>
                <?php else: ?>
                <div class="bg-yellow-50 p-4 rounded-lg border border-yellow-200">
                    <div class="flex items-center">
                        <i class="fas fa-clock text-yellow-600 text-xl mr-3"></i>
                        <div>
                            <p class="text-sm text-yellow-600">Status</p>
                            <p class="text-lg font-bold text-yellow-800">Still Working</p>
                        </div>
                    </div>
                </div>
                
                <div class="bg-gray-50 p-4 rounded-lg border border-gray-200">
                    <form method="POST" class="w-full">
                        <input type="hidden" name="action" value="clock_out">
                        <button type="submit" class="w-full bg-red-600 text-white py-2 px-4 rounded-lg hover:bg-red-700 transition duration-200">
                            <i class="fas fa-stop mr-2"></i>Clock Out
                        </button>
                    </form>
                </div>
                <?php endif; ?>
            </div>
            <?php else: ?>
            <div class="text-center py-8">
                <i class="fas fa-clock text-gray-400 text-4xl mb-4"></i>
                <p class="text-gray-500 mb-4">You haven't clocked in today</p>
                <form method="POST" class="inline">
                    <input type="hidden" name="action" value="clock_in">
                    <button type="submit" class="bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 transition duration-200">
                        <i class="fas fa-play mr-2"></i>Clock In Now
                    </button>
                </form>
            </div>
            <?php endif; ?>
        </div>

        <!-- Recent Attendance -->
        <div class="bg-white rounded-xl shadow-lg p-6">
            <h3 class="text-xl font-bold text-gray-900 mb-4">
                <i class="fas fa-history text-purple-500 mr-2"></i>Recent Attendance
            </h3>
            
            <?php if (!empty($recentAttendance)): ?>
            <div class="overflow-x-auto">
                <table class="min-w-full">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Date</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Clock In</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Clock Out</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Hours</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-200">
                        <?php foreach ($recentAttendance as $record): ?>
                        <tr class="hover:bg-gray-50">
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                <?= date('M j, Y', strtotime($record['check_in_time'])) ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                <?= date('g:i A', strtotime($record['check_in_time'])) ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                <?= $record['check_out_time'] ? date('g:i A', strtotime($record['check_out_time'])) : '-' ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                <?php
                                if ($record['check_out_time']) {
                                    $start = new DateTime($record['check_in_time']);
                                    $end = new DateTime($record['check_out_time']);
                                    $diff = $start->diff($end);
                                    echo $diff->format('%h:%I');
                                } else {
                                    echo '-';
                                }
                                ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <span class="px-2 py-1 text-xs font-semibold rounded-full 
                                    <?= $record['check_out_time'] ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800' ?>">
                                    <?= $record['check_out_time'] ? 'Complete' : 'In Progress' ?>
                                </span>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
            <div class="text-center py-8">
                <i class="fas fa-calendar-times text-gray-400 text-4xl mb-4"></i>
                <p class="text-gray-500">No attendance records found</p>
            </div>
            <?php endif; ?>
        </div>
    </div>
    <?php
}

function renderLeavePage($db, $employeeId) {
    // Get employee's leave applications
    $stmt = $db->prepare("SELECT * FROM leaves WHERE employee_id = ? ORDER BY created_at DESC");
    $stmt->execute([$employeeId]);
    $leaves = $stmt->fetchAll();
    ?>
    <div class="space-y-6">
        <div class="flex justify-between items-center">
            <h2 class="text-3xl font-bold text-gray-900">Leave Management</h2>
            <button onclick="showLeaveModal()" class="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition duration-200">
                <i class="fas fa-plus mr-2"></i>Apply for Leave
            </button>
        </div>

        <?php if (isset($_GET['success'])): ?>
        <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 rounded">
            <i class="fas fa-check-circle mr-2"></i>Leave application submitted successfully!
        </div>
        <?php endif; ?>

        <!-- Leave Balance -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div class="bg-white p-6 rounded-xl shadow-lg border-l-4 border-green-500">
                <div class="flex items-center">
                    <div class="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                        <i class="fas fa-calendar-check text-green-600 text-xl"></i>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm text-gray-500">Annual Leave</p>
                        <p class="text-2xl font-bold text-gray-900">15 days</p>
                    </div>
                </div>
            </div>
            
            <div class="bg-white p-6 rounded-xl shadow-lg border-l-4 border-blue-500">
                <div class="flex items-center">
                    <div class="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                        <i class="fas fa-user-md text-blue-600 text-xl"></i>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm text-gray-500">Sick Leave</p>
                        <p class="text-2xl font-bold text-gray-900">8 days</p>
                    </div>
                </div>
            </div>
            
            <div class="bg-white p-6 rounded-xl shadow-lg border-l-4 border-purple-500">
                <div class="flex items-center">
                    <div class="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                        <i class="fas fa-calendar-times text-purple-600 text-xl"></i>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm text-gray-500">Used This Year</p>
                        <p class="text-2xl font-bold text-gray-900"><?= count(array_filter($leaves, fn($l) => $l['status'] === 'approved')) ?> days</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Leave Applications -->
        <div class="bg-white rounded-xl shadow-lg p-6">
            <h3 class="text-xl font-bold text-gray-900 mb-4">
                <i class="fas fa-list text-blue-500 mr-2"></i>My Leave Applications
            </h3>
            
            <?php if (!empty($leaves)): ?>
            <div class="space-y-4">
                <?php foreach ($leaves as $leave): ?>
                <div class="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition duration-200">
                    <div class="flex items-center space-x-4">
                        <div class="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                            <i class="fas fa-calendar-times text-blue-600"></i>
                        </div>
                        <div>
                            <p class="font-medium text-gray-900"><?= htmlspecialchars($leave['leave_type']) ?></p>
                            <p class="text-sm text-gray-500">
                                <?= date('M j', strtotime($leave['start_date'])) ?> - <?= date('M j, Y', strtotime($leave['end_date'])) ?>
                            </p>
                            <p class="text-sm text-gray-600"><?= htmlspecialchars($leave['reason']) ?></p>
                        </div>
                    </div>
                    <div class="text-right">
                        <span class="px-3 py-1 text-xs font-semibold rounded-full 
                            <?php
                            switch ($leave['status']) {
                                case 'approved': echo 'bg-green-100 text-green-800'; break;
                                case 'rejected': echo 'bg-red-100 text-red-800'; break;
                                default: echo 'bg-yellow-100 text-yellow-800';
                            }
                            ?>">
                            <?= ucfirst($leave['status']) ?>
                        </span>
                        <p class="text-xs text-gray-400 mt-1">
                            Applied <?= date('M j, Y', strtotime($leave['created_at'])) ?>
                        </p>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <?php else: ?>
            <div class="text-center py-8">
                <i class="fas fa-calendar-times text-gray-400 text-4xl mb-4"></i>
                <p class="text-gray-500">No leave applications found</p>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Leave Application Modal -->
    <div id="leaveModal" class="hidden fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
        <div class="relative top-20 mx-auto p-5 border w-4/5 max-w-2xl shadow-lg rounded-md bg-white">
            <div class="mt-3">
                <h3 class="text-lg font-medium text-gray-900 mb-4">Apply for Leave</h3>
                <form method="POST" class="space-y-4">
                    <input type="hidden" name="action" value="apply_leave">
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Leave Type</label>
                        <select name="leave_type" required class="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2">
                            <option value="">Select Leave Type</option>
                            <option value="Annual Leave">Annual Leave</option>
                            <option value="Sick Leave">Sick Leave</option>
                            <option value="Personal Leave">Personal Leave</option>
                            <option value="Emergency Leave">Emergency Leave</option>
                        </select>
                    </div>
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700">Start Date</label>
                            <input type="date" name="start_date" required class="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700">End Date</label>
                            <input type="date" name="end_date" required class="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2">
                        </div>
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Reason</label>
                        <textarea name="reason" rows="3" required class="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2" placeholder="Please provide reason for leave..."></textarea>
                    </div>
                    
                    <div class="flex justify-end space-x-3 pt-4">
                        <button type="button" onclick="hideLeaveModal()" class="px-4 py-2 bg-gray-300 text-gray-700 rounded-md hover:bg-gray-400">Cancel</button>
                        <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">Submit Application</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        function showLeaveModal() {
            document.getElementById('leaveModal').classList.remove('hidden');
        }
        function hideLeaveModal() {
            document.getElementById('leaveModal').classList.add('hidden');
        }
    </script>
    <?php
}

function renderAdvancePage($db, $employeeId) {
    // Get employee's salary advance applications
    $stmt = $db->prepare("SELECT * FROM salary_advances WHERE employee_id = ? ORDER BY created_at DESC");
    $stmt->execute([$employeeId]);
    $advances = $stmt->fetchAll();
    ?>
    <div class="space-y-6">
        <div class="flex justify-between items-center">
            <h2 class="text-3xl font-bold text-gray-900">Salary Advance</h2>
            <button onclick="showAdvanceModal()" class="bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 transition duration-200">
                <i class="fas fa-plus mr-2"></i>Request Advance
            </button>
        </div>

        <?php if (isset($_GET['success'])): ?>
        <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 rounded">
            <i class="fas fa-check-circle mr-2"></i>Salary advance request submitted successfully!
        </div>
        <?php endif; ?>

        <!-- Advance Summary -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div class="bg-white p-6 rounded-xl shadow-lg border-l-4 border-green-500">
                <div class="flex items-center">
                    <div class="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                        <i class="fas fa-check-circle text-green-600 text-xl"></i>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm text-gray-500">Approved</p>
                        <p class="text-2xl font-bold text-gray-900">
                            $<?= number_format(array_sum(array_column(array_filter($advances, fn($a) => $a['status'] === 'approved'), 'amount'))) ?>
                        </p>
                    </div>
                </div>
            </div>
            
            <div class="bg-white p-6 rounded-xl shadow-lg border-l-4 border-yellow-500">
                <div class="flex items-center">
                    <div class="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
                        <i class="fas fa-clock text-yellow-600 text-xl"></i>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm text-gray-500">Pending</p>
                        <p class="text-2xl font-bold text-gray-900">
                            $<?= number_format(array_sum(array_column(array_filter($advances, fn($a) => $a['status'] === 'pending'), 'amount'))) ?>
                        </p>
                    </div>
                </div>
            </div>
            
            <div class="bg-white p-6 rounded-xl shadow-lg border-l-4 border-blue-500">
                <div class="flex items-center">
                    <div class="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                        <i class="fas fa-calculator text-blue-600 text-xl"></i>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm text-gray-500">Total Requests</p>
                        <p class="text-2xl font-bold text-gray-900"><?= count($advances) ?></p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Advance Applications -->
        <div class="bg-white rounded-xl shadow-lg p-6">
            <h3 class="text-xl font-bold text-gray-900 mb-4">
                <i class="fas fa-list text-green-500 mr-2"></i>My Advance Requests
            </h3>
            
            <?php if (!empty($advances)): ?>
            <div class="space-y-4">
                <?php foreach ($advances as $advance): ?>
                <div class="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition duration-200">
                    <div class="flex items-center space-x-4">
                        <div class="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                            <i class="fas fa-dollar-sign text-green-600"></i>
                        </div>
                        <div>
                            <p class="font-medium text-gray-900">$<?= number_format($advance['amount']) ?></p>
                            <p class="text-sm text-gray-600"><?= htmlspecialchars($advance['reason']) ?></p>
                        </div>
                    </div>
                    <div class="text-right">
                        <span class="px-3 py-1 text-xs font-semibold rounded-full 
                            <?php
                            switch ($advance['status']) {
                                case 'approved': echo 'bg-green-100 text-green-800'; break;
                                case 'rejected': echo 'bg-red-100 text-red-800'; break;
                                default: echo 'bg-yellow-100 text-yellow-800';
                            }
                            ?>">
                            <?= ucfirst($advance['status']) ?>
                        </span>
                        <p class="text-xs text-gray-400 mt-1">
                            Requested <?= date('M j, Y', strtotime($advance['created_at'])) ?>
                        </p>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <?php else: ?>
            <div class="text-center py-8">
                <i class="fas fa-hand-holding-usd text-gray-400 text-4xl mb-4"></i>
                <p class="text-gray-500">No advance requests found</p>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Advance Request Modal -->
    <div id="advanceModal" class="hidden fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
        <div class="relative top-20 mx-auto p-5 border w-4/5 max-w-2xl shadow-lg rounded-md bg-white">
            <div class="mt-3">
                <h3 class="text-lg font-medium text-gray-900 mb-4">Request Salary Advance</h3>
                <form method="POST" class="space-y-4">
                    <input type="hidden" name="action" value="apply_advance">
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Amount</label>
                        <input type="number" name="amount" required min="100" max="5000" class="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2" placeholder="Enter amount">
                        <p class="text-xs text-gray-500 mt-1">Maximum advance: $5,000</p>
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Reason</label>
                        <textarea name="reason" rows="3" required class="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2" placeholder="Please provide reason for advance..."></textarea>
                    </div>
                    
                    <div class="bg-blue-50 p-4 rounded-lg">
                        <h4 class="font-medium text-blue-900 mb-2">Terms & Conditions</h4>
                        <ul class="text-sm text-blue-800 space-y-1">
                            <li>• Advance will be deducted from next salary</li>
                            <li>• Maximum advance is 50% of monthly salary</li>
                            <li>• Processing time: 2-3 business days</li>
                        </ul>
                    </div>
                    
                    <div class="flex justify-end space-x-3 pt-4">
                        <button type="button" onclick="hideAdvanceModal()" class="px-4 py-2 bg-gray-300 text-gray-700 rounded-md hover:bg-gray-400">Cancel</button>
                        <button type="submit" class="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700">Submit Request</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        function showAdvanceModal() {
            document.getElementById('advanceModal').classList.remove('hidden');
        }
        function hideAdvanceModal() {
            document.getElementById('advanceModal').classList.add('hidden');
        }
    </script>
    <?php
}

function renderLoanPage($db, $employeeId) {
    // Get employee's loan applications
    $stmt = $db->prepare("SELECT * FROM loans WHERE employee_id = ? ORDER BY created_at DESC");
    $stmt->execute([$employeeId]);
    $loans = $stmt->fetchAll();
    ?>
    <div class="space-y-6">
        <div class="flex justify-between items-center">
            <h2 class="text-3xl font-bold text-gray-900">Loan Management</h2>
            <button onclick="showLoanModal()" class="bg-purple-600 text-white px-6 py-3 rounded-lg hover:bg-purple-700 transition duration-200">
                <i class="fas fa-plus mr-2"></i>Apply for Loan
            </button>
        </div>

        <?php if (isset($_GET['success'])): ?>
        <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 rounded">
            <i class="fas fa-check-circle mr-2"></i>Loan application submitted successfully!
        </div>
        <?php endif; ?>

        <!-- Loan Summary -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div class="bg-white p-6 rounded-xl shadow-lg border-l-4 border-green-500">
                <div class="flex items-center">
                    <div class="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                        <i class="fas fa-check-circle text-green-600 text-xl"></i>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm text-gray-500">Active Loans</p>
                        <p class="text-2xl font-bold text-gray-900">
                            $<?= number_format(array_sum(array_column(array_filter($loans, fn($l) => $l['status'] === 'approved'), 'amount'))) ?>
                        </p>
                    </div>
                </div>
            </div>
            
            <div class="bg-white p-6 rounded-xl shadow-lg border-l-4 border-yellow-500">
                <div class="flex items-center">
                    <div class="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
                        <i class="fas fa-clock text-yellow-600 text-xl"></i>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm text-gray-500">Pending</p>
                        <p class="text-2xl font-bold text-gray-900">
                            $<?= number_format(array_sum(array_column(array_filter($loans, fn($l) => $l['status'] === 'pending'), 'amount'))) ?>
                        </p>
                    </div>
                </div>
            </div>
            
            <div class="bg-white p-6 rounded-xl shadow-lg border-l-4 border-blue-500">
                <div class="flex items-center">
                    <div class="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                        <i class="fas fa-credit-card text-blue-600 text-xl"></i>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm text-gray-500">Monthly EMI</p>
                        <p class="text-2xl font-bold text-gray-900">
                            $<?= number_format(array_sum(array_column(array_filter($loans, fn($l) => $l['status'] === 'approved'), 'emi_amount'))) ?>
                        </p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Loan Applications -->
        <div class="bg-white rounded-xl shadow-lg p-6">
            <h3 class="text-xl font-bold text-gray-900 mb-4">
                <i class="fas fa-list text-purple-500 mr-2"></i>My Loan Applications
            </h3>
            
            <?php if (!empty($loans)): ?>
            <div class="space-y-4">
                <?php foreach ($loans as $loan): ?>
                <div class="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition duration-200">
                    <div class="flex items-center space-x-4">
                        <div class="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
                            <i class="fas fa-credit-card text-purple-600"></i>
                        </div>
                        <div>
                            <p class="font-medium text-gray-900">$<?= number_format($loan['amount']) ?></p>
                            <p class="text-sm text-gray-500">
                                EMI: $<?= number_format($loan['emi_amount']) ?> x <?= $loan['total_installments'] ?> months
                            </p>
                            <p class="text-sm text-gray-600"><?= htmlspecialchars($loan['reason']) ?></p>
                        </div>
                    </div>
                    <div class="text-right">
                        <span class="px-3 py-1 text-xs font-semibold rounded-full 
                            <?php
                            switch ($loan['status']) {
                                case 'approved': echo 'bg-green-100 text-green-800'; break;
                                case 'rejected': echo 'bg-red-100 text-red-800'; break;
                                default: echo 'bg-yellow-100 text-yellow-800';
                            }
                            ?>">
                            <?= ucfirst($loan['status']) ?>
                        </span>
                        <p class="text-xs text-gray-400 mt-1">
                            Applied <?= date('M j, Y', strtotime($loan['created_at'])) ?>
                        </p>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <?php else: ?>
            <div class="text-center py-8">
                <i class="fas fa-credit-card text-gray-400 text-4xl mb-4"></i>
                <p class="text-gray-500">No loan applications found</p>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Loan Application Modal -->
    <div id="loanModal" class="hidden fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
        <div class="relative top-20 mx-auto p-5 border w-4/5 max-w-2xl shadow-lg rounded-md bg-white">
            <div class="mt-3">
                <h3 class="text-lg font-medium text-gray-900 mb-4">Apply for Loan</h3>
                <form method="POST" class="space-y-4">
                    <input type="hidden" name="action" value="apply_loan">
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Loan Amount</label>
                        <input type="number" name="amount" required min="1000" max="50000" class="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2" placeholder="Enter loan amount">
                        <p class="text-xs text-gray-500 mt-1">Minimum: $1,000 | Maximum: $50,000</p>
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Installments (Months)</label>
                        <select name="installments" required class="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2">
                            <option value="">Select installments</option>
                            <option value="6">6 months</option>
                            <option value="12">12 months</option>
                            <option value="18">18 months</option>
                            <option value="24">24 months</option>
                            <option value="36">36 months</option>
                        </select>
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Purpose</label>
                        <textarea name="reason" rows="3" required class="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2" placeholder="Please provide purpose of loan..."></textarea>
                    </div>
                    
                    <div class="bg-purple-50 p-4 rounded-lg">
                        <h4 class="font-medium text-purple-900 mb-2">Loan Terms</h4>
                        <ul class="text-sm text-purple-800 space-y-1">
                            <li>• Interest rate: 8% per annum</li>
                            <li>• Processing fee: 2% of loan amount</li>
                            <li>• EMI will be deducted from salary</li>
                            <li>• Early repayment allowed without penalty</li>
                        </ul>
                    </div>
                    
                    <div class="flex justify-end space-x-3 pt-4">
                        <button type="button" onclick="hideLoanModal()" class="px-4 py-2 bg-gray-300 text-gray-700 rounded-md hover:bg-gray-400">Cancel</button>
                        <button type="submit" class="px-4 py-2 bg-purple-600 text-white rounded-md hover:bg-purple-700">Submit Application</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        function showLoanModal() {
            document.getElementById('loanModal').classList.remove('hidden');
        }
        function hideLoanModal() {
            document.getElementById('loanModal').classList.add('hidden');
        }
    </script>
    <?php
}

function renderProfilePage($db, $employeeId) {
    // Get employee details
    $stmt = $db->prepare("SELECT e.*, u.email, d.name as department_name FROM employees e JOIN users u ON e.user_id = u.id LEFT JOIN departments d ON e.department_id = d.id WHERE e.id = ?");
    $stmt->execute([$employeeId]);
    $employee = $stmt->fetch();
    ?>
    <div class="space-y-6">
        <div class="flex justify-between items-center">
            <h2 class="text-3xl font-bold text-gray-900">My Profile</h2>
            <button onclick="editProfile()" class="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition duration-200">
                <i class="fas fa-edit mr-2"></i>Edit Profile
            </button>
        </div>

        <!-- Profile Information -->
        <div class="bg-white rounded-xl shadow-lg p-6">
            <div class="flex items-center space-x-6 mb-6">
                <div class="w-24 h-24 bg-blue-100 rounded-full flex items-center justify-center">
                    <i class="fas fa-user text-blue-600 text-4xl"></i>
                </div>
                <div>
                    <h3 class="text-2xl font-bold text-gray-900">
                        <?= htmlspecialchars(($employee['first_name'] ?? '') . ' ' . ($employee['last_name'] ?? '')) ?>
                    </h3>
                    <p class="text-gray-500"><?= htmlspecialchars($employee['department_name'] ?? 'No Department') ?></p>
                    <p class="text-sm text-gray-400">Employee ID: EMP-<?= str_pad($employee['id'], 4, '0', STR_PAD_LEFT) ?></p>
                </div>
            </div>
            
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <h4 class="font-medium text-gray-900 mb-4">Personal Information</h4>
                    <div class="space-y-3">
                        <div>
                            <label class="text-sm text-gray-500">Email</label>
                            <p class="text-gray-900"><?= htmlspecialchars($employee['email'] ?? 'Not provided') ?></p>
                        </div>
                        <div>
                            <label class="text-sm text-gray-500">Phone</label>
                            <p class="text-gray-900"><?= htmlspecialchars($employee['phone'] ?? 'Not provided') ?></p>
                        </div>
                        <div>
                            <label class="text-sm text-gray-500">Date of Birth</label>
                            <p class="text-gray-900">
                                <?= $employee['date_of_birth'] ? date('F j, Y', strtotime($employee['date_of_birth'])) : 'Not provided' ?>
                            </p>
                        </div>
                        <div>
                            <label class="text-sm text-gray-500">Address</label>
                            <p class="text-gray-900"><?= htmlspecialchars($employee['address'] ?? 'Not provided') ?></p>
                        </div>
                    </div>
                </div>
                
                <div>
                    <h4 class="font-medium text-gray-900 mb-4">Employment Information</h4>
                    <div class="space-y-3">
                        <div>
                            <label class="text-sm text-gray-500">Department</label>
                            <p class="text-gray-900"><?= htmlspecialchars($employee['department_name'] ?? 'Not assigned') ?></p>
                        </div>
                        <div>
                            <label class="text-sm text-gray-500">Date of Joining</label>
                            <p class="text-gray-900">
                                <?= $employee['date_of_joining'] ? date('F j, Y', strtotime($employee['date_of_joining'])) : 'Not provided' ?>
                            </p>
                        </div>
                        <div>
                            <label class="text-sm text-gray-500">Employment Status</label>
                            <span class="px-2 py-1 text-xs font-semibold rounded-full 
                                <?= $employee['status'] === 'active' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800' ?>">
                                <?= ucfirst($employee['status'] ?? 'Unknown') ?>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Quick Actions -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div class="bg-white rounded-xl shadow-lg p-6">
                <h3 class="text-lg font-bold text-gray-900 mb-4">
                    <i class="fas fa-file-alt text-blue-500 mr-2"></i>Generate Documents
                </h3>
                <div class="space-y-3">
                    <button onclick="generateDocument('employment')" class="w-full bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition duration-200">
                        <i class="fas fa-certificate mr-2"></i>Employment Certificate
                    </button>
                    <button onclick="generateDocument('salary')" class="w-full bg-green-600 text-white py-2 px-4 rounded-lg hover:bg-green-700 transition duration-200">
                        <i class="fas fa-money-bill-wave mr-2"></i>Salary Certificate
                    </button>
                </div>
            </div>
            
            <div class="bg-white rounded-xl shadow-lg p-6">
                <h3 class="text-lg font-bold text-gray-900 mb-4">
                    <i class="fas fa-cog text-purple-500 mr-2"></i>Account Settings
                </h3>
                <div class="space-y-3">
                    <button onclick="changePassword()" class="w-full bg-purple-600 text-white py-2 px-4 rounded-lg hover:bg-purple-700 transition duration-200">
                        <i class="fas fa-key mr-2"></i>Change Password
                    </button>
                    <button onclick="updateNotifications()" class="w-full bg-gray-600 text-white py-2 px-4 rounded-lg hover:bg-gray-700 transition duration-200">
                        <i class="fas fa-bell mr-2"></i>Notification Settings
                    </button>
                </div>
            </div>
        </div>
    </div>

    <script>
        function editProfile() {
            alert('Edit profile functionality would be implemented here');
        }
        
        function generateDocument(type) {
            alert('Generate ' + type + ' certificate functionality would be implemented here');
        }
        
        function changePassword() {
            alert('Change password functionality would be implemented here');
        }
        
        function updateNotifications() {
            alert('Notification settings functionality would be implemented here');
        }
    </script>
    <?php
}

function renderPayslipPage($db, $employeeId) {
    // Get employee's payslips
    $stmt = $db->prepare("SELECT * FROM payrolls WHERE employee_id = ? ORDER BY year DESC, month DESC LIMIT 12");
    $stmt->execute([$employeeId]);
    $payslips = $stmt->fetchAll();
    ?>
    <div class="space-y-6">
        <div class="flex justify-between items-center">
            <h2 class="text-3xl font-bold text-gray-900">Payslips</h2>
            <button onclick="downloadAllPayslips()" class="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition duration-200">
                <i class="fas fa-download mr-2"></i>Download All
            </button>
        </div>

        <!-- Current Month Payslip -->
        <?php if (!empty($payslips)): ?>
        <div class="bg-white rounded-xl shadow-lg p-6">
            <h3 class="text-xl font-bold text-gray-900 mb-4">
                <i class="fas fa-file-invoice-dollar text-green-500 mr-2"></i>Latest Payslip
            </h3>
            
            <?php $latest = $payslips[0]; ?>
            <div class="bg-gray-50 p-6 rounded-lg">
                <div class="flex justify-between items-start mb-4">
                    <div>
                        <h4 class="text-lg font-bold text-gray-900">
                            <?= date('F Y', mktime(0, 0, 0, $latest['month'], 1, $latest['year'])) ?>
                        </h4>
                        <p class="text-sm text-gray-500">Generated on <?= date('M j, Y', strtotime($latest['created_at'])) ?></p>
                    </div>
                    <button onclick="downloadPayslip(<?= $latest['id'] ?>)" class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition duration-200">
                        <i class="fas fa-download mr-1"></i>Download
                    </button>
                </div>
                
                <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div class="bg-white p-4 rounded-lg">
                        <p class="text-sm text-gray-500">Gross Salary</p>
                        <p class="text-xl font-bold text-gray-900">$<?= number_format($latest['gross_salary'] ?? 0) ?></p>
                    </div>
                    <div class="bg-white p-4 rounded-lg">
                        <p class="text-sm text-gray-500">Deductions</p>
                        <p class="text-xl font-bold text-red-600">-$<?= number_format($latest['deductions'] ?? 0) ?></p>
                    </div>
                    <div class="bg-white p-4 rounded-lg">
                        <p class="text-sm text-gray-500">Net Salary</p>
                        <p class="text-xl font-bold text-green-600">$<?= number_format($latest['net_salary'] ?? 0) ?></p>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <!-- Payslip History -->
        <div class="bg-white rounded-xl shadow-lg p-6">
            <h3 class="text-xl font-bold text-gray-900 mb-4">
                <i class="fas fa-history text-purple-500 mr-2"></i>Payslip History
            </h3>
            
            <?php if (!empty($payslips)): ?>
            <div class="space-y-4">
                <?php foreach ($payslips as $payslip): ?>
                <div class="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition duration-200">
                    <div class="flex items-center space-x-4">
                        <div class="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                            <i class="fas fa-file-invoice-dollar text-green-600"></i>
                        </div>
                        <div>
                            <p class="font-medium text-gray-900">
                                <?= date('F Y', mktime(0, 0, 0, $payslip['month'], 1, $payslip['year'])) ?>
                            </p>
                            <p class="text-sm text-gray-500">
                                Net Salary: $<?= number_format($payslip['net_salary'] ?? 0) ?>
                            </p>
                        </div>
                    </div>
                    <div class="flex items-center space-x-2">
                        <span class="px-3 py-1 text-xs font-semibold rounded-full 
                            <?php
                            switch ($payslip['status']) {
                                case 'disbursed': echo 'bg-green-100 text-green-800'; break;
                                case 'approved': echo 'bg-blue-100 text-blue-800'; break;
                                default: echo 'bg-yellow-100 text-yellow-800';
                            }
                            ?>">
                            <?= ucfirst($payslip['status'] ?? 'pending') ?>
                        </span>
                        <button onclick="viewPayslip(<?= $payslip['id'] ?>)" class="text-blue-600 hover:text-blue-900">
                            <i class="fas fa-eye"></i>
                        </button>
                        <button onclick="downloadPayslip(<?= $payslip['id'] ?>)" class="text-green-600 hover:text-green-900">
                            <i class="fas fa-download"></i>
                        </button>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <?php else: ?>
            <div class="text-center py-8">
                <i class="fas fa-file-invoice-dollar text-gray-400 text-4xl mb-4"></i>
                <p class="text-gray-500">No payslips available</p>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <script>
        function viewPayslip(payslipId) {
            alert('View payslip functionality would be implemented here for ID: ' + payslipId);
        }
        
        function downloadPayslip(payslipId) {
            alert('Download payslip functionality would be implemented here for ID: ' + payslipId);
        }
        
        function downloadAllPayslips() {
            alert('Download all payslips functionality would be implemented here');
        }
    </script>
    <?php
}

// Accounts module functions
function renderAccountsDashboard($stats) {
    ?>
    <div class="space-y-6">
        <div class="flex justify-between items-center">
            <h2 class="text-3xl font-bold text-gray-900">Accounts Dashboard</h2>
            <div class="text-sm text-gray-500">
                <i class="fas fa-calendar mr-1"></i><?= date('F j, Y') ?>
            </div>
        </div>
        
        <!-- Stats Cards -->
        <div class="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div class="bg-gradient-to-r from-green-500 to-green-600 p-6 rounded-xl shadow-lg text-white">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-green-100 text-sm">Payroll Pending</p>
                        <p class="text-3xl font-bold"><?= $stats['payroll_pending'] ?></p>
                    </div>
                    <i class="fas fa-clock text-4xl text-green-200"></i>
                </div>
            </div>
            
            <div class="bg-gradient-to-r from-blue-500 to-blue-600 p-6 rounded-xl shadow-lg text-white">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-blue-100 text-sm">Total Expenses</p>
                        <p class="text-3xl font-bold">$<?= number_format($stats['total_expenses']) ?></p>
                    </div>
                    <i class="fas fa-money-bill-wave text-4xl text-blue-200"></i>
                </div>
            </div>
            
            <div class="bg-gradient-to-r from-purple-500 to-purple-600 p-6 rounded-xl shadow-lg text-white">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-purple-100 text-sm">Employees Paid</p>
                        <p class="text-3xl font-bold"><?= $stats['employees_paid'] ?></p>
                    </div>
                    <i class="fas fa-users text-4xl text-purple-200"></i>
                </div>
            </div>
            
            <div class="bg-gradient-to-r from-yellow-500 to-yellow-600 p-6 rounded-xl shadow-lg text-white">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-yellow-100 text-sm">This Month</p>
                        <p class="text-3xl font-bold">$<?= number_format($stats['total_expenses']) ?></p>
                    </div>
                    <i class="fas fa-calculator text-4xl text-yellow-200"></i>
                </div>
            </div>
        </div>

        <!-- Quick Actions -->
        <div class="bg-white rounded-xl shadow-lg p-6">
            <h3 class="text-xl font-bold text-gray-900 mb-4">Quick Actions</h3>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                <a href="?page=payroll" class="bg-blue-600 text-white p-4 rounded-lg hover:bg-blue-700 transition duration-200 text-center">
                    <i class="fas fa-money-bill-wave text-2xl mb-2"></i>
                    <p class="font-medium">Generate Payroll</p>
                </a>
                <a href="?page=salary_structure" class="bg-green-600 text-white p-4 rounded-lg hover:bg-green-700 transition duration-200 text-center">
                    <i class="fas fa-cogs text-2xl mb-2"></i>
                    <p class="font-medium">Salary Structure</p>
                </a>
                <a href="?page=reports" class="bg-purple-600 text-white p-4 rounded-lg hover:bg-purple-700 transition duration-200 text-center">
                    <i class="fas fa-chart-bar text-2xl mb-2"></i>
                    <p class="font-medium">Financial Reports</p>
                </a>
            </div>
        </div>
    </div>
    <?php
}

function renderAccountsPayroll($db) {
    ?>
    <div class="space-y-6">
        <div class="flex justify-between items-center">
            <h2 class="text-3xl font-bold text-gray-900">Payroll Management</h2>
            <button onclick="generateBulkPayroll()" class="bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 transition duration-200">
                <i class="fas fa-plus mr-2"></i>Generate Bulk Payroll
            </button>
        </div>

        <!-- Payroll Generation Form -->
        <div class="bg-white rounded-xl shadow-lg p-6">
            <h3 class="text-xl font-bold text-gray-900 mb-4">Generate Payroll</h3>
            <form method="POST" class="space-y-4">
                <input type="hidden" name="action" value="generate_bulk_payroll">
                
                <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Month</label>
                        <select name="month" required class="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2">
                            <?php for ($i = 1; $i <= 12; $i++): ?>
                            <option value="<?= $i ?>" <?= $i == date('n') ? 'selected' : '' ?>>
                                <?= date('F', mktime(0, 0, 0, $i, 1)) ?>
                            </option>
                            <?php endfor; ?>
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Year</label>
                        <select name="year" required class="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2">
                            <?php for ($i = date('Y') - 1; $i <= date('Y') + 1; $i++): ?>
                            <option value="<?= $i ?>" <?= $i == date('Y') ? 'selected' : '' ?>><?= $i ?></option>
                            <?php endfor; ?>
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Department</label>
                        <select name="department" class="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2">
                            <option value="">All Departments</option>
                            <option value="1">Human Resources</option>
                            <option value="2">Finance</option>
                            <option value="3">IT</option>
                        </select>
                    </div>
                </div>
                
                <button type="submit" class="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition duration-200">
                    <i class="fas fa-calculator mr-2"></i>Generate Payroll
                </button>
            </form>
        </div>

        <!-- Payroll Summary -->
        <div class="bg-white rounded-xl shadow-lg p-6">
            <h3 class="text-xl font-bold text-gray-900 mb-4">Payroll Summary</h3>
            <p class="text-gray-500">Detailed payroll management interface would be implemented here with employee-wise payroll generation, approval workflows, and disbursement tracking.</p>
        </div>
    </div>

    <script>
        function generateBulkPayroll() {
            alert('Bulk payroll generation functionality would be implemented here');
        }
    </script>
    <?php
}

function renderSalaryStructure($db) {
    ?>
    <div class="space-y-6">
        <div class="flex justify-between items-center">
            <h2 class="text-3xl font-bold text-gray-900">Salary Structure</h2>
            <button onclick="addSalaryStructure()" class="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition duration-200">
                <i class="fas fa-plus mr-2"></i>Add Structure
            </button>
        </div>

        <!-- Salary Structure Management -->
        <div class="bg-white rounded-xl shadow-lg p-6">
            <h3 class="text-xl font-bold text-gray-900 mb-4">Manage Salary Structures</h3>
            <p class="text-gray-500">Comprehensive salary structure management interface would be implemented here with grade-wise salary configuration, allowances, deductions, and tax calculations.</p>
        </div>
    </div>

    <script>
        function addSalaryStructure() {
            alert('Add salary structure functionality would be implemented here');
        }
    </script>
    <?php
}

function renderTransactions($db) {
    ?>
    <div class="space-y-6">
        <div class="flex justify-between items-center">
            <h2 class="text-3xl font-bold text-gray-900">Transactions</h2>
            <button onclick="addTransaction()" class="bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 transition duration-200">
                <i class="fas fa-plus mr-2"></i>Add Transaction
            </button>
        </div>

        <!-- Transaction Management -->
        <div class="bg-white rounded-xl shadow-lg p-6">
            <h3 class="text-xl font-bold text-gray-900 mb-4">Transaction History</h3>
            <p class="text-gray-500">Complete transaction management interface would be implemented here with expense tracking, payment records, and financial reporting.</p>
        </div>
    </div>

    <script>
        function addTransaction() {
            alert('Add transaction functionality would be implemented here');
        }
    </script>
    <?php
}

function renderAccountsReports($db) {
    ?>
    <div class="space-y-6">
        <div class="flex justify-between items-center">
            <h2 class="text-3xl font-bold text-gray-900">Financial Reports</h2>
            <button onclick="generateReport()" class="bg-purple-600 text-white px-6 py-3 rounded-lg hover:bg-purple-700 transition duration-200">
                <i class="fas fa-chart-bar mr-2"></i>Generate Report
            </button>
        </div>

        <!-- Financial Reports -->
        <div class="bg-white rounded-xl shadow-lg p-6">
            <h3 class="text-xl font-bold text-gray-900 mb-4">Financial Analytics</h3>
            <p class="text-gray-500">Comprehensive financial reporting interface would be implemented here with payroll analytics, expense reports, budget analysis, and financial dashboards.</p>
        </div>
    </div>

    <script>
        function generateReport() {
            alert('Generate financial report functionality would be implemented here');
        }
    </script>
    <?php
}
?>
