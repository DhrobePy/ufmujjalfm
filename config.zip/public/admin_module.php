<?php
// Admin Module Functions - Complete Implementation

function renderApprovalsPage($db, $pendingApprovals) {
    // Get detailed pending approvals with additional information
    $leaveApprovals = [];
    $advanceApprovals = [];
    $loanApprovals = [];
    $payrollApprovals = [];
    
    try {
        // Get pending leaves with details
        $stmt = $db->prepare("SELECT l.*, e.first_name, e.last_name, d.name as department_name FROM leaves l JOIN employees e ON l.employee_id = e.id LEFT JOIN departments d ON e.department_id = d.id WHERE l.status = 'pending' ORDER BY l.created_at ASC");
        $stmt->execute();
        $leaveApprovals = $stmt->fetchAll();
        
        // Get pending salary advances
        $stmt = $db->prepare("SELECT sa.*, e.first_name, e.last_name, d.name as department_name FROM salary_advances sa JOIN employees e ON sa.employee_id = e.id LEFT JOIN departments d ON e.department_id = d.id WHERE sa.status = 'pending' ORDER BY sa.created_at ASC");
        $stmt->execute();
        $advanceApprovals = $stmt->fetchAll();
        
        // Get pending loans
        $stmt = $db->prepare("SELECT l.*, e.first_name, e.last_name, d.name as department_name FROM loans l JOIN employees e ON l.employee_id = e.id LEFT JOIN departments d ON e.department_id = d.id WHERE l.status = 'pending' ORDER BY l.created_at ASC");
        $stmt->execute();
        $loanApprovals = $stmt->fetchAll();
        
        // Get pending payrolls
        $stmt = $db->prepare("SELECT p.*, e.first_name, e.last_name, d.name as department_name FROM payrolls p JOIN employees e ON p.employee_id = e.id LEFT JOIN departments d ON e.department_id = d.id WHERE p.status = 'approved' ORDER BY p.created_at ASC");
        $stmt->execute();
        $payrollApprovals = $stmt->fetchAll();
        
    } catch (PDOException $e) {
        // Handle error silently
    }
    ?>
    <div class="space-y-6">
        <div class="flex justify-between items-center">
            <h2 class="text-3xl font-bold text-gray-900">Approval Management</h2>
            <div class="flex space-x-2">
                <button onclick="approveAll('leave')" class="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700">
                    <i class="fas fa-check-double mr-2"></i>Approve All Leaves
                </button>
                <button onclick="showBulkApprovalModal()" class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">
                    <i class="fas fa-tasks mr-2"></i>Bulk Actions
                </button>
            </div>
        </div>

        <?php if (isset($_GET['success'])): ?>
        <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 rounded">
            <i class="fas fa-check-circle mr-2"></i>Approval action completed successfully!
        </div>
        <?php endif; ?>

        <!-- Approval Summary -->
        <div class="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div class="bg-white p-6 rounded-xl shadow-lg border-l-4 border-blue-500">
                <div class="flex items-center">
                    <div class="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                        <i class="fas fa-calendar-times text-blue-600 text-xl"></i>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm text-gray-500">Pending Leaves</p>
                        <p class="text-2xl font-bold text-gray-900"><?= count($leaveApprovals) ?></p>
                    </div>
                </div>
            </div>
            
            <div class="bg-white p-6 rounded-xl shadow-lg border-l-4 border-green-500">
                <div class="flex items-center">
                    <div class="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                        <i class="fas fa-hand-holding-usd text-green-600 text-xl"></i>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm text-gray-500">Salary Advances</p>
                        <p class="text-2xl font-bold text-gray-900"><?= count($advanceApprovals) ?></p>
                    </div>
                </div>
            </div>
            
            <div class="bg-white p-6 rounded-xl shadow-lg border-l-4 border-purple-500">
                <div class="flex items-center">
                    <div class="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                        <i class="fas fa-credit-card text-purple-600 text-xl"></i>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm text-gray-500">Loan Requests</p>
                        <p class="text-2xl font-bold text-gray-900"><?= count($loanApprovals) ?></p>
                    </div>
                </div>
            </div>
            
            <div class="bg-white p-6 rounded-xl shadow-lg border-l-4 border-yellow-500">
                <div class="flex items-center">
                    <div class="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
                        <i class="fas fa-money-bill-wave text-yellow-600 text-xl"></i>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm text-gray-500">Payroll Disbursals</p>
                        <p class="text-2xl font-bold text-gray-900"><?= count($payrollApprovals) ?></p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Leave Approvals -->
        <?php if (!empty($leaveApprovals)): ?>
        <div class="bg-white rounded-xl shadow-lg p-6">
            <h3 class="text-xl font-bold text-gray-900 mb-4">
                <i class="fas fa-calendar-times text-blue-500 mr-2"></i>Leave Approvals
            </h3>
            <div class="space-y-4">
                <?php foreach ($leaveApprovals as $leave): ?>
                <div class="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition duration-200">
                    <div class="flex items-center space-x-4">
                        <div class="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                            <i class="fas fa-user text-blue-600"></i>
                        </div>
                        <div>
                            <p class="font-medium text-gray-900">
                                <?= htmlspecialchars($leave['first_name'] . ' ' . $leave['last_name']) ?>
                            </p>
                            <p class="text-sm text-gray-500">
                                <?= htmlspecialchars($leave['department_name'] ?: 'No Department') ?>
                            </p>
                            <p class="text-sm text-gray-600">
                                <strong><?= htmlspecialchars($leave['leave_type']) ?></strong> - 
                                <?= date('M j', strtotime($leave['start_date'])) ?> to <?= date('M j, Y', strtotime($leave['end_date'])) ?>
                            </p>
                            <p class="text-sm text-gray-500">
                                Reason: <?= htmlspecialchars($leave['reason']) ?>
                            </p>
                        </div>
                    </div>
                    <div class="flex items-center space-x-2">
                        <span class="text-xs text-gray-400">
                            Applied <?= date('M j, Y', strtotime($leave['created_at'])) ?>
                        </span>
                        <form method="POST" class="inline">
                            <input type="hidden" name="action" value="approve_leave">
                            <input type="hidden" name="id" value="<?= $leave['id'] ?>">
                            <input type="hidden" name="status" value="approved">
                            <button type="submit" class="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition duration-200">
                                <i class="fas fa-check mr-1"></i>Approve
                            </button>
                        </form>
                        <form method="POST" class="inline">
                            <input type="hidden" name="action" value="approve_leave">
                            <input type="hidden" name="id" value="<?= $leave['id'] ?>">
                            <input type="hidden" name="status" value="rejected">
                            <button type="submit" class="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition duration-200">
                                <i class="fas fa-times mr-1"></i>Reject
                            </button>
                        </form>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>

        <!-- Salary Advance Approvals -->
        <?php if (!empty($advanceApprovals)): ?>
        <div class="bg-white rounded-xl shadow-lg p-6">
            <h3 class="text-xl font-bold text-gray-900 mb-4">
                <i class="fas fa-hand-holding-usd text-green-500 mr-2"></i>Salary Advance Approvals
            </h3>
            <div class="space-y-4">
                <?php foreach ($advanceApprovals as $advance): ?>
                <div class="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition duration-200">
                    <div class="flex items-center space-x-4">
                        <div class="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                            <i class="fas fa-dollar-sign text-green-600"></i>
                        </div>
                        <div>
                            <p class="font-medium text-gray-900">
                                <?= htmlspecialchars($advance['first_name'] . ' ' . $advance['last_name']) ?>
                            </p>
                            <p class="text-sm text-gray-500">
                                <?= htmlspecialchars($advance['department_name'] ?: 'No Department') ?>
                            </p>
                            <p class="text-sm text-gray-600">
                                <strong>Amount: $<?= number_format($advance['amount']) ?></strong>
                            </p>
                            <p class="text-sm text-gray-500">
                                Reason: <?= htmlspecialchars($advance['reason']) ?>
                            </p>
                        </div>
                    </div>
                    <div class="flex items-center space-x-2">
                        <span class="text-xs text-gray-400">
                            Applied <?= date('M j, Y', strtotime($advance['created_at'])) ?>
                        </span>
                        <form method="POST" class="inline">
                            <input type="hidden" name="action" value="approve_advance">
                            <input type="hidden" name="id" value="<?= $advance['id'] ?>">
                            <input type="hidden" name="status" value="approved">
                            <button type="submit" class="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition duration-200">
                                <i class="fas fa-check mr-1"></i>Approve
                            </button>
                        </form>
                        <form method="POST" class="inline">
                            <input type="hidden" name="action" value="approve_advance">
                            <input type="hidden" name="id" value="<?= $advance['id'] ?>">
                            <input type="hidden" name="status" value="rejected">
                            <button type="submit" class="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition duration-200">
                                <i class="fas fa-times mr-1"></i>Reject
                            </button>
                        </form>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>

        <!-- Loan Approvals -->
        <?php if (!empty($loanApprovals)): ?>
        <div class="bg-white rounded-xl shadow-lg p-6">
            <h3 class="text-xl font-bold text-gray-900 mb-4">
                <i class="fas fa-credit-card text-purple-500 mr-2"></i>Loan Approvals
            </h3>
            <div class="space-y-4">
                <?php foreach ($loanApprovals as $loan): ?>
                <div class="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition duration-200">
                    <div class="flex items-center space-x-4">
                        <div class="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
                            <i class="fas fa-credit-card text-purple-600"></i>
                        </div>
                        <div>
                            <p class="font-medium text-gray-900">
                                <?= htmlspecialchars($loan['first_name'] . ' ' . $loan['last_name']) ?>
                            </p>
                            <p class="text-sm text-gray-500">
                                <?= htmlspecialchars($loan['department_name'] ?: 'No Department') ?>
                            </p>
                            <p class="text-sm text-gray-600">
                                <strong>Amount: $<?= number_format($loan['amount']) ?></strong> - 
                                EMI: $<?= number_format($loan['emi_amount']) ?> x <?= $loan['total_installments'] ?> months
                            </p>
                            <p class="text-sm text-gray-500">
                                Reason: <?= htmlspecialchars($loan['reason']) ?>
                            </p>
                        </div>
                    </div>
                    <div class="flex items-center space-x-2">
                        <span class="text-xs text-gray-400">
                            Applied <?= date('M j, Y', strtotime($loan['created_at'])) ?>
                        </span>
                        <form method="POST" class="inline">
                            <input type="hidden" name="action" value="approve_loan">
                            <input type="hidden" name="id" value="<?= $loan['id'] ?>">
                            <input type="hidden" name="status" value="approved">
                            <button type="submit" class="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition duration-200">
                                <i class="fas fa-check mr-1"></i>Approve
                            </button>
                        </form>
                        <form method="POST" class="inline">
                            <input type="hidden" name="action" value="approve_loan">
                            <input type="hidden" name="id" value="<?= $loan['id'] ?>">
                            <input type="hidden" name="status" value="rejected">
                            <button type="submit" class="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition duration-200">
                                <i class="fas fa-times mr-1"></i>Reject
                            </button>
                        </form>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>

        <!-- Payroll Disbursals -->
        <?php if (!empty($payrollApprovals)): ?>
        <div class="bg-white rounded-xl shadow-lg p-6">
            <h3 class="text-xl font-bold text-gray-900 mb-4">
                <i class="fas fa-money-bill-wave text-yellow-500 mr-2"></i>Payroll Disbursals
            </h3>
            <div class="space-y-4">
                <?php foreach ($payrollApprovals as $payroll): ?>
                <div class="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition duration-200">
                    <div class="flex items-center space-x-4">
                        <div class="w-12 h-12 bg-yellow-100 rounded-full flex items-center justify-center">
                            <i class="fas fa-money-bill-wave text-yellow-600"></i>
                        </div>
                        <div>
                            <p class="font-medium text-gray-900">
                                <?= htmlspecialchars($payroll['first_name'] . ' ' . $payroll['last_name']) ?>
                            </p>
                            <p class="text-sm text-gray-500">
                                <?= htmlspecialchars($payroll['department_name'] ?: 'No Department') ?>
                            </p>
                            <p class="text-sm text-gray-600">
                                <strong><?= date('F Y', mktime(0, 0, 0, $payroll['month'], 1, $payroll['year'])) ?></strong> - 
                                Net Salary: $<?= number_format($payroll['net_salary']) ?>
                            </p>
                        </div>
                    </div>
                    <div class="flex items-center space-x-2">
                        <span class="text-xs text-gray-400">
                            Generated <?= date('M j, Y', strtotime($payroll['created_at'])) ?>
                        </span>
                        <form method="POST" class="inline">
                            <input type="hidden" name="action" value="approve_payroll">
                            <input type="hidden" name="id" value="<?= $payroll['id'] ?>">
                            <input type="hidden" name="status" value="disbursed">
                            <button type="submit" class="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition duration-200">
                                <i class="fas fa-check mr-1"></i>Disburse
                            </button>
                        </form>
                        <button onclick="viewPayrollDetails(<?= $payroll['id'] ?>)" class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition duration-200">
                            <i class="fas fa-eye mr-1"></i>View
                        </button>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>

        <!-- No Pending Approvals -->
        <?php if (empty($leaveApprovals) && empty($advanceApprovals) && empty($loanApprovals) && empty($payrollApprovals)): ?>
        <div class="bg-white rounded-xl shadow-lg p-12 text-center">
            <div class="w-24 h-24 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <i class="fas fa-check-circle text-green-600 text-4xl"></i>
            </div>
            <h3 class="text-2xl font-bold text-gray-900 mb-2">All Caught Up!</h3>
            <p class="text-gray-500 mb-6">No pending approvals at this time. Great job staying on top of things!</p>
            <div class="flex justify-center space-x-4">
                <a href="?page=employees" class="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition duration-200">
                    <i class="fas fa-users mr-2"></i>Manage Employees
                </a>
                <a href="?page=reports" class="bg-purple-600 text-white px-6 py-3 rounded-lg hover:bg-purple-700 transition duration-200">
                    <i class="fas fa-chart-bar mr-2"></i>View Reports
                </a>
            </div>
        </div>
        <?php endif; ?>
    </div>

    <script>
        function approveAll(type) {
            if (confirm('Are you sure you want to approve all ' + type + ' requests?')) {
                // Implementation for bulk approval
                alert('Bulk approval feature would be implemented here');
            }
        }
        
        function showBulkApprovalModal() {
            alert('Bulk approval modal would be implemented here');
        }
        
        function viewPayrollDetails(payrollId) {
            alert('Payroll details modal would be implemented here for ID: ' + payrollId);
        }
    </script>
    <?php
}

function renderEmployeesManagement($db) {
    // Get all employees with their details
    $stmt = $db->prepare("SELECT e.*, u.email, d.name as department_name FROM employees e JOIN users u ON e.user_id = u.id LEFT JOIN departments d ON e.department_id = d.id ORDER BY e.created_at DESC");
    $stmt->execute();
    $employees = $stmt->fetchAll();
    
    // Get departments for dropdown
    $stmt = $db->prepare("SELECT * FROM departments ORDER BY name");
    $stmt->execute();
    $departments = $stmt->fetchAll();
    
    // Handle employee actions
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        switch ($_POST['action']) {
            case 'add_employee':
                handleAddEmployee($db);
                break;
            case 'update_employee':
                handleUpdateEmployee($db);
                break;
            case 'deactivate_employee':
                handleDeactivateEmployee($db, $_POST['employee_id']);
                break;
        }
    }
    ?>
    <div class="space-y-6">
        <div class="flex justify-between items-center">
            <h2 class="text-3xl font-bold text-gray-900">Employee Management</h2>
            <div class="flex space-x-2">
                <button onclick="showAddEmployeeModal()" class="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition duration-200">
                    <i class="fas fa-plus mr-2"></i>Add Employee
                </button>
                <button onclick="showBulkImportModal()" class="bg-green-600 text-white px-4 py-3 rounded-lg hover:bg-green-700 transition duration-200">
                    <i class="fas fa-upload mr-2"></i>Bulk Import
                </button>
            </div>
        </div>

        <?php if (isset($_GET['success'])): ?>
        <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 rounded">
            <i class="fas fa-check-circle mr-2"></i>
            <?php
            switch ($_GET['success']) {
                case 'added': echo 'Employee added successfully!'; break;
                case 'updated': echo 'Employee updated successfully!'; break;
                case 'deactivated': echo 'Employee deactivated successfully!'; break;
                default: echo 'Operation completed successfully!';
            }
            ?>
        </div>
        <?php endif; ?>

        <!-- Employee Statistics -->
        <div class="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div class="bg-white p-6 rounded-xl shadow-lg border-l-4 border-blue-500">
                <div class="flex items-center">
                    <div class="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                        <i class="fas fa-users text-blue-600 text-xl"></i>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm text-gray-500">Total Employees</p>
                        <p class="text-2xl font-bold text-gray-900"><?= count($employees) ?></p>
                    </div>
                </div>
            </div>
            
            <div class="bg-white p-6 rounded-xl shadow-lg border-l-4 border-green-500">
                <div class="flex items-center">
                    <div class="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                        <i class="fas fa-user-check text-green-600 text-xl"></i>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm text-gray-500">Active</p>
                        <p class="text-2xl font-bold text-gray-900"><?= count(array_filter($employees, fn($e) => $e['status'] === 'active')) ?></p>
                    </div>
                </div>
            </div>
            
            <div class="bg-white p-6 rounded-xl shadow-lg border-l-4 border-yellow-500">
                <div class="flex items-center">
                    <div class="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
                        <i class="fas fa-user-clock text-yellow-600 text-xl"></i>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm text-gray-500">Inactive</p>
                        <p class="text-2xl font-bold text-gray-900"><?= count(array_filter($employees, fn($e) => $e['status'] === 'inactive')) ?></p>
                    </div>
                </div>
            </div>
            
            <div class="bg-white p-6 rounded-xl shadow-lg border-l-4 border-purple-500">
                <div class="flex items-center">
                    <div class="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                        <i class="fas fa-building text-purple-600 text-xl"></i>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm text-gray-500">Departments</p>
                        <p class="text-2xl font-bold text-gray-900"><?= count($departments) ?></p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Search and Filter -->
        <div class="bg-white rounded-xl shadow-lg p-6">
            <div class="flex flex-wrap items-center justify-between gap-4">
                <div class="flex items-center space-x-4">
                    <div class="relative">
                        <input type="text" id="searchEmployee" placeholder="Search employees..." class="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                        <i class="fas fa-search absolute left-3 top-3 text-gray-400"></i>
                    </div>
                    <select id="filterDepartment" class="border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500">
                        <option value="">All Departments</option>
                        <?php foreach ($departments as $dept): ?>
                        <option value="<?= htmlspecialchars($dept['name']) ?>"><?= htmlspecialchars($dept['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                    <select id="filterStatus" class="border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500">
                        <option value="">All Status</option>
                        <option value="active">Active</option>
                        <option value="inactive">Inactive</option>
                        <option value="terminated">Terminated</option>
                    </select>
                </div>
                <div class="flex space-x-2">
                    <button onclick="exportEmployees()" class="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700">
                        <i class="fas fa-download mr-2"></i>Export
                    </button>
                    <button onclick="clearFilters()" class="bg-gray-600 text-white px-4 py-2 rounded-lg hover:bg-gray-700">
                        <i class="fas fa-times mr-2"></i>Clear
                    </button>
                </div>
            </div>
        </div>

        <!-- Employees Table -->
        <div class="bg-white rounded-xl shadow-lg overflow-hidden">
            <div class="overflow-x-auto">
                <table class="min-w-full" id="employeesTable">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Employee</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Department</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Contact</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Joining Date</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php foreach ($employees as $employee): ?>
                        <tr class="hover:bg-gray-50 transition duration-200">
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="flex items-center">
                                    <div class="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                                        <i class="fas fa-user text-blue-600"></i>
                                    </div>
                                    <div class="ml-4">
                                        <div class="text-sm font-medium text-gray-900">
                                            <?= htmlspecialchars($employee['first_name'] . ' ' . $employee['last_name']) ?>
                                        </div>
                                        <div class="text-sm text-gray-500">
                                            ID: EMP-<?= str_pad($employee['id'], 4, '0', STR_PAD_LEFT) ?>
                                        </div>
                                    </div>
                                </div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                <?= htmlspecialchars($employee['department_name'] ?: 'No Department') ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="text-sm text-gray-900"><?= htmlspecialchars($employee['email']) ?></div>
                                <div class="text-sm text-gray-500"><?= htmlspecialchars($employee['phone'] ?: 'No phone') ?></div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                <?= $employee['date_of_joining'] ? date('M j, Y', strtotime($employee['date_of_joining'])) : 'Not set' ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <span class="px-2 py-1 text-xs font-semibold rounded-full 
                                    <?php
                                    switch ($employee['status']) {
                                        case 'active': echo 'bg-green-100 text-green-800'; break;
                                        case 'inactive': echo 'bg-yellow-100 text-yellow-800'; break;
                                        case 'terminated': echo 'bg-red-100 text-red-800'; break;
                                    }
                                    ?>">
                                    <?= ucfirst($employee['status']) ?>
                                </span>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                <div class="flex space-x-2">
                                    <button onclick="viewEmployee(<?= htmlspecialchars(json_encode($employee)) ?>)" class="text-blue-600 hover:text-blue-900">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                    <button onclick="editEmployee(<?= htmlspecialchars(json_encode($employee)) ?>)" class="text-green-600 hover:text-green-900">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <?php if ($employee['status'] === 'active'): ?>
                                    <button onclick="deactivateEmployee(<?= $employee['id'] ?>)" class="text-red-600 hover:text-red-900">
                                        <i class="fas fa-user-times"></i>
                                    </button>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Add Employee Modal -->
    <div id="addEmployeeModal" class="hidden fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
        <div class="relative top-20 mx-auto p-5 border w-4/5 max-w-2xl shadow-lg rounded-md bg-white">
            <div class="mt-3">
                <h3 class="text-lg font-medium text-gray-900 mb-4">Add New Employee</h3>
                <form method="POST" class="space-y-4">
                    <input type="hidden" name="action" value="add_employee">
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700">First Name</label>
                            <input type="text" name="first_name" required class="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700">Last Name</label>
                            <input type="text" name="last_name" required class="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2">
                        </div>
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Email</label>
                        <input type="email" name="email" required class="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2">
                    </div>
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700">Phone</label>
                            <input type="text" name="phone" class="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700">Department</label>
                            <select name="department_id" class="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2">
                                <option value="">Select Department</option>
                                <?php foreach ($departments as $dept): ?>
                                <option value="<?= $dept['id'] ?>"><?= htmlspecialchars($dept['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700">Date of Birth</label>
                            <input type="date" name="date_of_birth" class="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700">Date of Joining</label>
                            <input type="date" name="date_of_joining" class="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2">
                        </div>
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Address</label>
                        <textarea name="address" rows="3" class="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2"></textarea>
                    </div>
                    
                    <div class="flex justify-end space-x-3 pt-4">
                        <button type="button" onclick="hideAddEmployeeModal()" class="px-4 py-2 bg-gray-300 text-gray-700 rounded-md hover:bg-gray-400">Cancel</button>
                        <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">Add Employee</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        function showAddEmployeeModal() {
            document.getElementById('addEmployeeModal').classList.remove('hidden');
        }
        function hideAddEmployeeModal() {
            document.getElementById('addEmployeeModal').classList.add('hidden');
        }
        
        function viewEmployee(employee) {
            alert('Employee details modal would be implemented here for: ' + employee.first_name + ' ' + employee.last_name);
        }
        
        function editEmployee(employee) {
            alert('Edit employee modal would be implemented here for: ' + employee.first_name + ' ' + employee.last_name);
        }
        
        function deactivateEmployee(employeeId) {
            if (confirm('Are you sure you want to deactivate this employee?')) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.innerHTML = `
                    <input type="hidden" name="action" value="deactivate_employee">
                    <input type="hidden" name="employee_id" value="${employeeId}">
                `;
                document.body.appendChild(form);
                form.submit();
            }
        }
        
        function exportEmployees() {
            alert('Export functionality would be implemented here');
        }
        
        function clearFilters() {
            document.getElementById('searchEmployee').value = '';
            document.getElementById('filterDepartment').value = '';
            document.getElementById('filterStatus').value = '';
            // Reset table display
        }
        
        function showBulkImportModal() {
            alert('Bulk import modal would be implemented here');
        }
        
        // Search and filter functionality
        document.getElementById('searchEmployee').addEventListener('input', filterEmployees);
        document.getElementById('filterDepartment').addEventListener('change', filterEmployees);
        document.getElementById('filterStatus').addEventListener('change', filterEmployees);
        
        function filterEmployees() {
            const search = document.getElementById('searchEmployee').value.toLowerCase();
            const department = document.getElementById('filterDepartment').value;
            const status = document.getElementById('filterStatus').value;
            const rows = document.querySelectorAll('#employeesTable tbody tr');
            
            rows.forEach(row => {
                const text = row.textContent.toLowerCase();
                const matchesSearch = text.includes(search);
                const matchesDepartment = !department || text.includes(department.toLowerCase());
                const matchesStatus = !status || text.includes(status);
                
                row.style.display = matchesSearch && matchesDepartment && matchesStatus ? '' : 'none';
            });
        }
    </script>
    <?php
}

function renderPayrollManagement($db) {
    // Get payroll summary
    $stmt = $db->prepare("SELECT p.*, e.first_name, e.last_name, d.name as department_name FROM payrolls p JOIN employees e ON p.employee_id = e.id LEFT JOIN departments d ON e.department_id = d.id ORDER BY p.created_at DESC LIMIT 50");
    $stmt->execute();
    $payrolls = $stmt->fetchAll();
    
    // Get payroll statistics
    $stmt = $db->prepare("SELECT status, COUNT(*) as count, SUM(net_salary) as total FROM payrolls WHERE MONTH(created_at) = MONTH(CURDATE()) AND YEAR(created_at) = YEAR(CURDATE()) GROUP BY status");
    $stmt->execute();
    $stats = $stmt->fetchAll(PDO::FETCH_GROUP | PDO::FETCH_UNIQUE);
    ?>
    <div class="space-y-6">
        <div class="flex justify-between items-center">
            <h2 class="text-3xl font-bold text-gray-900">Payroll Management</h2>
            <div class="flex space-x-2">
                <a href="?page=payroll&role=accounts" class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">
                    <i class="fas fa-cog mr-2"></i>Accounts View
                </a>
                <button onclick="generatePayrollReport()" class="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700">
                    <i class="fas fa-file-alt mr-2"></i>Generate Report
                </button>
            </div>
        </div>

        <!-- Payroll Statistics -->
        <div class="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div class="bg-white p-6 rounded-xl shadow-lg border-l-4 border-yellow-500">
                <div class="flex items-center">
                    <div class="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
                        <i class="fas fa-clock text-yellow-600 text-xl"></i>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm text-gray-500">Pending</p>
                        <p class="text-2xl font-bold text-gray-900"><?= $stats['pending']['count'] ?? 0 ?></p>
                        <p class="text-xs text-gray-400">$<?= number_format($stats['pending']['total'] ?? 0) ?></p>
                    </div>
                </div>
            </div>
            
            <div class="bg-white p-6 rounded-xl shadow-lg border-l-4 border-blue-500">
                <div class="flex items-center">
                    <div class="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                        <i class="fas fa-check text-blue-600 text-xl"></i>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm text-gray-500">Approved</p>
                        <p class="text-2xl font-bold text-gray-900"><?= $stats['approved']['count'] ?? 0 ?></p>
                        <p class="text-xs text-gray-400">$<?= number_format($stats['approved']['total'] ?? 0) ?></p>
                    </div>
                </div>
            </div>
            
            <div class="bg-white p-6 rounded-xl shadow-lg border-l-4 border-green-500">
                <div class="flex items-center">
                    <div class="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                        <i class="fas fa-money-bill-wave text-green-600 text-xl"></i>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm text-gray-500">Disbursed</p>
                        <p class="text-2xl font-bold text-gray-900"><?= $stats['disbursed']['count'] ?? 0 ?></p>
                        <p class="text-xs text-gray-400">$<?= number_format($stats['disbursed']['total'] ?? 0) ?></p>
                    </div>
                </div>
            </div>
            
            <div class="bg-white p-6 rounded-xl shadow-lg border-l-4 border-purple-500">
                <div class="flex items-center">
                    <div class="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                        <i class="fas fa-calculator text-purple-600 text-xl"></i>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm text-gray-500">Total Amount</p>
                        <p class="text-2xl font-bold text-gray-900">
                            $<?= number_format(array_sum(array_column($stats, 'total'))) ?>
                        </p>
                        <p class="text-xs text-gray-400">This month</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Payroll Overview -->
        <div class="bg-white rounded-xl shadow-lg p-6">
            <h3 class="text-xl font-bold text-gray-900 mb-4">Payroll Overview</h3>
            <p class="text-gray-500">Detailed payroll management interface with approval workflows, disbursement tracking, and comprehensive reporting would be implemented here.</p>
        </div>
    </div>

    <script>
        function generatePayrollReport() {
            alert('Payroll report generation would be implemented here');
        }
    </script>
    <?php
}

function renderReportsPage($db) {
    ?>
    <div class="space-y-6">
        <div class="flex justify-between items-center">
            <h2 class="text-3xl font-bold text-gray-900">Reports & Analytics</h2>
            <div class="flex space-x-2">
                <button class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">
                    <i class="fas fa-download mr-2"></i>Export All
                </button>
                <button class="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700">
                    <i class="fas fa-calendar mr-2"></i>Schedule Report
                </button>
            </div>
        </div>

        <!-- Report Categories -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div class="bg-white p-6 rounded-xl shadow-lg hover:shadow-xl transition duration-200">
                <div class="flex items-center mb-4">
                    <div class="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                        <i class="fas fa-users text-blue-600 text-xl"></i>
                    </div>
                    <h3 class="text-lg font-bold text-gray-900 ml-4">Employee Reports</h3>
                </div>
                <ul class="space-y-2 text-sm text-gray-600">
                    <li><i class="fas fa-chevron-right mr-2"></i>Employee Directory</li>
                    <li><i class="fas fa-chevron-right mr-2"></i>Department Analysis</li>
                    <li><i class="fas fa-chevron-right mr-2"></i>Performance Metrics</li>
                    <li><i class="fas fa-chevron-right mr-2"></i>Attendance Summary</li>
                </ul>
                <button class="mt-4 w-full bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700">
                    Generate Reports
                </button>
            </div>
            
            <div class="bg-white p-6 rounded-xl shadow-lg hover:shadow-xl transition duration-200">
                <div class="flex items-center mb-4">
                    <div class="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                        <i class="fas fa-money-bill-wave text-green-600 text-xl"></i>
                    </div>
                    <h3 class="text-lg font-bold text-gray-900 ml-4">Financial Reports</h3>
                </div>
                <ul class="space-y-2 text-sm text-gray-600">
                    <li><i class="fas fa-chevron-right mr-2"></i>Payroll Summary</li>
                    <li><i class="fas fa-chevron-right mr-2"></i>Expense Analysis</li>
                    <li><i class="fas fa-chevron-right mr-2"></i>Budget vs Actual</li>
                    <li><i class="fas fa-chevron-right mr-2"></i>Cost Center Reports</li>
                </ul>
                <button class="mt-4 w-full bg-green-600 text-white py-2 rounded-lg hover:bg-green-700">
                    Generate Reports
                </button>
            </div>
            
            <div class="bg-white p-6 rounded-xl shadow-lg hover:shadow-xl transition duration-200">
                <div class="flex items-center mb-4">
                    <div class="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                        <i class="fas fa-chart-bar text-purple-600 text-xl"></i>
                    </div>
                    <h3 class="text-lg font-bold text-gray-900 ml-4">Analytics</h3>
                </div>
                <ul class="space-y-2 text-sm text-gray-600">
                    <li><i class="fas fa-chevron-right mr-2"></i>Trend Analysis</li>
                    <li><i class="fas fa-chevron-right mr-2"></i>Predictive Insights</li>
                    <li><i class="fas fa-chevron-right mr-2"></i>Compliance Reports</li>
                    <li><i class="fas fa-chevron-right mr-2"></i>Custom Dashboards</li>
                </ul>
                <button class="mt-4 w-full bg-purple-600 text-white py-2 rounded-lg hover:bg-purple-700">
                    Generate Reports
                </button>
            </div>
        </div>

        <!-- Recent Reports -->
        <div class="bg-white rounded-xl shadow-lg p-6">
            <h3 class="text-xl font-bold text-gray-900 mb-4">Recent Reports</h3>
            <div class="space-y-4">
                <div class="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                    <div class="flex items-center space-x-4">
                        <div class="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                            <i class="fas fa-file-alt text-blue-600"></i>
                        </div>
                        <div>
                            <p class="font-medium text-gray-900">Monthly Payroll Report - <?= date('F Y') ?></p>
                            <p class="text-sm text-gray-500">Generated on <?= date('M j, Y g:i A') ?></p>
                        </div>
                    </div>
                    <div class="flex space-x-2">
                        <button class="text-blue-600 hover:text-blue-900">
                            <i class="fas fa-download"></i>
                        </button>
                        <button class="text-green-600 hover:text-green-900">
                            <i class="fas fa-share"></i>
                        </button>
                    </div>
                </div>
                
                <div class="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                    <div class="flex items-center space-x-4">
                        <div class="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                            <i class="fas fa-chart-line text-green-600"></i>
                        </div>
                        <div>
                            <p class="font-medium text-gray-900">Employee Attendance Analysis</p>
                            <p class="text-sm text-gray-500">Generated on <?= date('M j, Y g:i A', strtotime('-1 day')) ?></p>
                        </div>
                    </div>
                    <div class="flex space-x-2">
                        <button class="text-blue-600 hover:text-blue-900">
                            <i class="fas fa-download"></i>
                        </button>
                        <button class="text-green-600 hover:text-green-900">
                            <i class="fas fa-share"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php
}

// Helper functions for admin module
function handleAddEmployee($db) {
    try {
        $db->beginTransaction();
        
        // Create user account
        $hashedPassword = password_hash('password', PASSWORD_DEFAULT);
        $stmt = $db->prepare("INSERT INTO users (email, password, role, is_active, created_at) VALUES (?, ?, 'employee', 1, NOW())");
        $stmt->execute([$_POST['email'], $hashedPassword]);
        $userId = $db->lastInsertId();
        
        // Create employee record
        $stmt = $db->prepare("INSERT INTO employees (user_id, department_id, first_name, last_name, phone, address, date_of_birth, date_of_joining, status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'active', NOW())");
        $stmt->execute([
            $userId,
            $_POST['department_id'] ?: null,
            $_POST['first_name'],
            $_POST['last_name'],
            $_POST['phone'],
            $_POST['address'],
            $_POST['date_of_birth'] ?: null,
            $_POST['date_of_joining'] ?: null
        ]);
        
        $db->commit();
        header('Location: ?page=employees&success=added');
        exit;
    } catch (PDOException $e) {
        $db->rollBack();
        header('Location: ?page=employees&error=add_failed');
        exit;
    }
}

function handleUpdateEmployee($db) {
    // Implementation for updating employee
    header('Location: ?page=employees&success=updated');
    exit;
}

function handleDeactivateEmployee($db, $employeeId) {
    try {
        $stmt = $db->prepare("UPDATE employees SET status = 'inactive' WHERE id = ?");
        $stmt->execute([$employeeId]);
        header('Location: ?page=employees&success=deactivated');
        exit;
    } catch (PDOException $e) {
        header('Location: ?page=employees&error=deactivate_failed');
        exit;
    }
}
?>
