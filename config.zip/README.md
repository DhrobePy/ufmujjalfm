# HR Management System

A comprehensive PHP-based Human Resources Management System built with TailwindCSS for modern, responsive design. This system is designed for mid-level companies with up to 150 employees and provides complete HR functionality including employee self-service, accounts management, and administrative oversight.

## Features

### Employee Self-Service Portal
- **Attendance Management**: Clock in/out, view attendance history
- **Leave Applications**: Apply for various types of leave, track status
- **Salary Advances**: Request salary advances with approval workflow
- **Loan Applications**: Apply for loans with EMI calculations
- **Profile Management**: Update personal information and view employment details
- **Document Generation**: Generate employment certificates, salary certificates, and payslips
- **Payslip Access**: View and download monthly payslips

### Accounts Management Module
- **Salary Structure Management**: Set up and modify employee salary components
- **Attendance Reports**: Generate comprehensive attendance reports (individual/bulk, date/month filters)
- **Payroll Processing**: Generate payroll for specific employees or bulk processing
- **Advanced Filtering**: Filter by branch, department, designation
- **Employee Search**: Search functionality across multiple criteria
- **Payroll Approval Workflow**: Submit payroll for admin approval
- **Transaction Management**: Maintain all HR-related financial transactions
- **Financial Reporting**: Generate detailed financial reports

### Admin Dashboard & Controls
- **Comprehensive Dashboard**: Overview of all HR and financial information
- **Employee Management**: Add, update, and manage employee profiles
- **Approval Workflows**: Approve/reject payroll, leave, salary advances, and loans
- **Transaction Oversight**: Monitor all financial transactions
- **Advanced Reporting**: Generate comprehensive reports across all modules
- **System Administration**: Manage departments, designations, branches, and system settings

## Technology Stack

- **Backend**: PHP 8.0+ with custom MVC framework
- **Frontend**: TailwindCSS for responsive design
- **Database**: MySQL 8.0+
- **PDF Generation**: DomPDF for document generation
- **Architecture**: RESTful API design with clean separation of concerns

## Installation

### Prerequisites
- PHP 8.0 or higher
- MySQL 8.0 or higher
- Composer
- Web server (Apache/Nginx) or PHP built-in server

### Setup Instructions

1. **Clone or download the project**
   ```bash
   git clone <repository-url>
   cd hr_management_app
   ```

2. **Install dependencies**
   ```bash
   composer install
   ```

3. **Configure environment**
   ```bash
   cp .env.example .env
   ```
   
   Edit `.env` file with your database credentials:
   ```
   DB_HOST=localhost
   DB_NAME=hr_management
   DB_USER=your_username
   DB_PASS=your_password
   APP_DEBUG=true
   APP_ENV=development
   ```

4. **Create database and import schema**
   ```bash
   mysql -u root -p -e "CREATE DATABASE hr_management;"
   mysql -u root -p hr_management < database/schema.sql
   ```

5. **Import demo data (optional)**
   ```bash
   mysql -u root -p hr_management < demo_data.sql
   ```

6. **Start the application**
   ```bash
   php -S localhost:8000 -t public/
   ```

7. **Access the application**
   Open your browser and navigate to `http://localhost:8000`

## Default Login Credentials

After importing demo data, you can use these credentials:

- **Admin**: admin@company.com / password
- **Accounts**: accounts@company.com / password  
- **Employee**: john.doe@company.com / password

## Project Structure

```
hr_management_app/
├── public/                 # Web root directory
│   └── index.php          # Application entry point
├── src/                   # Source code
│   ├── controllers/       # Web and API controllers
│   ├── models/           # Data models
│   ├── views/            # View templates
│   └── core/             # Core framework classes
├── database/             # Database files
│   └── schema.sql        # Database schema
├── config/               # Configuration files
├── vendor/               # Composer dependencies
├── .env                  # Environment configuration
└── composer.json         # PHP dependencies
```

## API Endpoints

The system provides a comprehensive REST API for all functionality:

### Authentication
- `POST /api/auth/login` - User login
- `POST /api/auth/logout` - User logout
- `GET /api/auth/me` - Get current user info

### Employee APIs
- `GET /api/employee/profile` - Get employee profile
- `PUT /api/employee/profile` - Update employee profile
- `POST /api/employee/attendance` - Mark attendance
- `GET /api/employee/attendance` - Get attendance records
- `POST /api/employee/leave` - Apply for leave
- `GET /api/employee/leaves` - Get leave applications
- `POST /api/employee/salary-advance` - Apply for salary advance
- `POST /api/employee/loan` - Apply for loan
- `GET /api/employee/payslips` - Get payslips

### Accounts APIs
- `POST /api/accounts/salary-structure` - Set salary structure
- `GET /api/accounts/attendance-report` - Generate attendance reports
- `POST /api/accounts/payroll` - Generate payroll
- `GET /api/accounts/transactions` - Get transactions
- `POST /api/accounts/transaction` - Add transaction

### Admin APIs
- `GET /api/admin/dashboard` - Get dashboard data
- `GET /api/admin/employees` - Get all employees
- `POST /api/admin/employee` - Add new employee
- `PUT /api/admin/employee/{id}` - Update employee
- `POST /api/admin/approve-payroll` - Approve payroll
- `POST /api/admin/approve-leave` - Approve leave
- `GET /api/admin/approvals` - Get pending approvals

## Key Features

### Responsive Design
- Mobile-first approach with TailwindCSS
- Adaptive layouts for desktop, tablet, and mobile
- Modern UI with smooth animations and transitions

### Security
- Password hashing with bcrypt
- Session-based authentication
- Role-based access control
- SQL injection prevention with prepared statements

### Reporting & Documents
- PDF generation for certificates and payslips
- Comprehensive reporting with filtering options
- Export functionality for data analysis

### Workflow Management
- Multi-level approval processes
- Status tracking for all applications
- Email notifications (configurable)

## Database Schema

The system uses a normalized database design with the following key tables:

- `users` - User authentication and roles
- `employees` - Employee personal and professional information
- `departments` - Organizational departments
- `designations` - Job positions and levels
- `branches` - Company locations
- `attendance` - Daily attendance records
- `leaves` - Leave applications and approvals
- `salary_structures` - Employee salary components
- `salary_advances` - Salary advance requests
- `loans` - Employee loan applications
- `payrolls` - Monthly payroll records
- `transactions` - Financial transactions

## Customization

The system is built with modularity in mind and can be easily customized:

1. **Adding new modules**: Create new controllers and models following the existing pattern
2. **Modifying UI**: Update TailwindCSS classes in view templates
3. **Custom reports**: Add new report types in the ReportController
4. **Workflow changes**: Modify approval processes in respective controllers

## Support

For technical support or feature requests, please refer to the system documentation or contact the development team.

## License

This project is proprietary software. All rights reserved.
