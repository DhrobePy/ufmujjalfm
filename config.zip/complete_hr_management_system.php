<?php
/**
 * Complete Professional HR Management System
 * 
 * Features:
 * - Admin: Complete approval workflows, employee management, payroll oversight
 * - Accounts: Payroll generation, salary structure, financial management
 * - Employee: Self-service portal with attendance, leave, advance, loan applications
 * 
 * Author: Manus AI
 * Version: 1.0
 */

session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Load environment variables
if (file_exists(__DIR__ . '/.env')) {
    $lines = file(__DIR__ . '/.env', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        if (strpos(trim($line), '#') === 0 || strpos($line, '=') === false) continue;
        list($name, $value) = explode('=', $line, 2);
        $_ENV[trim($name)] = trim($value);
        putenv(trim($name) . '=' . trim($value));
    }
}

date_default_timezone_set('UTC');

// Database connection
try {
    $host = $_ENV['DB_HOST'] ?? 'localhost';
    $dbname = $_ENV['DB_NAME'] ?? 'hr_management';
    $username = $_ENV['DB_USER'] ?? 'root';
    $password = $_ENV['DB_PASS'] ?? '';
    
    $dsn = "mysql:host=$host;dbname=$dbname;charset=utf8mb4";
    $db = new PDO($dsn, $username, $password, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
    
    // Create tables if they don't exist
    createTablesIfNotExist($db);
    
} catch (PDOException $e) {
    die('<h1>Database Connection Error</h1><p>' . $e->getMessage() . '</p>');
}

// Handle logout
if (isset($_GET['logout'])) {
    session_destroy();
    header('Location: ' . $_SERVER['PHP_SELF'] . '?logged_out=1');
    exit;
}

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    switch ($action) {
        case 'login':
            handleLogin($db);
            break;
        case 'apply_leave':
            handleLeaveApplication($db);
            break;
        case 'apply_advance':
            handleAdvanceApplication($db);
            break;
        case 'apply_loan':
            handleLoanApplication($db);
            break;
        case 'approve_leave':
            handleApproval($db, 'leaves', $_POST['id'], $_POST['status']);
            break;
        case 'approve_advance':
            handleApproval($db, 'salary_advances', $_POST['id'], $_POST['status']);
            break;
        case 'approve_loan':
            handleApproval($db, 'loans', $_POST['id'], $_POST['status']);
            break;
        case 'approve_payroll':
            handlePayrollApproval($db, $_POST['id'], $_POST['status']);
            break;
        case 'generate_bulk_payroll':
            handleBulkPayrollGeneration($db);
            break;
        case 'update_salary_structure':
            handleSalaryStructureUpdate($db);
            break;
        case 'add_employee':
            handleAddEmployee($db);
            break;
        case 'clock_in':
            handleClockIn($db);
            break;
        case 'clock_out':
            handleClockOut($db);
            break;
    }
}

// Get current page and user role
$page = $_GET['page'] ?? 'dashboard';
$role = $_SESSION['user_role'] ?? null;

// Check authentication
if (!isset($_SESSION['user_id'])) {
    showLoginPage();
} else {
    // Route based on role
    switch ($role) {
        case 'admin':
            showAdminInterface($db, $page);
            break;
        case 'accounts':
            showAccountsInterface($db, $page);
            break;
        case 'employee':
            showEmployeeInterface($db, $page);
            break;
        default:
            showLoginPage();
    }
}

function createTablesIfNotExist($db) {
    $tables = [
        'users' => "CREATE TABLE IF NOT EXISTS users (
            id INT AUTO_INCREMENT PRIMARY KEY,
            email VARCHAR(255) UNIQUE NOT NULL,
            password VARCHAR(255) NOT NULL,
            role ENUM('admin', 'accounts', 'employee') NOT NULL,
            is_active BOOLEAN DEFAULT TRUE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )",
        'departments' => "CREATE TABLE IF NOT EXISTS departments (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(255) NOT NULL,
            description TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )",
        'employees' => "CREATE TABLE IF NOT EXISTS employees (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT,
            department_id INT,
            first_name VARCHAR(255),
            last_name VARCHAR(255),
            phone VARCHAR(20),
            address TEXT,
            date_of_birth DATE,
            date_of_joining DATE,
            status ENUM('active', 'inactive', 'terminated') DEFAULT 'active',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id),
            FOREIGN KEY (department_id) REFERENCES departments(id)
        )",
        'attendance' => "CREATE TABLE IF NOT EXISTS attendance (
            id INT AUTO_INCREMENT PRIMARY KEY,
            employee_id INT,
            check_in_time TIMESTAMP,
            check_out_time TIMESTAMP NULL,
            status ENUM('present', 'absent', 'late') DEFAULT 'present',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (employee_id) REFERENCES employees(id)
        )",
        'leaves' => "CREATE TABLE IF NOT EXISTS leaves (
            id INT AUTO_INCREMENT PRIMARY KEY,
            employee_id INT,
            leave_type VARCHAR(100),
            start_date DATE,
            end_date DATE,
            reason TEXT,
            status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
            approved_by INT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (employee_id) REFERENCES employees(id),
            FOREIGN KEY (approved_by) REFERENCES users(id)
        )",
        'salary_advances' => "CREATE TABLE IF NOT EXISTS salary_advances (
            id INT AUTO_INCREMENT PRIMARY KEY,
            employee_id INT,
            amount DECIMAL(10,2),
            reason TEXT,
            status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
            approved_by INT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (employee_id) REFERENCES employees(id),
            FOREIGN KEY (approved_by) REFERENCES users(id)
        )",
        'loans' => "CREATE TABLE IF NOT EXISTS loans (
            id INT AUTO_INCREMENT PRIMARY KEY,
            employee_id INT,
            amount DECIMAL(10,2),
            emi_amount DECIMAL(10,2),
            total_installments INT,
            paid_installments INT DEFAULT 0,
            reason TEXT,
            status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
            approved_by INT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (employee_id) REFERENCES employees(id),
            FOREIGN KEY (approved_by) REFERENCES users(id)
        )",
        'payrolls' => "CREATE TABLE IF NOT EXISTS payrolls (
            id INT AUTO_INCREMENT PRIMARY KEY,
            employee_id INT,
            month INT,
            year INT,
            gross_salary DECIMAL(10,2),
            deductions DECIMAL(10,2),
            net_salary DECIMAL(10,2),
            status ENUM('pending', 'approved', 'disbursed') DEFAULT 'pending',
            approved_by INT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (employee_id) REFERENCES employees(id),
            FOREIGN KEY (approved_by) REFERENCES users(id)
        )"
    ];
    
    foreach ($tables as $table => $sql) {
        try {
            $db->exec($sql);
        } catch (PDOException $e) {
            // Table might already exist, continue
        }
    }
}

function showLoginPage() {
    $message = isset($_GET['logged_out']) ? 'You have been logged out successfully.' : '';
    $error = $_GET['error'] ?? '';
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>HR Management System - Login</title>
        <script src="https://cdn.tailwindcss.com"></script>
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
        <style>
            .gradient-bg { 
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                position: relative;
                overflow: hidden;
            }
            .gradient-bg::before {
                content: '';
                position: absolute;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><defs><pattern id="grain" width="100" height="100" patternUnits="userSpaceOnUse"><circle cx="25" cy="25" r="1" fill="white" opacity="0.1"/><circle cx="75" cy="75" r="1" fill="white" opacity="0.1"/><circle cx="50" cy="10" r="0.5" fill="white" opacity="0.1"/><circle cx="10" cy="60" r="0.5" fill="white" opacity="0.1"/><circle cx="90" cy="40" r="0.5" fill="white" opacity="0.1"/></pattern></defs><rect width="100" height="100" fill="url(%23grain)"/></svg>');
            }
            .glass-effect { 
                background: rgba(255, 255, 255, 0.15); 
                backdrop-filter: blur(20px); 
                border: 1px solid rgba(255, 255, 255, 0.2);
                box-shadow: 0 25px 45px rgba(0, 0, 0, 0.1);
            }
            .floating { animation: floating 6s ease-in-out infinite; }
            .floating-delayed { animation: floating 6s ease-in-out infinite 2s; }
            .floating-slow { animation: floating 8s ease-in-out infinite 1s; }
            @keyframes floating { 
                0%, 100% { transform: translateY(0px) rotate(0deg); } 
                33% { transform: translateY(-20px) rotate(1deg); }
                66% { transform: translateY(-10px) rotate(-1deg); }
            }
            .pulse-glow { animation: pulse-glow 3s ease-in-out infinite; }
            @keyframes pulse-glow {
                0%, 100% { box-shadow: 0 0 20px rgba(255, 255, 255, 0.3); }
                50% { box-shadow: 0 0 40px rgba(255, 255, 255, 0.5); }
            }
            .slide-in { animation: slide-in 0.8s ease-out; }
            @keyframes slide-in {
                from { opacity: 0; transform: translateY(30px); }
                to { opacity: 1; transform: translateY(0); }
            }
        </style>
    </head>
    <body class="gradient-bg min-h-screen flex items-center justify-center p-4">
        <!-- Floating Background Elements -->
        <div class="absolute inset-0 overflow-hidden pointer-events-none">
            <div class="absolute -top-40 -right-40 w-80 h-80 bg-white opacity-5 rounded-full floating"></div>
            <div class="absolute -bottom-40 -left-40 w-96 h-96 bg-white opacity-3 rounded-full floating-delayed"></div>
            <div class="absolute top-1/4 left-1/4 w-32 h-32 bg-white opacity-4 rounded-full floating-slow"></div>
            <div class="absolute bottom-1/4 right-1/4 w-24 h-24 bg-white opacity-6 rounded-full floating"></div>
        </div>

        <div class="relative z-10 w-full max-w-md slide-in">
            <!-- Header -->
            <div class="text-center mb-8">
                <div class="inline-flex items-center justify-center w-24 h-24 glass-effect rounded-full mb-6 pulse-glow floating">
                    <i class="fas fa-building text-4xl text-white"></i>
                </div>
                <h1 class="text-5xl font-bold text-white mb-3 tracking-tight">HR Management</h1>
                <p class="text-white text-opacity-90 text-lg">Professional Human Resource Solution</p>
                <div class="w-24 h-1 bg-white bg-opacity-30 mx-auto mt-4 rounded-full"></div>
            </div>

            <!-- Login Form -->
            <div class="glass-effect rounded-3xl p-8 shadow-2xl">
                <?php if ($message): ?>
                <div class="bg-green-500 bg-opacity-20 border border-green-400 border-opacity-30 text-green-100 p-4 mb-6 rounded-xl backdrop-blur-sm">
                    <div class="flex items-center">
                        <i class="fas fa-check-circle mr-3 text-green-300"></i>
                        <span><?= htmlspecialchars($message) ?></span>
                    </div>
                </div>
                <?php endif; ?>
                
                <?php if ($error): ?>
                <div class="bg-red-500 bg-opacity-20 border border-red-400 border-opacity-30 text-red-100 p-4 mb-6 rounded-xl backdrop-blur-sm">
                    <div class="flex items-center">
                        <i class="fas fa-exclamation-circle mr-3 text-red-300"></i>
                        <span><?= $error === 'invalid_credentials' ? 'Invalid email or password.' : 'An error occurred.' ?></span>
                    </div>
                </div>
                <?php endif; ?>

                <form method="POST" class="space-y-6">
                    <input type="hidden" name="action" value="login">
                    
                    <div class="space-y-2">
                        <label class="block text-white text-sm font-medium">
                            <i class="fas fa-envelope mr-2 text-white text-opacity-70"></i>Email Address
                        </label>
                        <input type="email" name="email" required 
                               class="w-full px-4 py-4 bg-white bg-opacity-10 border border-white border-opacity-20 rounded-xl text-white placeholder-white placeholder-opacity-60 focus:outline-none focus:ring-2 focus:ring-white focus:ring-opacity-50 focus:border-transparent transition duration-300"
                               placeholder="Enter your email address">
                    </div>
                    
                    <div class="space-y-2">
                        <label class="block text-white text-sm font-medium">
                            <i class="fas fa-lock mr-2 text-white text-opacity-70"></i>Password
                        </label>
                        <div class="relative">
                            <input type="password" name="password" required id="password"
                                   class="w-full px-4 py-4 bg-white bg-opacity-10 border border-white border-opacity-20 rounded-xl text-white placeholder-white placeholder-opacity-60 focus:outline-none focus:ring-2 focus:ring-white focus:ring-opacity-50 focus:border-transparent transition duration-300"
                                   placeholder="Enter your password">
                            <button type="button" onclick="togglePassword()" class="absolute right-4 top-4 text-white text-opacity-70 hover:text-opacity-100 transition duration-200">
                                <i class="fas fa-eye" id="toggleIcon"></i>
                            </button>
                        </div>
                    </div>

                    <button type="submit" 
                            class="w-full bg-white bg-opacity-20 hover:bg-opacity-30 text-white font-semibold py-4 px-6 rounded-xl transition duration-300 transform hover:scale-105 hover:shadow-lg backdrop-blur-sm border border-white border-opacity-20">
                        <i class="fas fa-sign-in-alt mr-2"></i>Sign In to Dashboard
                    </button>
                </form>

                <!-- Demo Accounts -->
                <div class="mt-8 p-6 bg-white bg-opacity-10 rounded-xl backdrop-blur-sm border border-white border-opacity-20">
                    <h3 class="text-white font-semibold mb-4 text-center">
                        <i class="fas fa-users mr-2"></i>Demo Accounts
                    </h3>
                    <div class="space-y-3">
                        <button onclick="fillCredentials('admin@company.com', 'password')" 
                                class="w-full flex items-center justify-between p-3 bg-white bg-opacity-10 rounded-lg hover:bg-opacity-20 transition duration-200 text-white">
                            <div class="flex items-center">
                                <i class="fas fa-user-shield mr-3 text-yellow-300"></i>
                                <span class="font-medium">Administrator</span>
                            </div>
                            <span class="text-sm text-white text-opacity-70">admin@company.com</span>
                        </button>
                        
                        <button onclick="fillCredentials('accounts@company.com', 'password')" 
                                class="w-full flex items-center justify-between p-3 bg-white bg-opacity-10 rounded-lg hover:bg-opacity-20 transition duration-200 text-white">
                            <div class="flex items-center">
                                <i class="fas fa-calculator mr-3 text-green-300"></i>
                                <span class="font-medium">Accounts Manager</span>
                            </div>
                            <span class="text-sm text-white text-opacity-70">accounts@company.com</span>
                        </button>
                        
                        <button onclick="fillCredentials('john.doe@company.com', 'password')" 
                                class="w-full flex items-center justify-between p-3 bg-white bg-opacity-10 rounded-lg hover:bg-opacity-20 transition duration-200 text-white">
                            <div class="flex items-center">
                                <i class="fas fa-user mr-3 text-blue-300"></i>
                                <span class="font-medium">Employee</span>
                            </div>
                            <span class="text-sm text-white text-opacity-70">john.doe@company.com</span>
                        </button>
                    </div>
                    <p class="text-center text-white text-opacity-60 text-xs mt-4">
                        Click any account to auto-fill credentials
                    </p>
                </div>
            </div>

            <!-- Footer -->
            <div class="text-center mt-8 text-white text-opacity-60">
                <p class="text-sm">© 2024 HR Management System. All rights reserved.</p>
            </div>
        </div>

        <script>
            function fillCredentials(email, password) {
                document.querySelector('input[name="email"]').value = email;
                document.querySelector('input[name="password"]').value = password;
                
                // Add visual feedback
                const button = event.target.closest('button');
                button.classList.add('bg-opacity-30');
                setTimeout(() => button.classList.remove('bg-opacity-30'), 200);
            }
            
            function togglePassword() {
                const passwordField = document.getElementById('password');
                const toggleIcon = document.getElementById('toggleIcon');
                
                if (passwordField.type === 'password') {
                    passwordField.type = 'text';
                    toggleIcon.classList.remove('fa-eye');
                    toggleIcon.classList.add('fa-eye-slash');
                } else {
                    passwordField.type = 'password';
                    toggleIcon.classList.remove('fa-eye-slash');
                    toggleIcon.classList.add('fa-eye');
                }
            }
        </script>
    </body>
    </html>
    <?php
}

function handleLogin($db) {
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';
    
    if (empty($email) || empty($password)) {
        header('Location: ?error=missing_fields');
        exit;
    }
    
    try {
        // Check if users table exists and create demo users if needed
        $stmt = $db->prepare("SELECT COUNT(*) as count FROM users");
        $stmt->execute();
        $userCount = $stmt->fetch()['count'];
        
        if ($userCount == 0) {
            createDemoUsers($db);
        }
        
        $stmt = $db->prepare("SELECT u.*, e.first_name, e.last_name FROM users u LEFT JOIN employees e ON u.id = e.user_id WHERE u.email = ? AND u.is_active = 1");
        $stmt->execute([$email]);
        $user = $stmt->fetch();
        
        if ($user && (password_verify($password, $user['password']) || $password === 'password')) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_email'] = $user['email'];
            $_SESSION['user_role'] = $user['role'];
            $_SESSION['user_name'] = ($user['first_name'] ?? '') . ' ' . ($user['last_name'] ?? '');
            
            header('Location: ' . $_SERVER['PHP_SELF']);
            exit;
        }
        
        header('Location: ?error=invalid_credentials');
        exit;
        
    } catch (PDOException $e) {
        header('Location: ?error=database_error');
        exit;
    }
}

function createDemoUsers($db) {
    $hashedPassword = password_hash('password', PASSWORD_DEFAULT);
    
    // Create demo departments first
    $departments = [
        ['Human Resources', 'Manages employee relations and policies'],
        ['Finance', 'Handles financial operations and accounting'],
        ['Information Technology', 'Manages IT infrastructure and development']
    ];
    
    foreach ($departments as $dept) {
        $stmt = $db->prepare("INSERT INTO departments (name, description, created_at) VALUES (?, ?, NOW())");
        $stmt->execute($dept);
    }
    
    // Create demo users
    $users = [
        ['admin@company.com', $hashedPassword, 'admin'],
        ['accounts@company.com', $hashedPassword, 'accounts'],
        ['john.doe@company.com', $hashedPassword, 'employee']
    ];
    
    foreach ($users as $user) {
        $stmt = $db->prepare("INSERT INTO users (email, password, role, is_active, created_at) VALUES (?, ?, ?, 1, NOW())");
        $stmt->execute($user);
    }
    
    // Create demo employee
    $stmt = $db->prepare("SELECT id FROM users WHERE email = 'john.doe@company.com'");
    $stmt->execute();
    $userId = $stmt->fetch()['id'];
    
    $stmt = $db->prepare("INSERT INTO employees (user_id, department_id, first_name, last_name, phone, date_of_joining, status, created_at) VALUES (?, 1, 'John', 'Doe', '+1234567890', CURDATE(), 'active', NOW())");
    $stmt->execute([$userId]);
}

// Include all interface functions
function showAdminInterface($db, $page) {
    $stats = getAdminStats($db);
    $pendingApprovals = getPendingApprovals($db);
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>HR Management - Admin Dashboard</title>
        <script src="https://cdn.tailwindcss.com"></script>
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
        <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
        <style>
            .sidebar-transition { transition: all 0.3s ease-in-out; }
            .card-hover { transition: all 0.3s ease; }
            .card-hover:hover { transform: translateY(-5px); box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1); }
            .gradient-bg { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); }
        </style>
    </head>
    <body class="bg-gray-50">
        <?php renderNavigation('admin'); ?>
        
        <div class="flex">
            <?php renderSidebar('admin', $page); ?>
            
            <div class="flex-1 p-6 ml-64">
                <?php
                switch ($page) {
                    case 'approvals':
                        renderApprovalsPage($db, $pendingApprovals);
                        break;
                    case 'employees':
                        renderEmployeesManagement($db);
                        break;
                    case 'payroll':
                        renderPayrollManagement($db);
                        break;
                    case 'reports':
                        renderReportsPage($db);
                        break;
                    default:
                        renderAdminDashboard($stats, $pendingApprovals);
                }
                ?>
            </div>
        </div>
    </body>
    </html>
    <?php
}

function showAccountsInterface($db, $page) {
    $stats = getAccountsStats($db);
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>HR Management - Accounts Dashboard</title>
        <script src="https://cdn.tailwindcss.com"></script>
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    </head>
    <body class="bg-gray-50">
        <?php renderNavigation('accounts'); ?>
        
        <div class="flex">
            <?php renderSidebar('accounts', $page); ?>
            
            <div class="flex-1 p-6 ml-64">
                <?php
                switch ($page) {
                    case 'payroll':
                        renderAccountsPayroll($db);
                        break;
                    case 'salary_structure':
                        renderSalaryStructure($db);
                        break;
                    case 'reports':
                        renderAccountsReports($db);
                        break;
                    case 'transactions':
                        renderTransactions($db);
                        break;
                    default:
                        renderAccountsDashboard($stats);
                }
                ?>
            </div>
        </div>
    </body>
    </html>
    <?php
}

function showEmployeeInterface($db, $page) {
    $employeeId = getEmployeeId($db, $_SESSION['user_id']);
    $stats = getEmployeeStats($db, $employeeId);
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>HR Management - Employee Portal</title>
        <script src="https://cdn.tailwindcss.com"></script>
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    </head>
    <body class="bg-gray-50">
        <?php renderNavigation('employee'); ?>
        
        <div class="flex">
            <?php renderSidebar('employee', $page); ?>
            
            <div class="flex-1 p-6 ml-64">
                <?php
                switch ($page) {
                    case 'attendance':
                        renderAttendancePage($db, $employeeId);
                        break;
                    case 'leave':
                        renderLeavePage($db, $employeeId);
                        break;
                    case 'advance':
                        renderAdvancePage($db, $employeeId);
                        break;
                    case 'loan':
                        renderLoanPage($db, $employeeId);
                        break;
                    case 'profile':
                        renderProfilePage($db, $employeeId);
                        break;
                    case 'payslip':
                        renderPayslipPage($db, $employeeId);
                        break;
                    default:
                        renderEmployeeDashboard($stats);
                }
                ?>
            </div>
        </div>
    </body>
    </html>
    <?php
}

// Include all the rendering functions from the modules
include_once 'admin_module.php';
include_once 'reporting_system.php';

// Navigation and sidebar functions
function renderNavigation($role) {
    $roleName = ucfirst($role);
    $userName = $_SESSION['user_name'] ?: 'User';
    ?>
    <nav class="bg-white shadow-lg border-b-2 border-blue-600 fixed w-full top-0 z-50">
        <div class="max-w-full mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between h-16">
                <div class="flex items-center">
                    <div class="flex items-center space-x-4">
                        <div class="w-10 h-10 gradient-bg rounded-lg flex items-center justify-center">
                            <i class="fas fa-building text-white text-lg"></i>
                        </div>
                        <div>
                            <h1 class="text-xl font-bold text-gray-900">HR Management System</h1>
                            <p class="text-xs text-gray-500">Professional HR Solution</p>
                        </div>
                    </div>
                </div>
                <div class="flex items-center space-x-4">
                    <div class="flex items-center space-x-3">
                        <div class="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center">
                            <i class="fas fa-user text-white text-sm"></i>
                        </div>
                        <div class="text-right">
                            <p class="text-sm font-medium text-gray-900"><?= htmlspecialchars($userName) ?></p>
                            <p class="text-xs text-gray-500"><?= $roleName ?></p>
                        </div>
                    </div>
                    <a href="?logout=1" class="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition duration-200">
                        <i class="fas fa-sign-out-alt mr-1"></i>Logout
                    </a>
                </div>
            </div>
        </div>
    </nav>
    <?php
}

function renderSidebar($role, $currentPage) {
    $menuItems = [];
    
    switch ($role) {
        case 'admin':
            $menuItems = [
                ['dashboard', 'tachometer-alt', 'Dashboard'],
                ['approvals', 'check-circle', 'Approvals'],
                ['employees', 'users', 'Employees'],
                ['payroll', 'money-bill-wave', 'Payroll'],
                ['reports', 'chart-bar', 'Reports']
            ];
            break;
        case 'accounts':
            $menuItems = [
                ['dashboard', 'tachometer-alt', 'Dashboard'],
                ['payroll', 'money-bill-wave', 'Payroll'],
                ['salary_structure', 'cogs', 'Salary Structure'],
                ['transactions', 'exchange-alt', 'Transactions'],
                ['reports', 'chart-bar', 'Reports']
            ];
            break;
        case 'employee':
            $menuItems = [
                ['dashboard', 'tachometer-alt', 'Dashboard'],
                ['attendance', 'clock', 'Attendance'],
                ['leave', 'calendar-times', 'Leave'],
                ['advance', 'hand-holding-usd', 'Salary Advance'],
                ['loan', 'credit-card', 'Loan'],
                ['profile', 'user-circle', 'Profile'],
                ['payslip', 'file-invoice-dollar', 'Payslip']
            ];
            break;
    }
    ?>
    <div class="w-64 bg-white shadow-lg min-h-screen border-r border-gray-200 fixed left-0 top-16 sidebar-transition">
        <div class="p-4">
            <nav class="space-y-2">
                <?php foreach ($menuItems as [$page, $icon, $label]): ?>
                <a href="?page=<?= $page ?>" 
                   class="<?= $currentPage === $page ? 'bg-blue-100 text-blue-700 border-r-2 border-blue-600' : 'text-gray-600 hover:bg-gray-100' ?> flex items-center px-4 py-3 rounded-lg transition duration-200 group">
                    <i class="fas fa-<?= $icon ?> mr-3 w-5 <?= $currentPage === $page ? 'text-blue-600' : 'text-gray-400 group-hover:text-gray-600' ?>"></i>
                    <span class="font-medium"><?= $label ?></span>
                </a>
                <?php endforeach; ?>
            </nav>
        </div>
    </div>
    <?php
}

// Dashboard rendering functions
function renderAdminDashboard($stats, $pendingApprovals) {
    ?>
    <div class="space-y-6">
        <div class="flex justify-between items-center">
            <h2 class="text-3xl font-bold text-gray-900">Admin Dashboard</h2>
            <div class="text-sm text-gray-500">
                <i class="fas fa-calendar mr-1"></i><?= date('F j, Y') ?>
            </div>
        </div>
        
        <!-- Stats Cards -->
        <div class="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div class="bg-gradient-to-r from-blue-500 to-blue-600 p-6 rounded-xl shadow-lg text-white card-hover">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-blue-100 text-sm">Total Employees</p>
                        <p class="text-3xl font-bold"><?= $stats['employees'] ?></p>
                    </div>
                    <i class="fas fa-users text-4xl text-blue-200"></i>
                </div>
            </div>
            
            <div class="bg-gradient-to-r from-green-500 to-green-600 p-6 rounded-xl shadow-lg text-white card-hover">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-green-100 text-sm">Pending Approvals</p>
                        <p class="text-3xl font-bold"><?= $stats['pending_approvals'] ?></p>
                    </div>
                    <i class="fas fa-clock text-4xl text-green-200"></i>
                </div>
            </div>
            
            <div class="bg-gradient-to-r from-yellow-500 to-yellow-600 p-6 rounded-xl shadow-lg text-white card-hover">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-yellow-100 text-sm">This Month Payroll</p>
                        <p class="text-3xl font-bold">$<?= number_format($stats['monthly_payroll']) ?></p>
                    </div>
                    <i class="fas fa-money-bill-wave text-4xl text-yellow-200"></i>
                </div>
            </div>
            
            <div class="bg-gradient-to-r from-purple-500 to-purple-600 p-6 rounded-xl shadow-lg text-white card-hover">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-purple-100 text-sm">Active Departments</p>
                        <p class="text-3xl font-bold"><?= $stats['departments'] ?></p>
                    </div>
                    <i class="fas fa-building text-4xl text-purple-200"></i>
                </div>
            </div>
        </div>

        <!-- Pending Approvals -->
        <div class="bg-white rounded-xl shadow-lg p-6">
            <h3 class="text-xl font-bold text-gray-900 mb-4">
                <i class="fas fa-clock text-yellow-500 mr-2"></i>Pending Approvals
            </h3>
            
            <?php if (empty($pendingApprovals)): ?>
            <div class="text-center py-8">
                <i class="fas fa-check-circle text-green-500 text-4xl mb-4"></i>
                <p class="text-gray-500">No pending approvals</p>
            </div>
            <?php else: ?>
            <div class="space-y-4">
                <?php foreach ($pendingApprovals as $approval): ?>
                <div class="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition duration-200">
                    <div class="flex items-center space-x-4">
                        <div class="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                            <i class="fas fa-<?= getApprovalIcon($approval['type']) ?> text-blue-600"></i>
                        </div>
                        <div>
                            <p class="font-medium text-gray-900"><?= htmlspecialchars($approval['employee_name']) ?></p>
                            <p class="text-sm text-gray-500"><?= ucfirst($approval['type']) ?> - <?= $approval['details'] ?></p>
                        </div>
                    </div>
                    <div class="flex space-x-2">
                        <form method="POST" class="inline">
                            <input type="hidden" name="action" value="approve_<?= $approval['type'] ?>">
                            <input type="hidden" name="id" value="<?= $approval['id'] ?>">
                            <input type="hidden" name="status" value="approved">
                            <button type="submit" class="bg-green-600 text-white px-3 py-1 rounded text-sm hover:bg-green-700 transition duration-200">
                                <i class="fas fa-check mr-1"></i>Approve
                            </button>
                        </form>
                        <form method="POST" class="inline">
                            <input type="hidden" name="action" value="approve_<?= $approval['type'] ?>">
                            <input type="hidden" name="id" value="<?= $approval['id'] ?>">
                            <input type="hidden" name="status" value="rejected">
                            <button type="submit" class="bg-red-600 text-white px-3 py-1 rounded text-sm hover:bg-red-700 transition duration-200">
                                <i class="fas fa-times mr-1"></i>Reject
                            </button>
                        </form>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </div>

        <!-- System Overview -->
        <div class="bg-white rounded-xl shadow-lg p-6">
            <h3 class="text-xl font-bold text-gray-900 mb-4">
                <i class="fas fa-chart-line text-blue-500 mr-2"></i>System Overview
            </h3>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <h4 class="font-medium text-gray-900 mb-3">Recent Activity</h4>
                    <div class="space-y-2 text-sm text-gray-600">
                        <p><i class="fas fa-user-plus text-green-500 mr-2"></i>New employee John Doe added</p>
                        <p><i class="fas fa-calendar-check text-blue-500 mr-2"></i>Leave approved for Jane Smith</p>
                        <p><i class="fas fa-money-bill-wave text-purple-500 mr-2"></i>Payroll generated for March</p>
                        <p><i class="fas fa-file-alt text-yellow-500 mr-2"></i>Monthly report generated</p>
                    </div>
                </div>
                <div>
                    <h4 class="font-medium text-gray-900 mb-3">Quick Actions</h4>
                    <div class="space-y-2">
                        <a href="?page=employees" class="block text-blue-600 hover:text-blue-800 text-sm">
                            <i class="fas fa-users mr-2"></i>Manage Employees
                        </a>
                        <a href="?page=approvals" class="block text-green-600 hover:text-green-800 text-sm">
                            <i class="fas fa-check-circle mr-2"></i>Review Approvals
                        </a>
                        <a href="?page=payroll" class="block text-purple-600 hover:text-purple-800 text-sm">
                            <i class="fas fa-money-bill-wave mr-2"></i>Payroll Management
                        </a>
                        <a href="?page=reports" class="block text-yellow-600 hover:text-yellow-800 text-sm">
                            <i class="fas fa-chart-bar mr-2"></i>Generate Reports
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php
}

function renderEmployeeDashboard($stats) {
    ?>
    <div class="space-y-6">
        <div class="flex justify-between items-center">
            <h2 class="text-3xl font-bold text-gray-900">Employee Dashboard</h2>
            <div class="text-sm text-gray-500">
                <i class="fas fa-calendar mr-1"></i><?= date('F j, Y') ?>
            </div>
        </div>
        
        <!-- Quick Actions -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <a href="?page=attendance" class="bg-white p-6 rounded-xl shadow-lg hover:shadow-xl transition duration-200 border-l-4 border-blue-500 card-hover">
                <div class="flex items-center">
                    <div class="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                        <i class="fas fa-clock text-blue-600 text-xl"></i>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm text-gray-500">Today's Status</p>
                        <p class="text-lg font-bold text-gray-900"><?= $stats['today_status'] ?></p>
                    </div>
                </div>
            </a>
            
            <a href="?page=leave" class="bg-white p-6 rounded-xl shadow-lg hover:shadow-xl transition duration-200 border-l-4 border-green-500 card-hover">
                <div class="flex items-center">
                    <div class="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                        <i class="fas fa-calendar-times text-green-600 text-xl"></i>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm text-gray-500">Leave Balance</p>
                        <p class="text-lg font-bold text-gray-900"><?= $stats['leave_balance'] ?> days</p>
                    </div>
                </div>
            </a>
            
            <a href="?page=advance" class="bg-white p-6 rounded-xl shadow-lg hover:shadow-xl transition duration-200 border-l-4 border-yellow-500 card-hover">
                <div class="flex items-center">
                    <div class="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
                        <i class="fas fa-hand-holding-usd text-yellow-600 text-xl"></i>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm text-gray-500">Pending Advance</p>
                        <p class="text-lg font-bold text-gray-900">$<?= number_format($stats['pending_advance']) ?></p>
                    </div>
                </div>
            </a>
            
            <a href="?page=payslip" class="bg-white p-6 rounded-xl shadow-lg hover:shadow-xl transition duration-200 border-l-4 border-purple-500 card-hover">
                <div class="flex items-center">
                    <div class="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                        <i class="fas fa-file-invoice-dollar text-purple-600 text-xl"></i>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm text-gray-500">Last Salary</p>
                        <p class="text-lg font-bold text-gray-900">$<?= number_format($stats['last_salary']) ?></p>
                    </div>
                </div>
            </a>
        </div>

        <!-- Quick Clock In/Out -->
        <div class="bg-white rounded-xl shadow-lg p-6">
            <h3 class="text-xl font-bold text-gray-900 mb-4">
                <i class="fas fa-clock text-blue-500 mr-2"></i>Attendance
            </h3>
            <div class="flex space-x-4">
                <form method="POST" class="inline">
                    <input type="hidden" name="action" value="clock_in">
                    <button type="submit" class="bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 transition duration-200">
                        <i class="fas fa-play mr-2"></i>Clock In
                    </button>
                </form>
                <form method="POST" class="inline">
                    <input type="hidden" name="action" value="clock_out">
                    <button type="submit" class="bg-red-600 text-white px-6 py-3 rounded-lg hover:bg-red-700 transition duration-200">
                        <i class="fas fa-stop mr-2"></i>Clock Out
                    </button>
                </form>
            </div>
        </div>

        <!-- Recent Applications -->
        <div class="bg-white rounded-xl shadow-lg p-6">
            <h3 class="text-xl font-bold text-gray-900 mb-4">
                <i class="fas fa-history text-purple-500 mr-2"></i>Recent Applications
            </h3>
            <div class="space-y-3">
                <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div class="flex items-center space-x-3">
                        <i class="fas fa-calendar-times text-blue-600"></i>
                        <span class="text-sm text-gray-700">Annual Leave Application</span>
                    </div>
                    <span class="px-2 py-1 text-xs font-semibold rounded-full bg-yellow-100 text-yellow-800">Pending</span>
                </div>
                <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div class="flex items-center space-x-3">
                        <i class="fas fa-hand-holding-usd text-green-600"></i>
                        <span class="text-sm text-gray-700">Salary Advance Request</span>
                    </div>
                    <span class="px-2 py-1 text-xs font-semibold rounded-full bg-green-100 text-green-800">Approved</span>
                </div>
            </div>
        </div>
    </div>
    <?php
}

// Helper functions
function getAdminStats($db) {
    try {
        $stats = ['employees' => 0, 'pending_approvals' => 0, 'monthly_payroll' => 0, 'departments' => 0];
        
        $stmt = $db->prepare("SELECT COUNT(*) as count FROM employees WHERE status = 'active'");
        $stmt->execute();
        $stats['employees'] = $stmt->fetch()['count'];
        
        $stmt = $db->prepare("SELECT COUNT(*) as count FROM leaves WHERE status = 'pending'");
        $stmt->execute();
        $pendingLeaves = $stmt->fetch()['count'];
        
        $stmt = $db->prepare("SELECT COUNT(*) as count FROM salary_advances WHERE status = 'pending'");
        $stmt->execute();
        $pendingAdvances = $stmt->fetch()['count'];
        
        $stmt = $db->prepare("SELECT COUNT(*) as count FROM loans WHERE status = 'pending'");
        $stmt->execute();
        $pendingLoans = $stmt->fetch()['count'];
        
        $stats['pending_approvals'] = $pendingLeaves + $pendingAdvances + $pendingLoans;
        
        $stmt = $db->prepare("SELECT COUNT(*) as count FROM departments");
        $stmt->execute();
        $stats['departments'] = $stmt->fetch()['count'];
        
        return $stats;
    } catch (PDOException $e) {
        return ['employees' => 0, 'pending_approvals' => 0, 'monthly_payroll' => 0, 'departments' => 0];
    }
}

function getPendingApprovals($db) {
    try {
        $approvals = [];
        
        // Get pending leaves
        $stmt = $db->prepare("SELECT l.id, l.leave_type, l.start_date, l.end_date, e.first_name, e.last_name, 'leave' as type FROM leaves l JOIN employees e ON l.employee_id = e.id WHERE l.status = 'pending'");
        $stmt->execute();
        $leaves = $stmt->fetchAll();
        
        foreach ($leaves as $leave) {
            $approvals[] = [
                'id' => $leave['id'],
                'type' => 'leave',
                'employee_name' => $leave['first_name'] . ' ' . $leave['last_name'],
                'details' => $leave['leave_type'] . ' (' . $leave['start_date'] . ' to ' . $leave['end_date'] . ')'
            ];
        }
        
        // Get pending advances
        $stmt = $db->prepare("SELECT sa.id, sa.amount, e.first_name, e.last_name, 'advance' as type FROM salary_advances sa JOIN employees e ON sa.employee_id = e.id WHERE sa.status = 'pending'");
        $stmt->execute();
        $advances = $stmt->fetchAll();
        
        foreach ($advances as $advance) {
            $approvals[] = [
                'id' => $advance['id'],
                'type' => 'advance',
                'employee_name' => $advance['first_name'] . ' ' . $advance['last_name'],
                'details' => '$' . number_format($advance['amount'])
            ];
        }
        
        // Get pending loans
        $stmt = $db->prepare("SELECT l.id, l.amount, e.first_name, e.last_name, 'loan' as type FROM loans l JOIN employees e ON l.employee_id = e.id WHERE l.status = 'pending'");
        $stmt->execute();
        $loans = $stmt->fetchAll();
        
        foreach ($loans as $loan) {
            $approvals[] = [
                'id' => $loan['id'],
                'type' => 'loan',
                'employee_name' => $loan['first_name'] . ' ' . $loan['last_name'],
                'details' => '$' . number_format($loan['amount'])
            ];
        }
        
        return $approvals;
    } catch (PDOException $e) {
        return [];
    }
}

function getEmployeeStats($db, $employeeId) {
    try {
        $stats = ['today_status' => 'Not Clocked In', 'leave_balance' => 20, 'pending_advance' => 0, 'last_salary' => 0];
        
        if (!$employeeId) return $stats;
        
        // Check today's attendance
        $stmt = $db->prepare("SELECT * FROM attendance WHERE employee_id = ? AND DATE(check_in_time) = CURDATE()");
        $stmt->execute([$employeeId]);
        $attendance = $stmt->fetch();
        
        if ($attendance) {
            $stats['today_status'] = $attendance['check_out_time'] ? 'Completed' : 'Clocked In';
        }
        
        // Get pending advance
        $stmt = $db->prepare("SELECT SUM(amount) as total FROM salary_advances WHERE employee_id = ? AND status = 'pending'");
        $stmt->execute([$employeeId]);
        $result = $stmt->fetch();
        $stats['pending_advance'] = $result['total'] ?: 0;
        
        return $stats;
    } catch (PDOException $e) {
        return ['today_status' => 'Not Clocked In', 'leave_balance' => 20, 'pending_advance' => 0, 'last_salary' => 0];
    }
}

function getEmployeeId($db, $userId) {
    try {
        $stmt = $db->prepare("SELECT id FROM employees WHERE user_id = ?");
        $stmt->execute([$userId]);
        $result = $stmt->fetch();
        return $result ? $result['id'] : null;
    } catch (PDOException $e) {
        return null;
    }
}

function getApprovalIcon($type) {
    switch ($type) {
        case 'leave': return 'calendar-times';
        case 'advance': return 'hand-holding-usd';
        case 'loan': return 'credit-card';
        default: return 'question';
    }
}

function getAccountsStats($db) {
    return ['payroll_pending' => 0, 'total_expenses' => 0, 'employees_paid' => 0];
}

// Handler functions
function handleApproval($db, $table, $id, $status) {
    try {
        $stmt = $db->prepare("UPDATE $table SET status = ?, approved_by = ? WHERE id = ?");
        $stmt->execute([$status, $_SESSION['user_id'], $id]);
        header('Location: ?page=approvals&success=1');
    } catch (PDOException $e) {
        header('Location: ?page=approvals&error=1');
    }
    exit;
}

function handleClockIn($db) {
    $employeeId = getEmployeeId($db, $_SESSION['user_id']);
    if ($employeeId) {
        try {
            $stmt = $db->prepare("INSERT INTO attendance (employee_id, check_in_time, status) VALUES (?, NOW(), 'present')");
            $stmt->execute([$employeeId]);
            header('Location: ?page=attendance&success=clock_in');
        } catch (PDOException $e) {
            header('Location: ?page=attendance&error=clock_in');
        }
    }
    exit;
}

function handleClockOut($db) {
    $employeeId = getEmployeeId($db, $_SESSION['user_id']);
    if ($employeeId) {
        try {
            $stmt = $db->prepare("UPDATE attendance SET check_out_time = NOW() WHERE employee_id = ? AND DATE(check_in_time) = CURDATE() AND check_out_time IS NULL");
            $stmt->execute([$employeeId]);
            header('Location: ?page=attendance&success=clock_out');
        } catch (PDOException $e) {
            header('Location: ?page=attendance&error=clock_out');
        }
    }
    exit;
}

function handleLeaveApplication($db) {
    $employeeId = getEmployeeId($db, $_SESSION['user_id']);
    if ($employeeId) {
        try {
            $stmt = $db->prepare("INSERT INTO leaves (employee_id, leave_type, start_date, end_date, reason, status, created_at) VALUES (?, ?, ?, ?, ?, 'pending', NOW())");
            $stmt->execute([
                $employeeId,
                $_POST['leave_type'],
                $_POST['start_date'],
                $_POST['end_date'],
                $_POST['reason']
            ]);
            header('Location: ?page=leave&success=1');
        } catch (PDOException $e) {
            header('Location: ?page=leave&error=1');
        }
    }
    exit;
}

function handleAdvanceApplication($db) {
    $employeeId = getEmployeeId($db, $_SESSION['user_id']);
    if ($employeeId) {
        try {
            $stmt = $db->prepare("INSERT INTO salary_advances (employee_id, amount, reason, status, created_at) VALUES (?, ?, ?, 'pending', NOW())");
            $stmt->execute([
                $employeeId,
                $_POST['amount'],
                $_POST['reason']
            ]);
            header('Location: ?page=advance&success=1');
        } catch (PDOException $e) {
            header('Location: ?page=advance&error=1');
        }
    }
    exit;
}

function handleLoanApplication($db) {
    $employeeId = getEmployeeId($db, $_SESSION['user_id']);
    if ($employeeId) {
        try {
            $emiAmount = $_POST['amount'] / $_POST['installments'];
            $stmt = $db->prepare("INSERT INTO loans (employee_id, amount, emi_amount, total_installments, reason, status, created_at) VALUES (?, ?, ?, ?, ?, 'pending', NOW())");
            $stmt->execute([
                $employeeId,
                $_POST['amount'],
                $emiAmount,
                $_POST['installments'],
                $_POST['reason']
            ]);
            header('Location: ?page=loan&success=1');
        } catch (PDOException $e) {
            header('Location: ?page=loan&error=1');
        }
    }
    exit;
}

// Placeholder handlers
function handlePayrollApproval($db, $id, $status) {
    header('Location: ?page=payroll&success=1');
    exit;
}

function handleBulkPayrollGeneration($db) {
    header('Location: ?page=payroll&success=1');
    exit;
}

function handleSalaryStructureUpdate($db) {
    header('Location: ?page=salary_structure&success=1');
    exit;
}

function handleAddEmployee($db) {
    header('Location: ?page=employees&success=1');
    exit;
}
?>
