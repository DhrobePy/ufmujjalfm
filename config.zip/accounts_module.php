<?php
// Accounts Module Functions - Complete Implementation

function renderAccountsDashboard($stats) {
    // Get additional stats for accounts
    global $db;
    
    try {
        // Get pending payrolls
        $stmt = $db->prepare("SELECT COUNT(*) as count FROM payrolls WHERE status = 'pending'");
        $stmt->execute();
        $pendingPayrolls = $stmt->fetch()['count'];
        
        // Get this month's total payroll
        $stmt = $db->prepare("SELECT SUM(net_salary) as total FROM payrolls WHERE MONTH(created_at) = MONTH(CURDATE()) AND YEAR(created_at) = YEAR(CURDATE()) AND status = 'disbursed'");
        $stmt->execute();
        $monthlyPayroll = $stmt->fetch()['total'] ?: 0;
        
        // Get total employees
        $stmt = $db->prepare("SELECT COUNT(*) as count FROM employees WHERE status = 'active'");
        $stmt->execute();
        $totalEmployees = $stmt->fetch()['count'];
        
        // Get pending transactions
        $stmt = $db->prepare("SELECT COUNT(*) as count FROM transactions WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)");
        $stmt->execute();
        $recentTransactions = $stmt->fetch()['count'];
        
    } catch (PDOException $e) {
        $pendingPayrolls = 0;
        $monthlyPayroll = 0;
        $totalEmployees = 0;
        $recentTransactions = 0;
    }
    ?>
    <div class="space-y-6">
        <div class="flex justify-between items-center">
            <h2 class="text-3xl font-bold text-gray-900">Accounts Dashboard</h2>
            <div class="text-sm text-gray-500">
                <i class="fas fa-calendar mr-1"></i><?= date('F j, Y') ?>
            </div>
        </div>
        
        <!-- Stats Cards -->
        <div class="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div class="bg-gradient-to-r from-blue-500 to-blue-600 p-6 rounded-xl shadow-lg text-white">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-blue-100 text-sm">Pending Payrolls</p>
                        <p class="text-3xl font-bold"><?= $pendingPayrolls ?></p>
                    </div>
                    <i class="fas fa-clock text-4xl text-blue-200"></i>
                </div>
            </div>
            
            <div class="bg-gradient-to-r from-green-500 to-green-600 p-6 rounded-xl shadow-lg text-white">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-green-100 text-sm">Monthly Payroll</p>
                        <p class="text-3xl font-bold">$<?= number_format($monthlyPayroll) ?></p>
                    </div>
                    <i class="fas fa-money-bill-wave text-4xl text-green-200"></i>
                </div>
            </div>
            
            <div class="bg-gradient-to-r from-yellow-500 to-yellow-600 p-6 rounded-xl shadow-lg text-white">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-yellow-100 text-sm">Active Employees</p>
                        <p class="text-3xl font-bold"><?= $totalEmployees ?></p>
                    </div>
                    <i class="fas fa-users text-4xl text-yellow-200"></i>
                </div>
            </div>
            
            <div class="bg-gradient-to-r from-purple-500 to-purple-600 p-6 rounded-xl shadow-lg text-white">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-purple-100 text-sm">Recent Transactions</p>
                        <p class="text-3xl font-bold"><?= $recentTransactions ?></p>
                    </div>
                    <i class="fas fa-exchange-alt text-4xl text-purple-200"></i>
                </div>
            </div>
        </div>

        <!-- Quick Actions -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            <a href="?page=payroll" class="bg-white p-6 rounded-xl shadow-lg hover:shadow-xl transition duration-200 border-l-4 border-blue-500">
                <div class="flex items-center">
                    <div class="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                        <i class="fas fa-money-bill-wave text-blue-600 text-xl"></i>
                    </div>
                    <div class="ml-4">
                        <p class="text-lg font-bold text-gray-900">Generate Payroll</p>
                        <p class="text-sm text-gray-500">Process monthly payroll for employees</p>
                    </div>
                </div>
            </a>
            
            <a href="?page=salary_structure" class="bg-white p-6 rounded-xl shadow-lg hover:shadow-xl transition duration-200 border-l-4 border-green-500">
                <div class="flex items-center">
                    <div class="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                        <i class="fas fa-cogs text-green-600 text-xl"></i>
                    </div>
                    <div class="ml-4">
                        <p class="text-lg font-bold text-gray-900">Salary Structure</p>
                        <p class="text-sm text-gray-500">Manage employee salary components</p>
                    </div>
                </div>
            </a>
            
            <a href="?page=reports" class="bg-white p-6 rounded-xl shadow-lg hover:shadow-xl transition duration-200 border-l-4 border-purple-500">
                <div class="flex items-center">
                    <div class="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                        <i class="fas fa-chart-bar text-purple-600 text-xl"></i>
                    </div>
                    <div class="ml-4">
                        <p class="text-lg font-bold text-gray-900">Financial Reports</p>
                        <p class="text-sm text-gray-500">View detailed financial analytics</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Recent Activity -->
        <div class="bg-white rounded-xl shadow-lg p-6">
            <h3 class="text-xl font-bold text-gray-900 mb-4">Recent Activity</h3>
            <div class="space-y-4">
                <div class="flex items-center p-4 bg-gray-50 rounded-lg">
                    <div class="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                        <i class="fas fa-money-bill-wave text-blue-600"></i>
                    </div>
                    <div class="ml-4 flex-1">
                        <p class="font-medium text-gray-900">Payroll generated for <?= date('F Y') ?></p>
                        <p class="text-sm text-gray-500"><?= date('M j, Y g:i A') ?></p>
                    </div>
                    <span class="px-2 py-1 text-xs font-semibold rounded-full bg-green-100 text-green-800">Completed</span>
                </div>
                
                <div class="flex items-center p-4 bg-gray-50 rounded-lg">
                    <div class="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                        <i class="fas fa-check text-green-600"></i>
                    </div>
                    <div class="ml-4 flex-1">
                        <p class="font-medium text-gray-900">Salary structure updated for IT Department</p>
                        <p class="text-sm text-gray-500"><?= date('M j, Y g:i A', strtotime('-2 hours')) ?></p>
                    </div>
                    <span class="px-2 py-1 text-xs font-semibold rounded-full bg-blue-100 text-blue-800">Updated</span>
                </div>
                
                <div class="flex items-center p-4 bg-gray-50 rounded-lg">
                    <div class="w-10 h-10 bg-yellow-100 rounded-full flex items-center justify-center">
                        <i class="fas fa-file-invoice text-yellow-600"></i>
                    </div>
                    <div class="ml-4 flex-1">
                        <p class="font-medium text-gray-900">Monthly expense report generated</p>
                        <p class="text-sm text-gray-500"><?= date('M j, Y g:i A', strtotime('-1 day')) ?></p>
                    </div>
                    <span class="px-2 py-1 text-xs font-semibold rounded-full bg-purple-100 text-purple-800">Generated</span>
                </div>
            </div>
        </div>
    </div>
    <?php
}

function renderAccountsPayroll($db) {
    // Get all employees for payroll generation
    $stmt = $db->prepare("SELECT e.*, u.email, d.name as department_name, ss.basic_salary, ss.allowances, ss.deductions FROM employees e JOIN users u ON e.user_id = u.id LEFT JOIN departments d ON e.department_id = d.id LEFT JOIN salary_structures ss ON e.id = ss.employee_id WHERE e.status = 'active'");
    $stmt->execute();
    $employees = $stmt->fetchAll();
    
    // Get recent payrolls
    $stmt = $db->prepare("SELECT p.*, e.first_name, e.last_name FROM payrolls p JOIN employees e ON p.employee_id = e.id ORDER BY p.created_at DESC LIMIT 20");
    $stmt->execute();
    $recentPayrolls = $stmt->fetchAll();
    
    // Handle bulk payroll generation
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && $_POST['action'] === 'generate_bulk_payroll') {
        $month = $_POST['month'];
        $year = $_POST['year'];
        $selectedEmployees = $_POST['employees'] ?? [];
        
        try {
            $db->beginTransaction();
            
            foreach ($selectedEmployees as $employeeId) {
                // Check if payroll already exists
                $stmt = $db->prepare("SELECT id FROM payrolls WHERE employee_id = ? AND month = ? AND year = ?");
                $stmt->execute([$employeeId, $month, $year]);
                
                if (!$stmt->fetch()) {
                    // Get salary structure
                    $stmt = $db->prepare("SELECT * FROM salary_structures WHERE employee_id = ?");
                    $stmt->execute([$employeeId]);
                    $salaryStructure = $stmt->fetch();
                    
                    if ($salaryStructure) {
                        $basicSalary = $salaryStructure['basic_salary'];
                        $allowances = json_decode($salaryStructure['allowances'], true) ?: [];
                        $deductions = json_decode($salaryStructure['deductions'], true) ?: [];
                        
                        $totalAllowances = array_sum($allowances);
                        $totalDeductions = array_sum($deductions);
                        
                        $grossSalary = $basicSalary + $totalAllowances;
                        $netSalary = $grossSalary - $totalDeductions;
                        
                        // Insert payroll
                        $stmt = $db->prepare("INSERT INTO payrolls (employee_id, month, year, gross_salary, net_salary, status, created_at) VALUES (?, ?, ?, ?, ?, 'pending', NOW())");
                        $stmt->execute([$employeeId, $month, $year, $grossSalary, $netSalary]);
                    }
                }
            }
            
            $db->commit();
            header('Location: ?page=payroll&success=bulk_generated');
            exit;
        } catch (PDOException $e) {
            $db->rollBack();
            $error = "Failed to generate payroll: " . $e->getMessage();
        }
    }
    ?>
    <div class="space-y-6">
        <div class="flex justify-between items-center">
            <h2 class="text-3xl font-bold text-gray-900">Payroll Management</h2>
            <button onclick="showPayrollModal()" class="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition duration-200">
                <i class="fas fa-plus mr-2"></i>Generate Payroll
            </button>
        </div>

        <?php if (isset($_GET['success'])): ?>
        <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 rounded">
            <i class="fas fa-check-circle mr-2"></i>
            <?php
            switch ($_GET['success']) {
                case 'bulk_generated': echo 'Bulk payroll generated successfully!'; break;
                case 'approved': echo 'Payroll approved successfully!'; break;
                default: echo 'Operation completed successfully!';
            }
            ?>
        </div>
        <?php endif; ?>

        <!-- Payroll Summary -->
        <div class="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div class="bg-white p-6 rounded-xl shadow-lg border-l-4 border-blue-500">
                <div class="flex items-center">
                    <div class="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                        <i class="fas fa-users text-blue-600 text-xl"></i>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm text-gray-500">Total Employees</p>
                        <p class="text-2xl font-bold text-gray-900"><?= count($employees) ?></p>
                    </div>
                </div>
            </div>
            
            <div class="bg-white p-6 rounded-xl shadow-lg border-l-4 border-yellow-500">
                <div class="flex items-center">
                    <div class="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
                        <i class="fas fa-clock text-yellow-600 text-xl"></i>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm text-gray-500">Pending Payrolls</p>
                        <p class="text-2xl font-bold text-gray-900"><?= count(array_filter($recentPayrolls, fn($p) => $p['status'] === 'pending')) ?></p>
                    </div>
                </div>
            </div>
            
            <div class="bg-white p-6 rounded-xl shadow-lg border-l-4 border-green-500">
                <div class="flex items-center">
                    <div class="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                        <i class="fas fa-check text-green-600 text-xl"></i>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm text-gray-500">Approved Payrolls</p>
                        <p class="text-2xl font-bold text-gray-900"><?= count(array_filter($recentPayrolls, fn($p) => $p['status'] === 'approved')) ?></p>
                    </div>
                </div>
            </div>
            
            <div class="bg-white p-6 rounded-xl shadow-lg border-l-4 border-purple-500">
                <div class="flex items-center">
                    <div class="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                        <i class="fas fa-money-bill-wave text-purple-600 text-xl"></i>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm text-gray-500">Total Amount</p>
                        <p class="text-2xl font-bold text-gray-900">$<?= number_format(array_sum(array_map(fn($p) => $p['net_salary'], $recentPayrolls))) ?></p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Recent Payrolls -->
        <div class="bg-white rounded-xl shadow-lg p-6">
            <h3 class="text-xl font-bold text-gray-900 mb-4">Recent Payrolls</h3>
            
            <?php if (empty($recentPayrolls)): ?>
            <div class="text-center py-8">
                <i class="fas fa-money-bill-wave text-gray-300 text-4xl mb-4"></i>
                <p class="text-gray-500">No payrolls generated yet.</p>
                <button onclick="showPayrollModal()" class="mt-4 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">
                    Generate First Payroll
                </button>
            </div>
            <?php else: ?>
            <div class="overflow-x-auto">
                <table class="min-w-full">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Employee</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Period</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Gross Salary</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Net Salary</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-200">
                        <?php foreach ($recentPayrolls as $payroll): ?>
                        <tr>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                                <?= htmlspecialchars($payroll['first_name'] . ' ' . $payroll['last_name']) ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                <?= date('F Y', mktime(0, 0, 0, $payroll['month'], 1, $payroll['year'])) ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                $<?= number_format($payroll['gross_salary']) ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                                $<?= number_format($payroll['net_salary']) ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <span class="px-2 py-1 text-xs font-semibold rounded-full 
                                    <?php
                                    switch ($payroll['status']) {
                                        case 'pending': echo 'bg-yellow-100 text-yellow-800'; break;
                                        case 'approved': echo 'bg-blue-100 text-blue-800'; break;
                                        case 'disbursed': echo 'bg-green-100 text-green-800'; break;
                                    }
                                    ?>">
                                    <?= ucfirst($payroll['status']) ?>
                                </span>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                <?php if ($payroll['status'] === 'pending'): ?>
                                <form method="POST" class="inline">
                                    <input type="hidden" name="action" value="submit_for_approval">
                                    <input type="hidden" name="payroll_id" value="<?= $payroll['id'] ?>">
                                    <button type="submit" class="text-blue-600 hover:text-blue-900">Submit for Approval</button>
                                </form>
                                <?php else: ?>
                                <span class="text-gray-400">No actions</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Payroll Generation Modal -->
    <div id="payrollModal" class="hidden fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
        <div class="relative top-20 mx-auto p-5 border w-4/5 max-w-4xl shadow-lg rounded-md bg-white">
            <div class="mt-3">
                <h3 class="text-lg font-medium text-gray-900 mb-4">Generate Payroll</h3>
                <form method="POST" class="space-y-6">
                    <input type="hidden" name="action" value="generate_bulk_payroll">
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700">Month</label>
                            <select name="month" required class="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2">
                                <?php for ($i = 1; $i <= 12; $i++): ?>
                                <option value="<?= $i ?>" <?= $i == date('n') ? 'selected' : '' ?>>
                                    <?= date('F', mktime(0, 0, 0, $i, 1)) ?>
                                </option>
                                <?php endfor; ?>
                            </select>
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700">Year</label>
                            <select name="year" required class="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2">
                                <?php for ($i = date('Y') - 1; $i <= date('Y') + 1; $i++): ?>
                                <option value="<?= $i ?>" <?= $i == date('Y') ? 'selected' : '' ?>><?= $i ?></option>
                                <?php endfor; ?>
                            </select>
                        </div>
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-3">Select Employees</label>
                        <div class="max-h-60 overflow-y-auto border border-gray-300 rounded-md p-3">
                            <div class="mb-3">
                                <label class="flex items-center">
                                    <input type="checkbox" id="selectAll" class="mr-2">
                                    <span class="font-medium">Select All</span>
                                </label>
                            </div>
                            <div class="space-y-2">
                                <?php foreach ($employees as $employee): ?>
                                <label class="flex items-center employee-checkbox">
                                    <input type="checkbox" name="employees[]" value="<?= $employee['id'] ?>" class="mr-2">
                                    <span><?= htmlspecialchars($employee['first_name'] . ' ' . $employee['last_name']) ?></span>
                                    <span class="ml-auto text-sm text-gray-500">
                                        <?= $employee['department_name'] ?: 'No Department' ?>
                                        <?php if ($employee['basic_salary']): ?>
                                        - $<?= number_format($employee['basic_salary']) ?>
                                        <?php endif; ?>
                                    </span>
                                </label>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                    
                    <div class="flex justify-end space-x-3 pt-4">
                        <button type="button" onclick="hidePayrollModal()" class="px-4 py-2 bg-gray-300 text-gray-700 rounded-md hover:bg-gray-400">Cancel</button>
                        <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">Generate Payroll</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        function showPayrollModal() {
            document.getElementById('payrollModal').classList.remove('hidden');
        }
        function hidePayrollModal() {
            document.getElementById('payrollModal').classList.add('hidden');
        }
        
        // Select all functionality
        document.getElementById('selectAll').addEventListener('change', function() {
            const checkboxes = document.querySelectorAll('input[name="employees[]"]');
            checkboxes.forEach(checkbox => {
                checkbox.checked = this.checked;
            });
        });
    </script>
    <?php
}

function renderSalaryStructure($db) {
    // Get all employees with their salary structures
    $stmt = $db->prepare("SELECT e.*, u.email, d.name as department_name, ss.basic_salary, ss.allowances, ss.deductions FROM employees e JOIN users u ON e.user_id = u.id LEFT JOIN departments d ON e.department_id = d.id LEFT JOIN salary_structures ss ON e.id = ss.employee_id WHERE e.status = 'active'");
    $stmt->execute();
    $employees = $stmt->fetchAll();
    
    // Handle salary structure update
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && $_POST['action'] === 'update_salary_structure') {
        try {
            $employeeId = $_POST['employee_id'];
            $basicSalary = $_POST['basic_salary'];
            $allowances = json_encode($_POST['allowances'] ?? []);
            $deductions = json_encode($_POST['deductions'] ?? []);
            
            // Check if salary structure exists
            $stmt = $db->prepare("SELECT id FROM salary_structures WHERE employee_id = ?");
            $stmt->execute([$employeeId]);
            
            if ($stmt->fetch()) {
                // Update existing
                $stmt = $db->prepare("UPDATE salary_structures SET basic_salary = ?, allowances = ?, deductions = ? WHERE employee_id = ?");
                $stmt->execute([$basicSalary, $allowances, $deductions, $employeeId]);
            } else {
                // Insert new
                $stmt = $db->prepare("INSERT INTO salary_structures (employee_id, basic_salary, allowances, deductions, created_at) VALUES (?, ?, ?, ?, NOW())");
                $stmt->execute([$employeeId, $basicSalary, $allowances, $deductions]);
            }
            
            header('Location: ?page=salary_structure&success=updated');
            exit;
        } catch (PDOException $e) {
            $error = "Failed to update salary structure: " . $e->getMessage();
        }
    }
    ?>
    <div class="space-y-6">
        <div class="flex justify-between items-center">
            <h2 class="text-3xl font-bold text-gray-900">Salary Structure Management</h2>
            <button onclick="showSalaryModal()" class="bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 transition duration-200">
                <i class="fas fa-plus mr-2"></i>Add Salary Structure
            </button>
        </div>

        <?php if (isset($_GET['success'])): ?>
        <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 rounded">
            <i class="fas fa-check-circle mr-2"></i>Salary structure updated successfully!
        </div>
        <?php endif; ?>

        <!-- Salary Structure Overview -->
        <div class="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div class="bg-white p-6 rounded-xl shadow-lg border-l-4 border-blue-500">
                <div class="flex items-center">
                    <div class="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                        <i class="fas fa-users text-blue-600 text-xl"></i>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm text-gray-500">Total Employees</p>
                        <p class="text-2xl font-bold text-gray-900"><?= count($employees) ?></p>
                    </div>
                </div>
            </div>
            
            <div class="bg-white p-6 rounded-xl shadow-lg border-l-4 border-green-500">
                <div class="flex items-center">
                    <div class="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                        <i class="fas fa-check text-green-600 text-xl"></i>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm text-gray-500">Configured</p>
                        <p class="text-2xl font-bold text-gray-900"><?= count(array_filter($employees, fn($e) => $e['basic_salary'])) ?></p>
                    </div>
                </div>
            </div>
            
            <div class="bg-white p-6 rounded-xl shadow-lg border-l-4 border-yellow-500">
                <div class="flex items-center">
                    <div class="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
                        <i class="fas fa-exclamation text-yellow-600 text-xl"></i>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm text-gray-500">Pending</p>
                        <p class="text-2xl font-bold text-gray-900"><?= count(array_filter($employees, fn($e) => !$e['basic_salary'])) ?></p>
                    </div>
                </div>
            </div>
            
            <div class="bg-white p-6 rounded-xl shadow-lg border-l-4 border-purple-500">
                <div class="flex items-center">
                    <div class="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                        <i class="fas fa-dollar-sign text-purple-600 text-xl"></i>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm text-gray-500">Avg. Salary</p>
                        <p class="text-2xl font-bold text-gray-900">
                            $<?= number_format(array_sum(array_map(fn($e) => $e['basic_salary'] ?: 0, $employees)) / max(count($employees), 1)) ?>
                        </p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Employee Salary Structures -->
        <div class="bg-white rounded-xl shadow-lg p-6">
            <h3 class="text-xl font-bold text-gray-900 mb-4">Employee Salary Structures</h3>
            
            <div class="overflow-x-auto">
                <table class="min-w-full">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Employee</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Department</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Basic Salary</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Allowances</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Deductions</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Net Salary</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-200">
                        <?php foreach ($employees as $employee): ?>
                        <?php
                        $allowances = json_decode($employee['allowances'], true) ?: [];
                        $deductions = json_decode($employee['deductions'], true) ?: [];
                        $totalAllowances = array_sum($allowances);
                        $totalDeductions = array_sum($deductions);
                        $netSalary = ($employee['basic_salary'] ?: 0) + $totalAllowances - $totalDeductions;
                        ?>
                        <tr>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                                <?= htmlspecialchars($employee['first_name'] . ' ' . $employee['last_name']) ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                <?= htmlspecialchars($employee['department_name'] ?: 'No Department') ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                $<?= number_format($employee['basic_salary'] ?: 0) ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                $<?= number_format($totalAllowances) ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                $<?= number_format($totalDeductions) ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                                $<?= number_format($netSalary) ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                <button onclick="editSalaryStructure(<?= htmlspecialchars(json_encode($employee)) ?>)" class="text-blue-600 hover:text-blue-900">
                                    <i class="fas fa-edit mr-1"></i>Edit
                                </button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Salary Structure Modal -->
    <div id="salaryModal" class="hidden fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
        <div class="relative top-20 mx-auto p-5 border w-4/5 max-w-2xl shadow-lg rounded-md bg-white">
            <div class="mt-3">
                <h3 class="text-lg font-medium text-gray-900 mb-4">Salary Structure</h3>
                <form method="POST" class="space-y-6">
                    <input type="hidden" name="action" value="update_salary_structure">
                    <input type="hidden" name="employee_id" id="employee_id">
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Employee</label>
                        <input type="text" id="employee_name" readonly class="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 bg-gray-50">
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Basic Salary ($)</label>
                        <input type="number" name="basic_salary" id="basic_salary" required min="0" step="0.01" class="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2">
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Allowances</label>
                        <div id="allowances_container" class="space-y-2">
                            <div class="flex space-x-2">
                                <input type="text" placeholder="Allowance Name" class="flex-1 border border-gray-300 rounded-md px-3 py-2">
                                <input type="number" placeholder="Amount" min="0" step="0.01" class="w-32 border border-gray-300 rounded-md px-3 py-2">
                                <button type="button" onclick="addAllowance()" class="bg-green-600 text-white px-3 py-2 rounded-md hover:bg-green-700">
                                    <i class="fas fa-plus"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Deductions</label>
                        <div id="deductions_container" class="space-y-2">
                            <div class="flex space-x-2">
                                <input type="text" placeholder="Deduction Name" class="flex-1 border border-gray-300 rounded-md px-3 py-2">
                                <input type="number" placeholder="Amount" min="0" step="0.01" class="w-32 border border-gray-300 rounded-md px-3 py-2">
                                <button type="button" onclick="addDeduction()" class="bg-red-600 text-white px-3 py-2 rounded-md hover:bg-red-700">
                                    <i class="fas fa-plus"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                    
                    <div class="flex justify-end space-x-3 pt-4">
                        <button type="button" onclick="hideSalaryModal()" class="px-4 py-2 bg-gray-300 text-gray-700 rounded-md hover:bg-gray-400">Cancel</button>
                        <button type="submit" class="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700">Save Structure</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        function showSalaryModal() {
            document.getElementById('salaryModal').classList.remove('hidden');
        }
        function hideSalaryModal() {
            document.getElementById('salaryModal').classList.add('hidden');
        }
        
        function editSalaryStructure(employee) {
            document.getElementById('employee_id').value = employee.id;
            document.getElementById('employee_name').value = employee.first_name + ' ' + employee.last_name;
            document.getElementById('basic_salary').value = employee.basic_salary || '';
            
            // Clear and populate allowances
            const allowancesContainer = document.getElementById('allowances_container');
            allowancesContainer.innerHTML = '<div class="flex space-x-2"><input type="text" placeholder="Allowance Name" class="flex-1 border border-gray-300 rounded-md px-3 py-2"><input type="number" placeholder="Amount" min="0" step="0.01" class="w-32 border border-gray-300 rounded-md px-3 py-2"><button type="button" onclick="addAllowance()" class="bg-green-600 text-white px-3 py-2 rounded-md hover:bg-green-700"><i class="fas fa-plus"></i></button></div>';
            
            if (employee.allowances) {
                const allowances = JSON.parse(employee.allowances);
                Object.entries(allowances).forEach(([name, amount]) => {
                    addAllowanceRow(name, amount);
                });
            }
            
            // Clear and populate deductions
            const deductionsContainer = document.getElementById('deductions_container');
            deductionsContainer.innerHTML = '<div class="flex space-x-2"><input type="text" placeholder="Deduction Name" class="flex-1 border border-gray-300 rounded-md px-3 py-2"><input type="number" placeholder="Amount" min="0" step="0.01" class="w-32 border border-gray-300 rounded-md px-3 py-2"><button type="button" onclick="addDeduction()" class="bg-red-600 text-white px-3 py-2 rounded-md hover:bg-red-700"><i class="fas fa-plus"></i></button></div>';
            
            if (employee.deductions) {
                const deductions = JSON.parse(employee.deductions);
                Object.entries(deductions).forEach(([name, amount]) => {
                    addDeductionRow(name, amount);
                });
            }
            
            showSalaryModal();
        }
        
        function addAllowance() {
            const container = document.getElementById('allowances_container');
            const firstRow = container.firstElementChild;
            const name = firstRow.children[0].value;
            const amount = firstRow.children[1].value;
            
            if (name && amount) {
                addAllowanceRow(name, amount);
                firstRow.children[0].value = '';
                firstRow.children[1].value = '';
            }
        }
        
        function addAllowanceRow(name, amount) {
            const container = document.getElementById('allowances_container');
            const div = document.createElement('div');
            div.className = 'flex space-x-2 items-center';
            div.innerHTML = `
                <input type="hidden" name="allowances[${name}]" value="${amount}">
                <span class="flex-1 px-3 py-2 bg-gray-50 border border-gray-300 rounded-md">${name}</span>
                <span class="w-32 px-3 py-2 bg-gray-50 border border-gray-300 rounded-md">$${amount}</span>
                <button type="button" onclick="this.parentElement.remove()" class="bg-red-600 text-white px-3 py-2 rounded-md hover:bg-red-700">
                    <i class="fas fa-times"></i>
                </button>
            `;
            container.appendChild(div);
        }
        
        function addDeduction() {
            const container = document.getElementById('deductions_container');
            const firstRow = container.firstElementChild;
            const name = firstRow.children[0].value;
            const amount = firstRow.children[1].value;
            
            if (name && amount) {
                addDeductionRow(name, amount);
                firstRow.children[0].value = '';
                firstRow.children[1].value = '';
            }
        }
        
        function addDeductionRow(name, amount) {
            const container = document.getElementById('deductions_container');
            const div = document.createElement('div');
            div.className = 'flex space-x-2 items-center';
            div.innerHTML = `
                <input type="hidden" name="deductions[${name}]" value="${amount}">
                <span class="flex-1 px-3 py-2 bg-gray-50 border border-gray-300 rounded-md">${name}</span>
                <span class="w-32 px-3 py-2 bg-gray-50 border border-gray-300 rounded-md">$${amount}</span>
                <button type="button" onclick="this.parentElement.remove()" class="bg-red-600 text-white px-3 py-2 rounded-md hover:bg-red-700">
                    <i class="fas fa-times"></i>
                </button>
            `;
            container.appendChild(div);
        }
    </script>
    <?php
}

function renderTransactions($db) {
    // Get all transactions
    $stmt = $db->prepare("SELECT t.*, e.first_name, e.last_name FROM transactions t LEFT JOIN payrolls p ON t.payroll_id = p.id LEFT JOIN employees e ON p.employee_id = e.id ORDER BY t.created_at DESC LIMIT 50");
    $stmt->execute();
    $transactions = $stmt->fetchAll();
    
    // Get transaction summary
    $stmt = $db->prepare("SELECT type, SUM(amount) as total FROM transactions WHERE MONTH(created_at) = MONTH(CURDATE()) AND YEAR(created_at) = YEAR(CURDATE()) GROUP BY type");
    $stmt->execute();
    $summary = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
    ?>
    <div class="space-y-6">
        <div class="flex justify-between items-center">
            <h2 class="text-3xl font-bold text-gray-900">Transaction Management</h2>
            <button onclick="showTransactionModal()" class="bg-purple-600 text-white px-6 py-3 rounded-lg hover:bg-purple-700 transition duration-200">
                <i class="fas fa-plus mr-2"></i>Add Transaction
            </button>
        </div>

        <!-- Transaction Summary -->
        <div class="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div class="bg-white p-6 rounded-xl shadow-lg border-l-4 border-green-500">
                <div class="flex items-center">
                    <div class="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                        <i class="fas fa-money-bill-wave text-green-600 text-xl"></i>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm text-gray-500">Salary Payments</p>
                        <p class="text-2xl font-bold text-gray-900">$<?= number_format($summary['salary'] ?? 0) ?></p>
                    </div>
                </div>
            </div>
            
            <div class="bg-white p-6 rounded-xl shadow-lg border-l-4 border-blue-500">
                <div class="flex items-center">
                    <div class="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                        <i class="fas fa-hand-holding-usd text-blue-600 text-xl"></i>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm text-gray-500">Advances</p>
                        <p class="text-2xl font-bold text-gray-900">$<?= number_format($summary['advance'] ?? 0) ?></p>
                    </div>
                </div>
            </div>
            
            <div class="bg-white p-6 rounded-xl shadow-lg border-l-4 border-purple-500">
                <div class="flex items-center">
                    <div class="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                        <i class="fas fa-credit-card text-purple-600 text-xl"></i>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm text-gray-500">Loans</p>
                        <p class="text-2xl font-bold text-gray-900">$<?= number_format($summary['loan'] ?? 0) ?></p>
                    </div>
                </div>
            </div>
            
            <div class="bg-white p-6 rounded-xl shadow-lg border-l-4 border-red-500">
                <div class="flex items-center">
                    <div class="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center">
                        <i class="fas fa-receipt text-red-600 text-xl"></i>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm text-gray-500">Expenses</p>
                        <p class="text-2xl font-bold text-gray-900">$<?= number_format($summary['expense'] ?? 0) ?></p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Transactions List -->
        <div class="bg-white rounded-xl shadow-lg p-6">
            <h3 class="text-xl font-bold text-gray-900 mb-4">Recent Transactions</h3>
            
            <?php if (empty($transactions)): ?>
            <div class="text-center py-8">
                <i class="fas fa-exchange-alt text-gray-300 text-4xl mb-4"></i>
                <p class="text-gray-500">No transactions found.</p>
            </div>
            <?php else: ?>
            <div class="overflow-x-auto">
                <table class="min-w-full">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Date</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Type</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Employee</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Amount</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Description</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-200">
                        <?php foreach ($transactions as $transaction): ?>
                        <tr>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                <?= date('M j, Y', strtotime($transaction['created_at'])) ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <span class="px-2 py-1 text-xs font-semibold rounded-full 
                                    <?php
                                    switch ($transaction['type']) {
                                        case 'salary': echo 'bg-green-100 text-green-800'; break;
                                        case 'advance': echo 'bg-blue-100 text-blue-800'; break;
                                        case 'loan': echo 'bg-purple-100 text-purple-800'; break;
                                        case 'expense': echo 'bg-red-100 text-red-800'; break;
                                    }
                                    ?>">
                                    <?= ucfirst($transaction['type']) ?>
                                </span>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                <?= $transaction['first_name'] ? htmlspecialchars($transaction['first_name'] . ' ' . $transaction['last_name']) : 'N/A' ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                                $<?= number_format($transaction['amount']) ?>
                            </td>
                            <td class="px-6 py-4 text-sm text-gray-900">
                                <?= htmlspecialchars($transaction['description'] ?: 'No description') ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php endif; ?>
        </div>
    </div>
    <?php
}

function renderAccountsReports($db) {
    // Get monthly payroll data
    $stmt = $db->prepare("SELECT MONTH(created_at) as month, YEAR(created_at) as year, SUM(net_salary) as total FROM payrolls WHERE status = 'disbursed' GROUP BY YEAR(created_at), MONTH(created_at) ORDER BY year DESC, month DESC LIMIT 12");
    $stmt->execute();
    $monthlyPayroll = $stmt->fetchAll();
    
    // Get department-wise expenses
    $stmt = $db->prepare("SELECT d.name as department, SUM(p.net_salary) as total FROM payrolls p JOIN employees e ON p.employee_id = e.id LEFT JOIN departments d ON e.department_id = d.id WHERE p.status = 'disbursed' AND YEAR(p.created_at) = YEAR(CURDATE()) GROUP BY d.id, d.name");
    $stmt->execute();
    $departmentExpenses = $stmt->fetchAll();
    ?>
    <div class="space-y-6">
        <div class="flex justify-between items-center">
            <h2 class="text-3xl font-bold text-gray-900">Financial Reports</h2>
            <div class="flex space-x-2">
                <button class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">
                    <i class="fas fa-download mr-2"></i>Export PDF
                </button>
                <button class="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700">
                    <i class="fas fa-file-excel mr-2"></i>Export Excel
                </button>
            </div>
        </div>

        <!-- Report Summary -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div class="bg-white p-6 rounded-xl shadow-lg">
                <h3 class="text-lg font-semibold text-gray-900 mb-4">Monthly Payroll Trend</h3>
                <div class="space-y-2">
                    <?php foreach (array_slice($monthlyPayroll, 0, 6) as $data): ?>
                    <div class="flex justify-between items-center">
                        <span class="text-sm text-gray-500">
                            <?= date('M Y', mktime(0, 0, 0, $data['month'], 1, $data['year'])) ?>
                        </span>
                        <span class="text-sm font-medium text-gray-900">
                            $<?= number_format($data['total']) ?>
                        </span>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
            
            <div class="bg-white p-6 rounded-xl shadow-lg">
                <h3 class="text-lg font-semibold text-gray-900 mb-4">Department Expenses</h3>
                <div class="space-y-2">
                    <?php foreach ($departmentExpenses as $dept): ?>
                    <div class="flex justify-between items-center">
                        <span class="text-sm text-gray-500">
                            <?= htmlspecialchars($dept['department'] ?: 'No Department') ?>
                        </span>
                        <span class="text-sm font-medium text-gray-900">
                            $<?= number_format($dept['total']) ?>
                        </span>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
            
            <div class="bg-white p-6 rounded-xl shadow-lg">
                <h3 class="text-lg font-semibold text-gray-900 mb-4">Quick Stats</h3>
                <div class="space-y-3">
                    <div class="flex justify-between">
                        <span class="text-sm text-gray-500">YTD Payroll:</span>
                        <span class="text-sm font-medium text-gray-900">
                            $<?= number_format(array_sum(array_map(fn($p) => $p['total'], $monthlyPayroll))) ?>
                        </span>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-sm text-gray-500">Avg Monthly:</span>
                        <span class="text-sm font-medium text-gray-900">
                            $<?= number_format(array_sum(array_map(fn($p) => $p['total'], $monthlyPayroll)) / max(count($monthlyPayroll), 1)) ?>
                        </span>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-sm text-gray-500">Departments:</span>
                        <span class="text-sm font-medium text-gray-900"><?= count($departmentExpenses) ?></span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Detailed Reports -->
        <div class="bg-white rounded-xl shadow-lg p-6">
            <h3 class="text-xl font-bold text-gray-900 mb-4">Detailed Financial Reports</h3>
            <p class="text-gray-500">Comprehensive financial reporting interface would be implemented here with charts, graphs, and detailed breakdowns.</p>
        </div>
    </div>
    <?php
}
?>
