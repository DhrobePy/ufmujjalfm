<?php

// Test script to verify HR Management application setup

echo "HR Management System - Setup Test\n";
echo "==================================\n\n";

// Test 1: Check if autoloader works
echo "1. Testing autoloader... ";
try {
    require_once __DIR__ . '/vendor/autoload.php';
    echo "✓ OK\n";
} catch (Exception $e) {
    echo "✗ FAILED: " . $e->getMessage() . "\n";
    exit(1);
}

// Test 2: Check environment file
echo "2. Testing environment configuration... ";
if (file_exists(__DIR__ . '/.env')) {
    echo "✓ OK\n";
} else {
    echo "✗ FAILED: .env file not found\n";
}

// Test 3: Test database connection
echo "3. Testing database connection... ";
try {
    $database = new App\Core\Database();
    $db = $database->getConnection();
    echo "✓ OK\n";
} catch (Exception $e) {
    echo "✗ FAILED: " . $e->getMessage() . "\n";
}

// Test 4: Check core classes
echo "4. Testing core classes... ";
try {
    $router = new App\Core\Router();
    echo "✓ OK\n";
} catch (Exception $e) {
    echo "✗ FAILED: " . $e->getMessage() . "\n";
}

// Test 5: Check if required directories exist
echo "5. Testing directory structure... ";
$requiredDirs = [
    'src/controllers',
    'src/models', 
    'src/views',
    'src/core',
    'public',
    'database'
];

$allDirsExist = true;
foreach ($requiredDirs as $dir) {
    if (!is_dir(__DIR__ . '/' . $dir)) {
        echo "✗ FAILED: Directory $dir not found\n";
        $allDirsExist = false;
        break;
    }
}

if ($allDirsExist) {
    echo "✓ OK\n";
}

// Test 6: Check if key files exist
echo "6. Testing key files... ";
$requiredFiles = [
    'public/index.php',
    'src/core/Database.php',
    'src/core/Router.php',
    'database/schema.sql',
    'composer.json'
];

$allFilesExist = true;
foreach ($requiredFiles as $file) {
    if (!file_exists(__DIR__ . '/' . $file)) {
        echo "✗ FAILED: File $file not found\n";
        $allFilesExist = false;
        break;
    }
}

if ($allFilesExist) {
    echo "✓ OK\n";
}

echo "\nSetup test completed!\n";
echo "You can now start a web server to test the application:\n";
echo "php -S localhost:8000 -t public/\n";
