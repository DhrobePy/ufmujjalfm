<?php
// Employee Portal Functions - Complete Implementation

function renderAttendancePage($db, $employeeId) {
    // Get today's attendance
    $stmt = $db->prepare("SELECT * FROM attendance WHERE employee_id = ? AND DATE(check_in_time) = CURDATE()");
    $stmt->execute([$employeeId]);
    $todayAttendance = $stmt->fetch();
    
    // Get recent attendance records
    $stmt = $db->prepare("SELECT * FROM attendance WHERE employee_id = ? ORDER BY check_in_time DESC LIMIT 10");
    $stmt->execute([$employeeId]);
    $recentAttendance = $stmt->fetchAll();
    
    // Get monthly stats
    $stmt = $db->prepare("SELECT COUNT(*) as days_present FROM attendance WHERE employee_id = ? AND MONTH(check_in_time) = MONTH(CURDATE()) AND YEAR(check_in_time) = YEAR(CURDATE())");
    $stmt->execute([$employeeId]);
    $monthlyStats = $stmt->fetch();
    ?>
    <div class="space-y-6">
        <div class="flex justify-between items-center">
            <h2 class="text-3xl font-bold text-gray-900">Attendance Management</h2>
            <div class="text-sm text-gray-500">
                <i class="fas fa-calendar mr-1"></i><?= date('F j, Y') ?>
            </div>
        </div>

        <!-- Today's Status -->
        <div class="bg-gradient-to-r from-blue-500 to-purple-600 rounded-xl shadow-lg p-6 text-white">
            <div class="flex items-center justify-between">
                <div>
                    <h3 class="text-xl font-bold mb-2">Today's Status</h3>
                    <?php if ($todayAttendance): ?>
                        <p class="text-blue-100">Check In: <?= date('h:i A', strtotime($todayAttendance['check_in_time'])) ?></p>
                        <?php if ($todayAttendance['check_out_time']): ?>
                            <p class="text-blue-100">Check Out: <?= date('h:i A', strtotime($todayAttendance['check_out_time'])) ?></p>
                            <p class="text-green-200 font-semibold">✓ Day Completed</p>
                        <?php else: ?>
                            <p class="text-yellow-200 font-semibold">⏰ Currently Working</p>
                        <?php endif; ?>
                    <?php else: ?>
                        <p class="text-red-200 font-semibold">❌ Not Clocked In</p>
                    <?php endif; ?>
                </div>
                <div class="text-right">
                    <?php if (!$todayAttendance): ?>
                        <form method="POST" class="inline">
                            <input type="hidden" name="action" value="clock_in">
                            <button type="submit" class="bg-white bg-opacity-20 hover:bg-opacity-30 text-white font-semibold py-3 px-6 rounded-lg transition duration-200">
                                <i class="fas fa-play mr-2"></i>Clock In
                            </button>
                        </form>
                    <?php elseif (!$todayAttendance['check_out_time']): ?>
                        <form method="POST" class="inline">
                            <input type="hidden" name="action" value="clock_out">
                            <button type="submit" class="bg-white bg-opacity-20 hover:bg-opacity-30 text-white font-semibold py-3 px-6 rounded-lg transition duration-200">
                                <i class="fas fa-stop mr-2"></i>Clock Out
                            </button>
                        </form>
                    <?php else: ?>
                        <div class="bg-white bg-opacity-20 text-white font-semibold py-3 px-6 rounded-lg">
                            <i class="fas fa-check mr-2"></i>Completed
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Monthly Stats -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div class="bg-white p-6 rounded-xl shadow-lg">
                <div class="flex items-center">
                    <div class="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                        <i class="fas fa-calendar-check text-green-600 text-xl"></i>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm text-gray-500">Days Present</p>
                        <p class="text-2xl font-bold text-gray-900"><?= $monthlyStats['days_present'] ?></p>
                    </div>
                </div>
            </div>
            
            <div class="bg-white p-6 rounded-xl shadow-lg">
                <div class="flex items-center">
                    <div class="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                        <i class="fas fa-clock text-blue-600 text-xl"></i>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm text-gray-500">Working Days</p>
                        <p class="text-2xl font-bold text-gray-900"><?= date('j') ?></p>
                    </div>
                </div>
            </div>
            
            <div class="bg-white p-6 rounded-xl shadow-lg">
                <div class="flex items-center">
                    <div class="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                        <i class="fas fa-percentage text-purple-600 text-xl"></i>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm text-gray-500">Attendance Rate</p>
                        <p class="text-2xl font-bold text-gray-900"><?= round(($monthlyStats['days_present'] / date('j')) * 100) ?>%</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Recent Attendance -->
        <div class="bg-white rounded-xl shadow-lg p-6">
            <h3 class="text-xl font-bold text-gray-900 mb-4">Recent Attendance</h3>
            <div class="overflow-x-auto">
                <table class="min-w-full">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Date</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Check In</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Check Out</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Hours</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-200">
                        <?php foreach ($recentAttendance as $record): ?>
                        <tr>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                <?= date('M j, Y', strtotime($record['check_in_time'])) ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                <?= date('h:i A', strtotime($record['check_in_time'])) ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                <?= $record['check_out_time'] ? date('h:i A', strtotime($record['check_out_time'])) : '-' ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                <?php
                                if ($record['check_out_time']) {
                                    $hours = (strtotime($record['check_out_time']) - strtotime($record['check_in_time'])) / 3600;
                                    echo number_format($hours, 1) . 'h';
                                } else {
                                    echo '-';
                                }
                                ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <span class="px-2 py-1 text-xs font-semibold rounded-full <?= $record['status'] === 'present' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800' ?>">
                                    <?= ucfirst($record['status']) ?>
                                </span>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <?php
}

function renderLeavePage($db, $employeeId) {
    // Get employee's leave applications
    $stmt = $db->prepare("SELECT * FROM leaves WHERE employee_id = ? ORDER BY created_at DESC");
    $stmt->execute([$employeeId]);
    $leaves = $stmt->fetchAll();
    
    // Handle form submission
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && $_POST['action'] === 'apply_leave') {
        try {
            $stmt = $db->prepare("INSERT INTO leaves (employee_id, leave_type, start_date, end_date, reason, status, created_at) VALUES (?, ?, ?, ?, ?, 'pending', NOW())");
            $stmt->execute([
                $employeeId,
                $_POST['leave_type'],
                $_POST['start_date'],
                $_POST['end_date'],
                $_POST['reason']
            ]);
            header('Location: ?page=leave&success=1');
            exit;
        } catch (PDOException $e) {
            $error = "Failed to submit leave application.";
        }
    }
    ?>
    <div class="space-y-6">
        <div class="flex justify-between items-center">
            <h2 class="text-3xl font-bold text-gray-900">Leave Management</h2>
            <button onclick="showLeaveModal()" class="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition duration-200">
                <i class="fas fa-plus mr-2"></i>Apply for Leave
            </button>
        </div>

        <?php if (isset($_GET['success'])): ?>
        <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 rounded">
            <i class="fas fa-check-circle mr-2"></i>Leave application submitted successfully!
        </div>
        <?php endif; ?>

        <!-- Leave Balance -->
        <div class="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div class="bg-white p-6 rounded-xl shadow-lg border-l-4 border-blue-500">
                <div class="flex items-center">
                    <div class="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                        <i class="fas fa-calendar text-blue-600 text-xl"></i>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm text-gray-500">Annual Leave</p>
                        <p class="text-2xl font-bold text-gray-900">15 days</p>
                    </div>
                </div>
            </div>
            
            <div class="bg-white p-6 rounded-xl shadow-lg border-l-4 border-green-500">
                <div class="flex items-center">
                    <div class="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                        <i class="fas fa-user-md text-green-600 text-xl"></i>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm text-gray-500">Sick Leave</p>
                        <p class="text-2xl font-bold text-gray-900">10 days</p>
                    </div>
                </div>
            </div>
            
            <div class="bg-white p-6 rounded-xl shadow-lg border-l-4 border-yellow-500">
                <div class="flex items-center">
                    <div class="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
                        <i class="fas fa-clock text-yellow-600 text-xl"></i>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm text-gray-500">Pending</p>
                        <p class="text-2xl font-bold text-gray-900"><?= count(array_filter($leaves, fn($l) => $l['status'] === 'pending')) ?></p>
                    </div>
                </div>
            </div>
            
            <div class="bg-white p-6 rounded-xl shadow-lg border-l-4 border-purple-500">
                <div class="flex items-center">
                    <div class="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                        <i class="fas fa-check text-purple-600 text-xl"></i>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm text-gray-500">Approved</p>
                        <p class="text-2xl font-bold text-gray-900"><?= count(array_filter($leaves, fn($l) => $l['status'] === 'approved')) ?></p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Leave Applications -->
        <div class="bg-white rounded-xl shadow-lg p-6">
            <h3 class="text-xl font-bold text-gray-900 mb-4">Leave Applications</h3>
            
            <?php if (empty($leaves)): ?>
            <div class="text-center py-8">
                <i class="fas fa-calendar-times text-gray-300 text-4xl mb-4"></i>
                <p class="text-gray-500">No leave applications found.</p>
                <button onclick="showLeaveModal()" class="mt-4 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">
                    Apply for Your First Leave
                </button>
            </div>
            <?php else: ?>
            <div class="overflow-x-auto">
                <table class="min-w-full">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Leave Type</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Start Date</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">End Date</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Days</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Applied On</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-200">
                        <?php foreach ($leaves as $leave): ?>
                        <tr>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                                <?= htmlspecialchars($leave['leave_type']) ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                <?= date('M j, Y', strtotime($leave['start_date'])) ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                <?= date('M j, Y', strtotime($leave['end_date'])) ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                <?php
                                $days = (strtotime($leave['end_date']) - strtotime($leave['start_date'])) / (60 * 60 * 24) + 1;
                                echo $days . ' day' . ($days > 1 ? 's' : '');
                                ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <span class="px-2 py-1 text-xs font-semibold rounded-full 
                                    <?php
                                    switch ($leave['status']) {
                                        case 'pending': echo 'bg-yellow-100 text-yellow-800'; break;
                                        case 'approved': echo 'bg-green-100 text-green-800'; break;
                                        case 'rejected': echo 'bg-red-100 text-red-800'; break;
                                    }
                                    ?>">
                                    <?= ucfirst($leave['status']) ?>
                                </span>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                <?= date('M j, Y', strtotime($leave['created_at'])) ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Leave Application Modal -->
    <div id="leaveModal" class="hidden fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
        <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
            <div class="mt-3">
                <h3 class="text-lg font-medium text-gray-900 mb-4">Apply for Leave</h3>
                <form method="POST" class="space-y-4">
                    <input type="hidden" name="action" value="apply_leave">
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Leave Type</label>
                        <select name="leave_type" required class="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2">
                            <option value="">Select Leave Type</option>
                            <option value="Annual Leave">Annual Leave</option>
                            <option value="Sick Leave">Sick Leave</option>
                            <option value="Personal Leave">Personal Leave</option>
                            <option value="Emergency Leave">Emergency Leave</option>
                        </select>
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Start Date</label>
                        <input type="date" name="start_date" required class="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2">
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700">End Date</label>
                        <input type="date" name="end_date" required class="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2">
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Reason</label>
                        <textarea name="reason" rows="3" required class="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2" placeholder="Please provide reason for leave"></textarea>
                    </div>
                    
                    <div class="flex justify-end space-x-3 pt-4">
                        <button type="button" onclick="hideLeaveModal()" class="px-4 py-2 bg-gray-300 text-gray-700 rounded-md hover:bg-gray-400">Cancel</button>
                        <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">Submit Application</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        function showLeaveModal() {
            document.getElementById('leaveModal').classList.remove('hidden');
        }
        function hideLeaveModal() {
            document.getElementById('leaveModal').classList.add('hidden');
        }
    </script>
    <?php
}

function renderAdvancePage($db, $employeeId) {
    // Get employee's salary advance applications
    $stmt = $db->prepare("SELECT * FROM salary_advances WHERE employee_id = ? ORDER BY created_at DESC");
    $stmt->execute([$employeeId]);
    $advances = $stmt->fetchAll();
    
    // Handle form submission
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && $_POST['action'] === 'apply_advance') {
        try {
            $stmt = $db->prepare("INSERT INTO salary_advances (employee_id, amount, reason, status, created_at) VALUES (?, ?, ?, 'pending', NOW())");
            $stmt->execute([
                $employeeId,
                $_POST['amount'],
                $_POST['reason']
            ]);
            header('Location: ?page=advance&success=1');
            exit;
        } catch (PDOException $e) {
            $error = "Failed to submit advance application.";
        }
    }
    ?>
    <div class="space-y-6">
        <div class="flex justify-between items-center">
            <h2 class="text-3xl font-bold text-gray-900">Salary Advance</h2>
            <button onclick="showAdvanceModal()" class="bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 transition duration-200">
                <i class="fas fa-plus mr-2"></i>Request Advance
            </button>
        </div>

        <?php if (isset($_GET['success'])): ?>
        <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 rounded">
            <i class="fas fa-check-circle mr-2"></i>Salary advance request submitted successfully!
        </div>
        <?php endif; ?>

        <!-- Advance Summary -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div class="bg-white p-6 rounded-xl shadow-lg border-l-4 border-yellow-500">
                <div class="flex items-center">
                    <div class="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
                        <i class="fas fa-clock text-yellow-600 text-xl"></i>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm text-gray-500">Pending Requests</p>
                        <p class="text-2xl font-bold text-gray-900"><?= count(array_filter($advances, fn($a) => $a['status'] === 'pending')) ?></p>
                    </div>
                </div>
            </div>
            
            <div class="bg-white p-6 rounded-xl shadow-lg border-l-4 border-green-500">
                <div class="flex items-center">
                    <div class="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                        <i class="fas fa-check text-green-600 text-xl"></i>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm text-gray-500">Approved Amount</p>
                        <p class="text-2xl font-bold text-gray-900">
                            $<?= number_format(array_sum(array_map(fn($a) => $a['status'] === 'approved' ? $a['amount'] : 0, $advances))) ?>
                        </p>
                    </div>
                </div>
            </div>
            
            <div class="bg-white p-6 rounded-xl shadow-lg border-l-4 border-blue-500">
                <div class="flex items-center">
                    <div class="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                        <i class="fas fa-hand-holding-usd text-blue-600 text-xl"></i>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm text-gray-500">Total Requests</p>
                        <p class="text-2xl font-bold text-gray-900"><?= count($advances) ?></p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Advance Applications -->
        <div class="bg-white rounded-xl shadow-lg p-6">
            <h3 class="text-xl font-bold text-gray-900 mb-4">Advance Requests</h3>
            
            <?php if (empty($advances)): ?>
            <div class="text-center py-8">
                <i class="fas fa-hand-holding-usd text-gray-300 text-4xl mb-4"></i>
                <p class="text-gray-500">No salary advance requests found.</p>
                <button onclick="showAdvanceModal()" class="mt-4 bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700">
                    Request Your First Advance
                </button>
            </div>
            <?php else: ?>
            <div class="overflow-x-auto">
                <table class="min-w-full">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Amount</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Reason</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Requested On</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-200">
                        <?php foreach ($advances as $advance): ?>
                        <tr>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                                $<?= number_format($advance['amount']) ?>
                            </td>
                            <td class="px-6 py-4 text-sm text-gray-900">
                                <?= htmlspecialchars($advance['reason']) ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <span class="px-2 py-1 text-xs font-semibold rounded-full 
                                    <?php
                                    switch ($advance['status']) {
                                        case 'pending': echo 'bg-yellow-100 text-yellow-800'; break;
                                        case 'approved': echo 'bg-green-100 text-green-800'; break;
                                        case 'rejected': echo 'bg-red-100 text-red-800'; break;
                                    }
                                    ?>">
                                    <?= ucfirst($advance['status']) ?>
                                </span>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                <?= date('M j, Y', strtotime($advance['created_at'])) ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Advance Request Modal -->
    <div id="advanceModal" class="hidden fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
        <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
            <div class="mt-3">
                <h3 class="text-lg font-medium text-gray-900 mb-4">Request Salary Advance</h3>
                <form method="POST" class="space-y-4">
                    <input type="hidden" name="action" value="apply_advance">
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Amount ($)</label>
                        <input type="number" name="amount" required min="1" step="0.01" class="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2" placeholder="Enter amount">
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Reason</label>
                        <textarea name="reason" rows="4" required class="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2" placeholder="Please provide reason for salary advance"></textarea>
                    </div>
                    
                    <div class="bg-yellow-50 border border-yellow-200 rounded-md p-3">
                        <p class="text-sm text-yellow-800">
                            <i class="fas fa-info-circle mr-1"></i>
                            Note: Salary advance will be deducted from your next payroll.
                        </p>
                    </div>
                    
                    <div class="flex justify-end space-x-3 pt-4">
                        <button type="button" onclick="hideAdvanceModal()" class="px-4 py-2 bg-gray-300 text-gray-700 rounded-md hover:bg-gray-400">Cancel</button>
                        <button type="submit" class="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700">Submit Request</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        function showAdvanceModal() {
            document.getElementById('advanceModal').classList.remove('hidden');
        }
        function hideAdvanceModal() {
            document.getElementById('advanceModal').classList.add('hidden');
        }
    </script>
    <?php
}

function renderLoanPage($db, $employeeId) {
    // Get employee's loan applications
    $stmt = $db->prepare("SELECT * FROM loans WHERE employee_id = ? ORDER BY created_at DESC");
    $stmt->execute([$employeeId]);
    $loans = $stmt->fetchAll();
    
    // Handle form submission
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && $_POST['action'] === 'apply_loan') {
        try {
            $emiAmount = $_POST['amount'] / $_POST['installments'];
            $stmt = $db->prepare("INSERT INTO loans (employee_id, amount, emi_amount, total_installments, reason, status, created_at) VALUES (?, ?, ?, ?, ?, 'pending', NOW())");
            $stmt->execute([
                $employeeId,
                $_POST['amount'],
                $emiAmount,
                $_POST['installments'],
                $_POST['reason']
            ]);
            header('Location: ?page=loan&success=1');
            exit;
        } catch (PDOException $e) {
            $error = "Failed to submit loan application.";
        }
    }
    ?>
    <div class="space-y-6">
        <div class="flex justify-between items-center">
            <h2 class="text-3xl font-bold text-gray-900">Loan Management</h2>
            <button onclick="showLoanModal()" class="bg-purple-600 text-white px-6 py-3 rounded-lg hover:bg-purple-700 transition duration-200">
                <i class="fas fa-plus mr-2"></i>Apply for Loan
            </button>
        </div>

        <?php if (isset($_GET['success'])): ?>
        <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 rounded">
            <i class="fas fa-check-circle mr-2"></i>Loan application submitted successfully!
        </div>
        <?php endif; ?>

        <!-- Loan Summary -->
        <div class="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div class="bg-white p-6 rounded-xl shadow-lg border-l-4 border-blue-500">
                <div class="flex items-center">
                    <div class="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                        <i class="fas fa-credit-card text-blue-600 text-xl"></i>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm text-gray-500">Active Loans</p>
                        <p class="text-2xl font-bold text-gray-900"><?= count(array_filter($loans, fn($l) => $l['status'] === 'approved')) ?></p>
                    </div>
                </div>
            </div>
            
            <div class="bg-white p-6 rounded-xl shadow-lg border-l-4 border-green-500">
                <div class="flex items-center">
                    <div class="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                        <i class="fas fa-dollar-sign text-green-600 text-xl"></i>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm text-gray-500">Total Borrowed</p>
                        <p class="text-2xl font-bold text-gray-900">
                            $<?= number_format(array_sum(array_map(fn($l) => $l['status'] === 'approved' ? $l['amount'] : 0, $loans))) ?>
                        </p>
                    </div>
                </div>
            </div>
            
            <div class="bg-white p-6 rounded-xl shadow-lg border-l-4 border-yellow-500">
                <div class="flex items-center">
                    <div class="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
                        <i class="fas fa-clock text-yellow-600 text-xl"></i>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm text-gray-500">Pending</p>
                        <p class="text-2xl font-bold text-gray-900"><?= count(array_filter($loans, fn($l) => $l['status'] === 'pending')) ?></p>
                    </div>
                </div>
            </div>
            
            <div class="bg-white p-6 rounded-xl shadow-lg border-l-4 border-purple-500">
                <div class="flex items-center">
                    <div class="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                        <i class="fas fa-calendar-alt text-purple-600 text-xl"></i>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm text-gray-500">Monthly EMI</p>
                        <p class="text-2xl font-bold text-gray-900">
                            $<?= number_format(array_sum(array_map(fn($l) => $l['status'] === 'approved' ? $l['emi_amount'] : 0, $loans))) ?>
                        </p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Loan Applications -->
        <div class="bg-white rounded-xl shadow-lg p-6">
            <h3 class="text-xl font-bold text-gray-900 mb-4">Loan Applications</h3>
            
            <?php if (empty($loans)): ?>
            <div class="text-center py-8">
                <i class="fas fa-credit-card text-gray-300 text-4xl mb-4"></i>
                <p class="text-gray-500">No loan applications found.</p>
                <button onclick="showLoanModal()" class="mt-4 bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700">
                    Apply for Your First Loan
                </button>
            </div>
            <?php else: ?>
            <div class="overflow-x-auto">
                <table class="min-w-full">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Amount</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">EMI</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Installments</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Paid</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Applied On</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-200">
                        <?php foreach ($loans as $loan): ?>
                        <tr>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                                $<?= number_format($loan['amount']) ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                $<?= number_format($loan['emi_amount']) ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                <?= $loan['total_installments'] ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                <?= $loan['paid_installments'] ?>/<?= $loan['total_installments'] ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <span class="px-2 py-1 text-xs font-semibold rounded-full 
                                    <?php
                                    switch ($loan['status']) {
                                        case 'pending': echo 'bg-yellow-100 text-yellow-800'; break;
                                        case 'approved': echo 'bg-green-100 text-green-800'; break;
                                        case 'rejected': echo 'bg-red-100 text-red-800'; break;
                                        case 'paid': echo 'bg-blue-100 text-blue-800'; break;
                                    }
                                    ?>">
                                    <?= ucfirst($loan['status']) ?>
                                </span>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                <?= date('M j, Y', strtotime($loan['created_at'])) ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Loan Application Modal -->
    <div id="loanModal" class="hidden fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
        <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
            <div class="mt-3">
                <h3 class="text-lg font-medium text-gray-900 mb-4">Apply for Loan</h3>
                <form method="POST" class="space-y-4">
                    <input type="hidden" name="action" value="apply_loan">
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Loan Amount ($)</label>
                        <input type="number" name="amount" required min="1" step="0.01" class="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2" placeholder="Enter loan amount">
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Number of Installments</label>
                        <select name="installments" required class="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2">
                            <option value="">Select Installments</option>
                            <option value="6">6 months</option>
                            <option value="12">12 months</option>
                            <option value="18">18 months</option>
                            <option value="24">24 months</option>
                            <option value="36">36 months</option>
                        </select>
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Purpose</label>
                        <textarea name="reason" rows="3" required class="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2" placeholder="Please provide purpose of loan"></textarea>
                    </div>
                    
                    <div class="bg-blue-50 border border-blue-200 rounded-md p-3">
                        <p class="text-sm text-blue-800">
                            <i class="fas fa-info-circle mr-1"></i>
                            EMI will be automatically calculated and deducted from your monthly salary.
                        </p>
                    </div>
                    
                    <div class="flex justify-end space-x-3 pt-4">
                        <button type="button" onclick="hideLoanModal()" class="px-4 py-2 bg-gray-300 text-gray-700 rounded-md hover:bg-gray-400">Cancel</button>
                        <button type="submit" class="px-4 py-2 bg-purple-600 text-white rounded-md hover:bg-purple-700">Submit Application</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        function showLoanModal() {
            document.getElementById('loanModal').classList.remove('hidden');
        }
        function hideLoanModal() {
            document.getElementById('loanModal').classList.add('hidden');
        }
    </script>
    <?php
}

function renderProfilePage($db, $employeeId) {
    // Get employee profile
    $stmt = $db->prepare("SELECT e.*, u.email, d.name as department_name FROM employees e JOIN users u ON e.user_id = u.id LEFT JOIN departments d ON e.department_id = d.id WHERE e.id = ?");
    $stmt->execute([$employeeId]);
    $employee = $stmt->fetch();
    
    if (!$employee) {
        echo '<div class="text-center py-8"><p class="text-red-500">Employee profile not found.</p></div>';
        return;
    }
    ?>
    <div class="space-y-6">
        <div class="flex justify-between items-center">
            <h2 class="text-3xl font-bold text-gray-900">Employee Profile</h2>
            <button onclick="showEditModal()" class="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition duration-200">
                <i class="fas fa-edit mr-2"></i>Edit Profile
            </button>
        </div>

        <!-- Profile Card -->
        <div class="bg-white rounded-xl shadow-lg overflow-hidden">
            <div class="bg-gradient-to-r from-blue-500 to-purple-600 px-6 py-8">
                <div class="flex items-center space-x-6">
                    <div class="w-24 h-24 bg-white bg-opacity-20 rounded-full flex items-center justify-center">
                        <i class="fas fa-user text-white text-4xl"></i>
                    </div>
                    <div class="text-white">
                        <h3 class="text-2xl font-bold"><?= htmlspecialchars($employee['first_name'] . ' ' . $employee['last_name']) ?></h3>
                        <p class="text-blue-100"><?= htmlspecialchars($employee['department_name'] ?: 'No Department') ?></p>
                        <p class="text-blue-100"><?= htmlspecialchars($employee['email']) ?></p>
                    </div>
                </div>
            </div>
            
            <div class="p-6">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <h4 class="text-lg font-semibold text-gray-900 mb-4">Personal Information</h4>
                        <div class="space-y-3">
                            <div class="flex justify-between">
                                <span class="text-gray-500">Phone:</span>
                                <span class="text-gray-900"><?= htmlspecialchars($employee['phone'] ?: 'Not provided') ?></span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-gray-500">Date of Birth:</span>
                                <span class="text-gray-900"><?= $employee['date_of_birth'] ? date('M j, Y', strtotime($employee['date_of_birth'])) : 'Not provided' ?></span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-gray-500">Address:</span>
                                <span class="text-gray-900"><?= htmlspecialchars($employee['address'] ?: 'Not provided') ?></span>
                            </div>
                        </div>
                    </div>
                    
                    <div>
                        <h4 class="text-lg font-semibold text-gray-900 mb-4">Employment Information</h4>
                        <div class="space-y-3">
                            <div class="flex justify-between">
                                <span class="text-gray-500">Date of Joining:</span>
                                <span class="text-gray-900"><?= $employee['date_of_joining'] ? date('M j, Y', strtotime($employee['date_of_joining'])) : 'Not provided' ?></span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-gray-500">Status:</span>
                                <span class="px-2 py-1 text-xs font-semibold rounded-full <?= $employee['status'] === 'active' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800' ?>">
                                    <?= ucfirst($employee['status']) ?>
                                </span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-gray-500">Employee ID:</span>
                                <span class="text-gray-900">EMP-<?= str_pad($employee['id'], 4, '0', STR_PAD_LEFT) ?></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Quick Actions -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div class="bg-white p-6 rounded-xl shadow-lg text-center">
                <div class="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <i class="fas fa-file-download text-blue-600 text-2xl"></i>
                </div>
                <h3 class="text-lg font-semibold text-gray-900 mb-2">Employment Certificate</h3>
                <p class="text-gray-500 text-sm mb-4">Download your employment certificate</p>
                <button class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition duration-200">
                    <i class="fas fa-download mr-2"></i>Download
                </button>
            </div>
            
            <div class="bg-white p-6 rounded-xl shadow-lg text-center">
                <div class="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <i class="fas fa-file-invoice-dollar text-green-600 text-2xl"></i>
                </div>
                <h3 class="text-lg font-semibold text-gray-900 mb-2">Salary Certificate</h3>
                <p class="text-gray-500 text-sm mb-4">Download your salary certificate</p>
                <button class="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition duration-200">
                    <i class="fas fa-download mr-2"></i>Download
                </button>
            </div>
            
            <div class="bg-white p-6 rounded-xl shadow-lg text-center">
                <div class="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <i class="fas fa-key text-purple-600 text-2xl"></i>
                </div>
                <h3 class="text-lg font-semibold text-gray-900 mb-2">Change Password</h3>
                <p class="text-gray-500 text-sm mb-4">Update your login password</p>
                <button class="bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 transition duration-200">
                    <i class="fas fa-edit mr-2"></i>Change
                </button>
            </div>
        </div>
    </div>

    <!-- Edit Profile Modal -->
    <div id="editModal" class="hidden fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
        <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
            <div class="mt-3">
                <h3 class="text-lg font-medium text-gray-900 mb-4">Edit Profile</h3>
                <form method="POST" class="space-y-4">
                    <input type="hidden" name="action" value="update_profile">
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Phone</label>
                        <input type="text" name="phone" value="<?= htmlspecialchars($employee['phone']) ?>" class="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2">
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Date of Birth</label>
                        <input type="date" name="date_of_birth" value="<?= $employee['date_of_birth'] ?>" class="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2">
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Address</label>
                        <textarea name="address" rows="3" class="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2"><?= htmlspecialchars($employee['address']) ?></textarea>
                    </div>
                    
                    <div class="flex justify-end space-x-3 pt-4">
                        <button type="button" onclick="hideEditModal()" class="px-4 py-2 bg-gray-300 text-gray-700 rounded-md hover:bg-gray-400">Cancel</button>
                        <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">Update Profile</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        function showEditModal() {
            document.getElementById('editModal').classList.remove('hidden');
        }
        function hideEditModal() {
            document.getElementById('editModal').classList.add('hidden');
        }
    </script>
    <?php
}

function renderPayslipPage($db, $employeeId) {
    // Get employee's payslips
    $stmt = $db->prepare("SELECT * FROM payrolls WHERE employee_id = ? ORDER BY year DESC, month DESC LIMIT 12");
    $stmt->execute([$employeeId]);
    $payslips = $stmt->fetchAll();
    ?>
    <div class="space-y-6">
        <div class="flex justify-between items-center">
            <h2 class="text-3xl font-bold text-gray-900">Payslips</h2>
            <div class="text-sm text-gray-500">
                <i class="fas fa-calendar mr-1"></i>Last 12 months
            </div>
        </div>

        <!-- Payslip Summary -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div class="bg-white p-6 rounded-xl shadow-lg border-l-4 border-green-500">
                <div class="flex items-center">
                    <div class="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                        <i class="fas fa-dollar-sign text-green-600 text-xl"></i>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm text-gray-500">Last Salary</p>
                        <p class="text-2xl font-bold text-gray-900">
                            $<?= !empty($payslips) ? number_format($payslips[0]['net_salary']) : '0' ?>
                        </p>
                    </div>
                </div>
            </div>
            
            <div class="bg-white p-6 rounded-xl shadow-lg border-l-4 border-blue-500">
                <div class="flex items-center">
                    <div class="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                        <i class="fas fa-chart-line text-blue-600 text-xl"></i>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm text-gray-500">YTD Earnings</p>
                        <p class="text-2xl font-bold text-gray-900">
                            $<?= number_format(array_sum(array_map(fn($p) => $p['net_salary'], $payslips))) ?>
                        </p>
                    </div>
                </div>
            </div>
            
            <div class="bg-white p-6 rounded-xl shadow-lg border-l-4 border-purple-500">
                <div class="flex items-center">
                    <div class="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                        <i class="fas fa-file-invoice text-purple-600 text-xl"></i>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm text-gray-500">Total Payslips</p>
                        <p class="text-2xl font-bold text-gray-900"><?= count($payslips) ?></p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Payslips List -->
        <div class="bg-white rounded-xl shadow-lg p-6">
            <h3 class="text-xl font-bold text-gray-900 mb-4">Payslip History</h3>
            
            <?php if (empty($payslips)): ?>
            <div class="text-center py-8">
                <i class="fas fa-file-invoice text-gray-300 text-4xl mb-4"></i>
                <p class="text-gray-500">No payslips available yet.</p>
                <p class="text-sm text-gray-400 mt-2">Payslips will appear here once payroll is processed.</p>
            </div>
            <?php else: ?>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <?php foreach ($payslips as $payslip): ?>
                <div class="border border-gray-200 rounded-lg p-4 hover:shadow-md transition duration-200">
                    <div class="flex items-center justify-between mb-3">
                        <div>
                            <h4 class="font-semibold text-gray-900">
                                <?= date('F Y', mktime(0, 0, 0, $payslip['month'], 1, $payslip['year'])) ?>
                            </h4>
                            <p class="text-sm text-gray-500">Net Salary: $<?= number_format($payslip['net_salary']) ?></p>
                        </div>
                        <span class="px-2 py-1 text-xs font-semibold rounded-full 
                            <?php
                            switch ($payslip['status']) {
                                case 'pending': echo 'bg-yellow-100 text-yellow-800'; break;
                                case 'approved': echo 'bg-blue-100 text-blue-800'; break;
                                case 'disbursed': echo 'bg-green-100 text-green-800'; break;
                            }
                            ?>">
                            <?= ucfirst($payslip['status']) ?>
                        </span>
                    </div>
                    
                    <div class="space-y-2 text-sm">
                        <div class="flex justify-between">
                            <span class="text-gray-500">Gross Salary:</span>
                            <span class="text-gray-900">$<?= number_format($payslip['gross_salary']) ?></span>
                        </div>
                        <div class="flex justify-between">
                            <span class="text-gray-500">Net Salary:</span>
                            <span class="font-semibold text-gray-900">$<?= number_format($payslip['net_salary']) ?></span>
                        </div>
                    </div>
                    
                    <div class="mt-4 pt-3 border-t border-gray-200">
                        <button class="w-full bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition duration-200 text-sm">
                            <i class="fas fa-download mr-2"></i>Download PDF
                        </button>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </div>
    </div>
    <?php
}
?>
