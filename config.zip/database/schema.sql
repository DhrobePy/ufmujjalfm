-- HR Management System Database Schema

-- Create database
CREATE DATABASE IF NOT EXISTS hr_management;
USE hr_management;

-- Users Table
CREATE TABLE `users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `email` VARCHAR(255) NOT NULL UNIQUE,
  `password` VARCHAR(255) NOT NULL,
  `role` ENUM('employee', 'accounts', 'admin') NOT NULL,
  `is_active` BOOLEAN DEFAULT TRUE,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Departments Table
CREATE TABLE `departments` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(255) NOT NULL,
  `description` TEXT,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Designations Table
CREATE TABLE `designations` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(255) NOT NULL,
  `department_id` INT,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`department_id`) REFERENCES `departments`(`id`)
);

-- Branches Table
CREATE TABLE `branches` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(255) NOT NULL,
  `address` TEXT,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Employees Table
CREATE TABLE `employees` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `employee_id` VARCHAR(50) UNIQUE NOT NULL,
  `department_id` INT NOT NULL,
  `designation_id` INT NOT NULL,
  `branch_id` INT NOT NULL,
  `first_name` VARCHAR(255) NOT NULL,
  `last_name` VARCHAR(255) NOT NULL,
  `date_of_birth` DATE,
  `gender` ENUM('Male', 'Female', 'Other'),
  `phone_number` VARCHAR(20),
  `address` TEXT,
  `date_of_joining` DATE,
  `profile_picture` VARCHAR(255),
  `is_active` BOOLEAN DEFAULT TRUE,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`department_id`) REFERENCES `departments`(`id`),
  FOREIGN KEY (`designation_id`) REFERENCES `designations`(`id`),
  FOREIGN KEY (`branch_id`) REFERENCES `branches`(`id`)
);

-- Attendance Table
CREATE TABLE `attendance` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `employee_id` INT NOT NULL,
  `date` DATE NOT NULL,
  `check_in` TIME,
  `check_out` TIME,
  `status` ENUM('Present', 'Absent', 'Leave', 'Half Day') NOT NULL,
  `notes` TEXT,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`employee_id`) REFERENCES `employees`(`id`) ON DELETE CASCADE,
  UNIQUE KEY `employee_date` (`employee_id`, `date`)
);

-- Leave Types Table
CREATE TABLE `leave_types` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(255) NOT NULL,
  `days_allowed` INT DEFAULT 0,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Leaves Table
CREATE TABLE `leaves` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `employee_id` INT NOT NULL,
  `leave_type_id` INT NOT NULL,
  `start_date` DATE NOT NULL,
  `end_date` DATE NOT NULL,
  `days_requested` INT NOT NULL,
  `reason` TEXT,
  `status` ENUM('Pending', 'Approved', 'Rejected') DEFAULT 'Pending',
  `approved_by` INT,
  `approved_at` TIMESTAMP NULL,
  `rejection_reason` TEXT,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`employee_id`) REFERENCES `employees`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`leave_type_id`) REFERENCES `leave_types`(`id`),
  FOREIGN KEY (`approved_by`) REFERENCES `users`(`id`)
);

-- Salary Advances Table
CREATE TABLE `salary_advances` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `employee_id` INT NOT NULL,
  `amount` DECIMAL(10, 2) NOT NULL,
  `reason` TEXT,
  `status` ENUM('Pending', 'Approved', 'Rejected', 'Disbursed') DEFAULT 'Pending',
  `approved_by` INT,
  `approved_at` TIMESTAMP NULL,
  `disbursed_at` TIMESTAMP NULL,
  `rejection_reason` TEXT,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`employee_id`) REFERENCES `employees`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`approved_by`) REFERENCES `users`(`id`)
);

-- Loans Table
CREATE TABLE `loans` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `employee_id` INT NOT NULL,
  `amount` DECIMAL(10, 2) NOT NULL,
  `reason` TEXT,
  `payment_type` ENUM('emi', 'random') NOT NULL,
  `emi_amount` DECIMAL(10, 2),
  `tenure_months` INT,
  `status` ENUM('Pending', 'Approved', 'Rejected', 'Active', 'Completed') DEFAULT 'Pending',
  `approved_by` INT,
  `approved_at` TIMESTAMP NULL,
  `rejection_reason` TEXT,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`employee_id`) REFERENCES `employees`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`approved_by`) REFERENCES `users`(`id`)
);

-- Loan Payments Table
CREATE TABLE `loan_payments` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `loan_id` INT NOT NULL,
  `amount` DECIMAL(10, 2) NOT NULL,
  `payment_date` DATE NOT NULL,
  `payment_method` VARCHAR(100),
  `notes` TEXT,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`loan_id`) REFERENCES `loans`(`id`) ON DELETE CASCADE
);

-- Salary Components Table
CREATE TABLE `salary_components` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(255) NOT NULL,
  `type` ENUM('allowance', 'deduction') NOT NULL,
  `is_percentage` BOOLEAN DEFAULT FALSE,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Salary Structures Table
CREATE TABLE `salary_structures` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `employee_id` INT NOT NULL,
  `basic_salary` DECIMAL(10, 2) NOT NULL,
  `gross_salary` DECIMAL(10, 2) NOT NULL,
  `net_salary` DECIMAL(10, 2) NOT NULL,
  `effective_from` DATE NOT NULL,
  `is_active` BOOLEAN DEFAULT TRUE,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`employee_id`) REFERENCES `employees`(`id`) ON DELETE CASCADE
);

-- Salary Structure Components Table
CREATE TABLE `salary_structure_components` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `salary_structure_id` INT NOT NULL,
  `component_id` INT NOT NULL,
  `amount` DECIMAL(10, 2) NOT NULL,
  `percentage` DECIMAL(5, 2),
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`salary_structure_id`) REFERENCES `salary_structures`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`component_id`) REFERENCES `salary_components`(`id`)
);

-- Payrolls Table
CREATE TABLE `payrolls` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `month` INT NOT NULL,
  `year` INT NOT NULL,
  `status` ENUM('Draft', 'Pending', 'Approved', 'Disbursed') DEFAULT 'Draft',
  `total_amount` DECIMAL(12, 2) DEFAULT 0,
  `created_by` INT NOT NULL,
  `approved_by` INT,
  `approved_at` TIMESTAMP NULL,
  `disbursed_at` TIMESTAMP NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`created_by`) REFERENCES `users`(`id`),
  FOREIGN KEY (`approved_by`) REFERENCES `users`(`id`),
  UNIQUE KEY `month_year` (`month`, `year`)
);

-- Payroll Items Table
CREATE TABLE `payroll_items` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `payroll_id` INT NOT NULL,
  `employee_id` INT NOT NULL,
  `basic_salary` DECIMAL(10, 2) NOT NULL,
  `gross_salary` DECIMAL(10, 2) NOT NULL,
  `total_deductions` DECIMAL(10, 2) DEFAULT 0,
  `net_salary` DECIMAL(10, 2) NOT NULL,
  `working_days` INT DEFAULT 0,
  `present_days` INT DEFAULT 0,
  `leave_days` INT DEFAULT 0,
  `salary_details` JSON,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`payroll_id`) REFERENCES `payrolls`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`employee_id`) REFERENCES `employees`(`id`) ON DELETE CASCADE,
  UNIQUE KEY `payroll_employee` (`payroll_id`, `employee_id`)
);

-- Transactions Table
CREATE TABLE `transactions` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `reference_id` VARCHAR(100),
  `description` TEXT NOT NULL,
  `amount` DECIMAL(10, 2) NOT NULL,
  `type` ENUM('Expense', 'Salary', 'Advance', 'Loan') NOT NULL,
  `category` VARCHAR(100),
  `employee_id` INT,
  `created_by` INT NOT NULL,
  `transaction_date` DATE NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`employee_id`) REFERENCES `employees`(`id`),
  FOREIGN KEY (`created_by`) REFERENCES `users`(`id`)
);

-- Certificates Table
CREATE TABLE `certificates` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `employee_id` INT NOT NULL,
  `type` ENUM('Employment', 'Salary', 'Experience') NOT NULL,
  `content` TEXT NOT NULL,
  `file_path` VARCHAR(255),
  `generated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`employee_id`) REFERENCES `employees`(`id`) ON DELETE CASCADE
);

-- Sessions Table
CREATE TABLE `sessions` (
  `id` VARCHAR(128) PRIMARY KEY,
  `user_id` INT,
  `data` TEXT,
  `expires_at` TIMESTAMP NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
);

-- Insert default data
INSERT INTO `departments` (`name`, `description`) VALUES
('Human Resources', 'Manages employee relations and policies'),
('Information Technology', 'Handles technology infrastructure and development'),
('Finance & Accounts', 'Manages financial operations and accounting'),
('Sales & Marketing', 'Handles sales and marketing activities'),
('Operations', 'Manages day-to-day operations');

INSERT INTO `branches` (`name`, `address`) VALUES
('Head Office', 'Main Branch Address'),
('Branch 1', 'Branch 1 Address'),
('Branch 2', 'Branch 2 Address');

INSERT INTO `leave_types` (`name`, `days_allowed`) VALUES
('Annual Leave', 21),
('Sick Leave', 10),
('Casual Leave', 12),
('Maternity Leave', 90),
('Paternity Leave', 15);

INSERT INTO `salary_components` (`name`, `type`, `is_percentage`) VALUES
('House Rent Allowance', 'allowance', TRUE),
('Medical Allowance', 'allowance', FALSE),
('Transport Allowance', 'allowance', FALSE),
('Provident Fund', 'deduction', TRUE),
('Income Tax', 'deduction', TRUE),
('Professional Tax', 'deduction', FALSE);

-- Create default admin user
INSERT INTO `users` (`email`, `password`, `role`) VALUES
('admin@hrms.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin');

INSERT INTO `employees` (`user_id`, `employee_id`, `department_id`, `designation_id`, `branch_id`, `first_name`, `last_name`, `date_of_joining`) VALUES
(1, 'EMP001', 1, 1, 1, 'System', 'Administrator', CURDATE());

INSERT INTO `designations` (`name`, `department_id`) VALUES
('Administrator', 1),
('HR Manager', 1),
('IT Manager', 2),
('Software Developer', 2),
('Finance Manager', 3),
('Accountant', 3),
('Sales Manager', 4),
('Marketing Executive', 4),
('Operations Manager', 5),
('Operations Executive', 5);
