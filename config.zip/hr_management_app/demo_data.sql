-- Demo data for HR Management System

-- Insert departments
INSERT INTO departments (name, description, created_at) VALUES
('Human Resources', 'Manages employee relations and policies', NOW()),
('Information Technology', 'Handles technology infrastructure and development', NOW()),
('Finance', 'Manages financial operations and accounting', NOW()),
('Marketing', 'Handles marketing and promotional activities', NOW()),
('Operations', 'Manages day-to-day business operations', NOW());

-- Insert branches
INSERT INTO branches (name, address, city, state, country, phone, created_at) VALUES
('Main Office', '123 Business Street', 'New York', 'NY', 'USA', '+1-555-0100', NOW()),
('West Coast Branch', '456 Tech Avenue', 'San Francisco', 'CA', 'USA', '+1-555-0200', NOW()),
('East Coast Branch', '789 Corporate Blvd', 'Boston', 'MA', 'USA', '+1-555-0300', NOW());

-- Insert designations
INSERT INTO designations (title, department_id, level, created_at) VALUES
('HR Manager', 1, 'senior', NOW()),
('HR Executive', 1, 'junior', NOW()),
('Software Engineer', 2, 'junior', NOW()),
('Senior Software Engineer', 2, 'senior', NOW()),
('IT Manager', 2, 'senior', NOW()),
('Financial Analyst', 3, 'junior', NOW()),
('Finance Manager', 3, 'senior', NOW()),
('Marketing Executive', 4, 'junior', NOW()),
('Marketing Manager', 4, 'senior', NOW()),
('Operations Executive', 5, 'junior', NOW()),
('Operations Manager', 5, 'senior', NOW());

-- Insert users (admin, accounts, employees)
INSERT INTO users (email, password, role, is_active, created_at) VALUES
('admin@company.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', 1, NOW()),
('accounts@company.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'accounts', 1, NOW()),
('john.doe@company.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'employee', 1, NOW()),
('jane.smith@company.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'employee', 1, NOW()),
('mike.johnson@company.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'employee', 1, NOW());

-- Insert employees
INSERT INTO employees (user_id, employee_id, first_name, last_name, email, phone, date_of_birth, gender, address, city, state, country, postal_code, hire_date, department_id, designation_id, branch_id, salary, status, created_at) VALUES
(1, 'EMP001', 'Admin', 'User', 'admin@company.com', '+1-555-1001', '1980-01-15', 'male', '123 Admin Street', 'New York', 'NY', 'USA', '10001', '2020-01-01', 1, 1, 1, 80000.00, 'active', NOW()),
(2, 'EMP002', 'Accounts', 'Manager', 'accounts@company.com', '+1-555-1002', '1985-03-20', 'female', '456 Finance Ave', 'New York', 'NY', 'USA', '10002', '2020-02-01', 3, 7, 1, 75000.00, 'active', NOW()),
(3, 'EMP003', 'John', 'Doe', 'john.doe@company.com', '+1-555-1003', '1990-05-10', 'male', '789 Developer Lane', 'San Francisco', 'CA', 'USA', '94101', '2021-03-15', 2, 3, 2, 65000.00, 'active', NOW()),
(4, 'EMP004', 'Jane', 'Smith', 'jane.smith@company.com', '+1-555-1004', '1988-08-25', 'female', '321 Marketing Blvd', 'Boston', 'MA', 'USA', '02101', '2021-06-01', 4, 8, 3, 55000.00, 'active', NOW()),
(5, 'EMP005', 'Mike', 'Johnson', 'mike.johnson@company.com', '+1-555-1005', '1992-12-03', 'male', '654 Operations St', 'New York', 'NY', 'USA', '10003', '2022-01-10', 5, 10, 1, 50000.00, 'active', NOW());

-- Insert salary components
INSERT INTO salary_components (name, type, is_taxable, created_at) VALUES
('Basic Salary', 'earning', 1, NOW()),
('House Rent Allowance', 'earning', 1, NOW()),
('Transport Allowance', 'earning', 0, NOW()),
('Medical Allowance', 'earning', 0, NOW()),
('Performance Bonus', 'earning', 1, NOW()),
('Income Tax', 'deduction', 0, NOW()),
('Provident Fund', 'deduction', 0, NOW()),
('Health Insurance', 'deduction', 0, NOW());

-- Insert salary structures
INSERT INTO salary_structures (employee_id, component_id, amount, created_at) VALUES
-- Admin User
(1, 1, 50000.00, NOW()),
(1, 2, 20000.00, NOW()),
(1, 3, 5000.00, NOW()),
(1, 4, 3000.00, NOW()),
(1, 6, 8000.00, NOW()),
(1, 7, 6000.00, NOW()),
-- Accounts Manager
(2, 1, 45000.00, NOW()),
(2, 2, 18000.00, NOW()),
(2, 3, 5000.00, NOW()),
(2, 4, 3000.00, NOW()),
(2, 6, 7000.00, NOW()),
(2, 7, 5400.00, NOW()),
-- John Doe
(3, 1, 40000.00, NOW()),
(3, 2, 16000.00, NOW()),
(3, 3, 4000.00, NOW()),
(3, 4, 2500.00, NOW()),
(3, 6, 6000.00, NOW()),
(3, 7, 4800.00, NOW()),
-- Jane Smith
(4, 1, 35000.00, NOW()),
(4, 2, 14000.00, NOW()),
(4, 3, 3000.00, NOW()),
(4, 4, 2000.00, NOW()),
(4, 6, 5000.00, NOW()),
(4, 7, 4200.00, NOW()),
-- Mike Johnson
(5, 1, 30000.00, NOW()),
(5, 2, 12000.00, NOW()),
(5, 3, 3000.00, NOW()),
(5, 4, 2000.00, NOW()),
(5, 6, 4500.00, NOW()),
(5, 7, 3600.00, NOW());

-- Insert leave types
INSERT INTO leave_types (name, days_allowed, carry_forward, created_at) VALUES
('Annual Leave', 21, 1, NOW()),
('Sick Leave', 10, 0, NOW()),
('Maternity Leave', 90, 0, NOW()),
('Paternity Leave', 15, 0, NOW()),
('Emergency Leave', 5, 0, NOW());

-- Insert some sample attendance records
INSERT INTO attendance (employee_id, date, check_in, check_out, status, created_at) VALUES
(3, '2024-10-01', '09:00:00', '17:30:00', 'present', NOW()),
(3, '2024-10-02', '09:15:00', '17:45:00', 'present', NOW()),
(3, '2024-10-03', '09:00:00', '17:30:00', 'present', NOW()),
(4, '2024-10-01', '09:30:00', '18:00:00', 'present', NOW()),
(4, '2024-10-02', '09:00:00', '17:30:00', 'present', NOW()),
(4, '2024-10-03', NULL, NULL, 'absent', NOW()),
(5, '2024-10-01', '08:45:00', '17:15:00', 'present', NOW()),
(5, '2024-10-02', '09:00:00', '17:30:00', 'present', NOW()),
(5, '2024-10-03', '09:30:00', '17:45:00', 'late', NOW());

-- Insert some sample leave applications
INSERT INTO leaves (employee_id, leave_type_id, start_date, end_date, days, reason, status, created_at) VALUES
(3, 1, '2024-10-15', '2024-10-17', 3, 'Family vacation', 'pending', NOW()),
(4, 2, '2024-10-10', '2024-10-10', 1, 'Medical appointment', 'approved', NOW()),
(5, 1, '2024-10-20', '2024-10-22', 3, 'Personal work', 'pending', NOW());

-- Insert some sample salary advances
INSERT INTO salary_advances (employee_id, amount, reason, status, requested_date, created_at) VALUES
(3, 5000.00, 'Medical emergency', 'pending', '2024-10-05', NOW()),
(4, 3000.00, 'Home repair', 'approved', '2024-09-25', NOW()),
(5, 2000.00, 'Educational expenses', 'pending', '2024-10-08', NOW());

-- Insert some sample loans
INSERT INTO loans (employee_id, amount, interest_rate, tenure_months, emi_amount, purpose, status, applied_date, created_at) VALUES
(3, 50000.00, 8.5, 24, 2291.67, 'Home renovation', 'pending', '2024-10-01', NOW()),
(4, 25000.00, 7.5, 12, 2187.50, 'Vehicle purchase', 'approved', '2024-09-15', NOW());

-- Insert some sample transactions
INSERT INTO transactions (type, category, amount, description, transaction_date, created_at) VALUES
('expense', 'office_supplies', 1500.00, 'Office stationery and supplies', '2024-10-01', NOW()),
('expense', 'utilities', 2500.00, 'Electricity and internet bills', '2024-10-02', NOW()),
('expense', 'travel', 3000.00, 'Business travel expenses', '2024-10-03', NOW()),
('income', 'other', 5000.00, 'Miscellaneous income', '2024-10-04', NOW());
