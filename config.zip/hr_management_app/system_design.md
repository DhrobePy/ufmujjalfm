# HR Management System Design

This document outlines the system architecture, database schema, and API endpoints for the HR Management web application.

## 1. System Architecture

### 1.1. Frontend

*   **Framework:** TailwindCSS for styling.
*   **Templating:** PHP for server-side rendering of views.

### 1.2. Backend

*   **Language:** PHP
*   **Web Server:** Apache or Nginx
*   **Database:** MySQL

### 1.3. Directory Structure

```
/hr_management_app
├── public/
│   ├── index.php
│   ├── css/
│   │   └── style.css
│   └── js/
├── src/
│   ├── controllers/
│   ├── models/
│   ├── views/
│   └── core/
├── templates/
├── database/
└── composer.json
```

## 2. Database Schema

This section will detail the tables and relationships in the MySQL database.

## 3. API Endpoints

This section will define the RESTful API endpoints for the application.



## 2. Database Schema

```sql
-- Users Table
CREATE TABLE `users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `email` VARCHAR(255) NOT NULL UNIQUE,
  `password` VARCHAR(255) NOT NULL,
  `role` ENUM('employee', 'accounts', 'admin') NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Departments Table
CREATE TABLE `departments` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(255) NOT NULL
);

-- Designations Table
CREATE TABLE `designations` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(255) NOT NULL
);

-- Employees Table
CREATE TABLE `employees` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `department_id` INT NOT NULL,
  `designation_id` INT NOT NULL,
  `first_name` VARCHAR(255) NOT NULL,
  `last_name` VARCHAR(255) NOT NULL,
  `date_of_birth` DATE,
  `gender` ENUM('Male', 'Female', 'Other'),
  `phone_number` VARCHAR(20),
  `address` TEXT,
  `date_of_joining` DATE,
  `profile_picture` VARCHAR(255),
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`),
  FOREIGN KEY (`department_id`) REFERENCES `departments`(`id`),
  FOREIGN KEY (`designation_id`) REFERENCES `designations`(`id`)
);

-- Attendance Table
CREATE TABLE `attendance` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `employee_id` INT NOT NULL,
  `date` DATE NOT NULL,
  `status` ENUM('Present', 'Absent', 'Leave') NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`employee_id`) REFERENCES `employees`(`id`)
);

-- Leaves Table
CREATE TABLE `leaves` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `employee_id` INT NOT NULL,
  `start_date` DATE NOT NULL,
  `end_date` DATE NOT NULL,
  `reason` TEXT,
  `status` ENUM('Pending', 'Approved', 'Rejected') DEFAULT 'Pending',
  `approved_by` INT,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`employee_id`) REFERENCES `employees`(`id`),
  FOREIGN KEY (`approved_by`) REFERENCES `users`(`id`)
);

-- Salary Advances Table
CREATE TABLE `salary_advances` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `employee_id` INT NOT NULL,
  `amount` DECIMAL(10, 2) NOT NULL,
  `reason` TEXT,
  `status` ENUM('Pending', 'Approved', 'Rejected') DEFAULT 'Pending',
  `approved_by` INT,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`employee_id`) REFERENCES `employees`(`id`),
  FOREIGN KEY (`approved_by`) REFERENCES `users`(`id`)
);

-- Loans Table
CREATE TABLE `loans` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `employee_id` INT NOT NULL,
  `amount` DECIMAL(10, 2) NOT NULL,
  `reason` TEXT,
  `payment_type` ENUM('emi', 'random') NOT NULL,
  `status` ENUM('Pending', 'Approved', 'Rejected') DEFAULT 'Pending',
  `approved_by` INT,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`employee_id`) REFERENCES `employees`(`id`),
  FOREIGN KEY (`approved_by`) REFERENCES `users`(`id`)
);

-- Loan Payments Table
CREATE TABLE `loan_payments` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `loan_id` INT NOT NULL,
  `amount` DECIMAL(10, 2) NOT NULL,
  `payment_date` DATE NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`loan_id`) REFERENCES `loans`(`id`)
);

-- Salary Structures Table
CREATE TABLE `salary_structures` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `designation_id` INT NOT NULL,
  `basic_salary` DECIMAL(10, 2) NOT NULL,
  `allowances` JSON,
  `deductions` JSON,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`designation_id`) REFERENCES `designations`(`id`)
);

-- Payrolls Table
CREATE TABLE `payrolls` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `month` INT NOT NULL,
  `year` INT NOT NULL,
  `status` ENUM('Pending', 'Approved', 'Disbursed') DEFAULT 'Pending',
  `created_by` INT NOT NULL,
  `approved_by` INT,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`created_by`) REFERENCES `users`(`id`),
  FOREIGN KEY (`approved_by`) REFERENCES `users`(`id`)
);

-- Payroll Items Table
CREATE TABLE `payroll_items` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `payroll_id` INT NOT NULL,
  `employee_id` INT NOT NULL,
  `net_salary` DECIMAL(10, 2) NOT NULL,
  `details` JSON,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`payroll_id`) REFERENCES `payrolls`(`id`),
  FOREIGN KEY (`employee_id`) REFERENCES `employees`(`id`)
);

-- Transactions Table
CREATE TABLE `transactions` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `description` TEXT NOT NULL,
  `amount` DECIMAL(10, 2) NOT NULL,
  `type` ENUM('Expense', 'Salary') NOT NULL,
  `created_by` INT NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`created_by`) REFERENCES `users`(`id`)
);

-- Certificates Table
CREATE TABLE `certificates` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `employee_id` INT NOT NULL,
  `type` ENUM('Employment', 'Salary') NOT NULL,
  `content` TEXT NOT NULL,
  `generated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`employee_id`) REFERENCES `employees`(`id`)
);
```



## 3. API Endpoints

### 3.1. Authentication

*   `POST /api/login`: User login
*   `POST /api/logout`: User logout

### 3.2. Employee

*   `GET /api/employee/profile`: Get employee profile
*   `POST /api/employee/attendance`: Mark attendance
*   `POST /api/employee/leave`: Apply for leave
*   `POST /api/employee/salary-advance`: Apply for salary advance
*   `POST /api/employee/loan`: Apply for loan
*   `GET /api/employee/certificate/employment`: Generate employment certificate
*   `GET /api/employee/certificate/salary`: Generate salary certificate
*   `GET /api/employee/payslip`: Generate payslip

### 3.3. Accounts

*   `POST /api/accounts/salary-structure`: Set salary structure
*   `GET /api/accounts/attendance-report`: Generate attendance report
*   `POST /api/accounts/payroll`: Generate payroll
*   `GET /api/accounts/transactions`: Get all transactions

### 3.4. Admin

*   `GET /api/admin/dashboard`: Get dashboard info
*   `GET /api/admin/employees`: Get all employees
*   `GET /api/admin/employee/{id}`: Get employee profile
*   `POST /api/admin/employee`: Add new employee
*   `PUT /api/admin/employee/{id}`: Update employee profile
*   `POST /api/admin/payroll/approve`: Approve payroll
*   `POST /api/admin/leave/approve`: Approve leave
*   `POST /api/admin/salary-advance/approve`: Approve salary advance
*   `POST /api/admin/loan/approve`: Approve loan

