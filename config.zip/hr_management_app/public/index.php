<?php

// Start session
session_start();

// Set error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Include autoloader
require_once __DIR__ . '/../vendor/autoload.php';

// Load environment variables
if (file_exists(__DIR__ . '/../.env')) {
    $lines = file(__DIR__ . '/../.env', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        if (strpos(trim($line), '#') === 0) {
            continue;
        }
        list($name, $value) = explode('=', $line, 2);
        $_ENV[trim($name)] = trim($value);
        putenv(trim($name) . '=' . trim($value));
    }
}

// Set timezone
date_default_timezone_set('UTC');

// Initialize database connection
try {
    $database = new App\Core\Database();
    $db = $database->getConnection();
} catch (Exception $e) {
    // If database connection fails, show a friendly error
    http_response_code(500);
    if (strpos($_SERVER['REQUEST_URI'], '/api/') === 0) {
        header('Content-Type: application/json');
        echo json_encode(['error' => 'Database connection failed']);
    } else {
        echo '<h1>Database Connection Error</h1>';
        echo '<p>Unable to connect to the database. Please check your configuration.</p>';
        if ($_ENV['APP_DEBUG'] ?? false) {
            echo '<p>Error: ' . $e->getMessage() . '</p>';
        }
    }
    exit;
}

// Initialize and dispatch router
try {
    $router = new App\Core\Router();
    $router->dispatch();
} catch (Exception $e) {
    // Handle routing errors
    http_response_code(500);
    if (strpos($_SERVER['REQUEST_URI'], '/api/') === 0) {
        header('Content-Type: application/json');
        echo json_encode(['error' => 'Internal server error']);
    } else {
        echo '<h1>Application Error</h1>';
        echo '<p>An error occurred while processing your request.</p>';
        if ($_ENV['APP_DEBUG'] ?? false) {
            echo '<p>Error: ' . $e->getMessage() . '</p>';
            echo '<pre>' . $e->getTraceAsString() . '</pre>';
        }
    }
}
