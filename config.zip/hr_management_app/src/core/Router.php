<?php

namespace App\Core;

class Router
{
    private $routes = [];
    private $currentRoute = null;

    public function __construct()
    {
        $this->setupRoutes();
    }

    private function setupRoutes()
    {
        // Home routes
        $this->addRoute('GET', '/', 'HomeController@index');
        
        // Authentication routes
        $this->addRoute('GET', '/login', 'AuthController@login');
        $this->addRoute('POST', '/login', 'AuthController@login');
        $this->addRoute('GET', '/logout', 'AuthController@logout');
        $this->addRoute('POST', '/logout', 'AuthController@logout');
        
        // Dashboard routes
        $this->addRoute('GET', '/dashboard', 'DashboardController@index');
        
        // Employee routes
        $this->addRoute('GET', '/employee/dashboard', 'EmployeeController@dashboard');
        $this->addRoute('GET', '/employee/profile', 'EmployeeController@profile');
        $this->addRoute('POST', '/employee/profile', 'EmployeeController@updateProfile');
        $this->addRoute('GET', '/employee/attendance', 'EmployeeController@attendance');
        $this->addRoute('GET', '/employee/leaves', 'EmployeeController@leaves');
        $this->addRoute('GET', '/employee/salary-advances', 'EmployeeController@salaryAdvances');
        $this->addRoute('GET', '/employee/loans', 'EmployeeController@loans');
        $this->addRoute('GET', '/employee/payslips', 'EmployeeController@payslips');
        
        // Accounts routes
        $this->addRoute('GET', '/accounts/dashboard', 'AccountsController@dashboard');
        $this->addRoute('GET', '/accounts/salary-structures', 'AccountsController@salaryStructures');
        $this->addRoute('GET', '/accounts/attendance-reports', 'AccountsController@attendanceReports');
        $this->addRoute('GET', '/accounts/payroll', 'AccountsController@payroll');
        $this->addRoute('GET', '/accounts/transactions', 'AccountsController@transactions');
        
        // Admin routes
        $this->addRoute('GET', '/admin/dashboard', 'AdminController@dashboard');
        $this->addRoute('GET', '/admin/employees', 'AdminController@employees');
        $this->addRoute('GET', '/admin/employees/add', 'AdminController@addEmployee');
        $this->addRoute('POST', '/admin/employees/add', 'AdminController@addEmployee');
        $this->addRoute('GET', '/admin/employees/edit/{id}', 'AdminController@editEmployee');
        $this->addRoute('POST', '/admin/employees/edit/{id}', 'AdminController@editEmployee');
        $this->addRoute('GET', '/admin/employees/{id}', 'AdminController@employeeProfile');
        $this->addRoute('GET', '/admin/approvals', 'AdminController@approvals');
        $this->addRoute('GET', '/admin/reports', 'AdminController@reports');
        
        // API routes
        $this->setupApiRoutes();
    }

    private function setupApiRoutes()
    {
        // Authentication API
        $this->addRoute('POST', '/api/auth/login', 'Api\\AuthController@login');
        $this->addRoute('POST', '/api/auth/logout', 'Api\\AuthController@logout');
        $this->addRoute('GET', '/api/auth/me', 'Api\\AuthController@me');
        
        // Employee API
        $this->addRoute('GET', '/api/employee/profile', 'Api\\EmployeeController@getProfile');
        $this->addRoute('PUT', '/api/employee/profile', 'Api\\EmployeeController@updateProfile');
        $this->addRoute('POST', '/api/employee/attendance', 'Api\\EmployeeController@markAttendance');
        $this->addRoute('GET', '/api/employee/attendance', 'Api\\EmployeeController@getAttendance');
        $this->addRoute('POST', '/api/employee/leave', 'Api\\EmployeeController@applyLeave');
        $this->addRoute('GET', '/api/employee/leaves', 'Api\\EmployeeController@getLeaves');
        $this->addRoute('POST', '/api/employee/salary-advance', 'Api\\EmployeeController@applySalaryAdvance');
        $this->addRoute('GET', '/api/employee/salary-advances', 'Api\\EmployeeController@getSalaryAdvances');
        $this->addRoute('POST', '/api/employee/loan', 'Api\\EmployeeController@applyLoan');
        $this->addRoute('GET', '/api/employee/loans', 'Api\\EmployeeController@getLoans');
        $this->addRoute('GET', '/api/employee/payslips', 'Api\\EmployeeController@getPayslips');
        
        // Accounts API
        $this->addRoute('POST', '/api/accounts/salary-structure', 'Api\\AccountsController@setSalaryStructure');
        $this->addRoute('GET', '/api/accounts/salary-structures', 'Api\\AccountsController@getSalaryStructures');
        $this->addRoute('GET', '/api/accounts/attendance-report', 'Api\\AccountsController@getAttendanceReport');
        $this->addRoute('POST', '/api/accounts/payroll', 'Api\\AccountsController@generatePayroll');
        $this->addRoute('GET', '/api/accounts/payrolls', 'Api\\AccountsController@getPayrolls');
        $this->addRoute('GET', '/api/accounts/payroll/{id}', 'Api\\AccountsController@getPayrollDetails');
        $this->addRoute('POST', '/api/accounts/payroll/submit', 'Api\\AccountsController@submitPayrollForApproval');
        $this->addRoute('POST', '/api/accounts/transaction', 'Api\\AccountsController@addTransaction');
        $this->addRoute('GET', '/api/accounts/transactions', 'Api\\AccountsController@getTransactions');
        $this->addRoute('PUT', '/api/accounts/transaction', 'Api\\AccountsController@updateTransaction');
        $this->addRoute('DELETE', '/api/accounts/transaction', 'Api\\AccountsController@deleteTransaction');
        $this->addRoute('GET', '/api/accounts/financial-summary', 'Api\\AccountsController@getFinancialSummary');
        $this->addRoute('POST', '/api/accounts/bulk-salary-update', 'Api\\AccountsController@bulkUpdateSalary');
        
        // Admin API
        $this->addRoute('GET', '/api/admin/dashboard', 'Api\\AdminController@getDashboard');
        $this->addRoute('GET', '/api/admin/employees', 'Api\\AdminController@getEmployees');
        $this->addRoute('GET', '/api/admin/employee/{id}', 'Api\\AdminController@getEmployee');
        $this->addRoute('POST', '/api/admin/employee', 'Api\\AdminController@addEmployee');
        $this->addRoute('PUT', '/api/admin/employee/{id}', 'Api\\AdminController@updateEmployee');
        $this->addRoute('DELETE', '/api/admin/employee/{id}', 'Api\\AdminController@deleteEmployee');
        $this->addRoute('POST', '/api/admin/approve-payroll', 'Api\\AdminController@approvePayroll');
        $this->addRoute('POST', '/api/admin/approve-leave', 'Api\\AdminController@approveLeave');
        $this->addRoute('POST', '/api/admin/approve-salary-advance', 'Api\\AdminController@approveSalaryAdvance');
        $this->addRoute('POST', '/api/admin/approve-loan', 'Api\\AdminController@approveLoan');
        $this->addRoute('GET', '/api/admin/approvals', 'Api\\AdminController@getApprovals');
        $this->addRoute('POST', '/api/admin/disburse-payroll', 'Api\\AdminController@disbursePayroll');
        
        // Common API
        $this->addRoute('GET', '/api/departments', 'Api\\CommonController@getDepartments');
        $this->addRoute('GET', '/api/designations', 'Api\\CommonController@getDesignations');
        $this->addRoute('GET', '/api/branches', 'Api\\CommonController@getBranches');
        $this->addRoute('GET', '/api/leave-types', 'Api\\CommonController@getLeaveTypes');
        $this->addRoute('GET', '/api/salary-components', 'Api\\CommonController@getSalaryComponents');
        $this->addRoute('GET', '/api/system-stats', 'Api\\CommonController@getSystemStats');
        $this->addRoute('GET', '/api/months', 'Api\\CommonController@getMonths');
        $this->addRoute('GET', '/api/years', 'Api\\CommonController@getYears');
        $this->addRoute('GET', '/api/employee-options', 'Api\\CommonController@getEmployeeOptions');
        $this->addRoute('GET', '/api/search-employees', 'Api\\CommonController@searchEmployees');
        $this->addRoute('GET', '/api/transaction-categories', 'Api\\CommonController@getTransactionCategories');
        $this->addRoute('GET', '/api/attendance-statuses', 'Api\\CommonController@getAttendanceStatuses');
        $this->addRoute('GET', '/api/application-statuses', 'Api\\CommonController@getApplicationStatuses');
        $this->addRoute('GET', '/api/payroll-statuses', 'Api\\CommonController@getPayrollStatuses');
        $this->addRoute('GET', '/api/transaction-types', 'Api\\CommonController@getTransactionTypes');
        $this->addRoute('GET', '/api/gender-options', 'Api\\CommonController@getGenderOptions');
        $this->addRoute('GET', '/api/user-roles', 'Api\\CommonController@getUserRoles');
        
        // Report API
        $this->addRoute('GET', '/api/reports/attendance', 'Api\\ReportController@generateAttendanceReport');
        $this->addRoute('GET', '/api/reports/leave', 'Api\\ReportController@generateLeaveReport');
        $this->addRoute('GET', '/api/reports/payroll', 'Api\\ReportController@generatePayrollReport');
        $this->addRoute('GET', '/api/reports/financial', 'Api\\ReportController@generateFinancialReport');
        $this->addRoute('GET', '/api/reports/employee', 'Api\\ReportController@generateEmployeeReport');
        $this->addRoute('GET', '/api/reports/comprehensive', 'Api\\ReportController@generateComprehensiveReport');
        $this->addRoute('GET', '/api/reports/payslip', 'Api\\ReportController@generatePayslip');
        
        // Document API
        $this->addRoute('GET', '/api/documents/employment-certificate', 'Api\\DocumentController@generateEmploymentCertificate');
        $this->addRoute('GET', '/api/documents/salary-certificate', 'Api\\DocumentController@generateSalaryCertificate');
        $this->addRoute('GET', '/api/documents/experience-letter', 'Api\\DocumentController@generateExperienceLetter');
    }

    public function addRoute($method, $path, $handler)
    {
        $this->routes[] = [
            'method' => strtoupper($method),
            'path' => $path,
            'handler' => $handler
        ];
    }

    public function dispatch()
    {
        $requestMethod = $_SERVER['REQUEST_METHOD'];
        $requestUri = $_SERVER['REQUEST_URI'];
        
        // Remove query string
        $requestUri = strtok($requestUri, '?');
        
        // Remove trailing slash except for root
        if ($requestUri !== '/' && substr($requestUri, -1) === '/') {
            $requestUri = rtrim($requestUri, '/');
        }

        foreach ($this->routes as $route) {
            if ($route['method'] === $requestMethod && $this->matchRoute($route['path'], $requestUri)) {
                $this->currentRoute = $route;
                return $this->executeRoute($route['handler'], $this->extractParams($route['path'], $requestUri));
            }
        }

        // Route not found
        http_response_code(404);
        if (strpos($requestUri, '/api/') === 0) {
            header('Content-Type: application/json');
            echo json_encode(['error' => 'Route not found']);
        } else {
            echo "404 - Page Not Found";
        }
    }

    private function matchRoute($routePath, $requestUri)
    {
        // Convert route path to regex pattern
        $pattern = preg_replace('/\{[^}]+\}/', '([^/]+)', $routePath);
        $pattern = '#^' . $pattern . '$#';
        
        return preg_match($pattern, $requestUri);
    }

    private function extractParams($routePath, $requestUri)
    {
        $params = [];
        
        // Extract parameter names from route path
        preg_match_all('/\{([^}]+)\}/', $routePath, $paramNames);
        
        // Extract parameter values from request URI
        $pattern = preg_replace('/\{[^}]+\}/', '([^/]+)', $routePath);
        $pattern = '#^' . $pattern . '$#';
        
        if (preg_match($pattern, $requestUri, $matches)) {
            array_shift($matches); // Remove full match
            
            for ($i = 0; $i < count($paramNames[1]); $i++) {
                if (isset($matches[$i])) {
                    $params[$paramNames[1][$i]] = $matches[$i];
                }
            }
        }
        
        return $params;
    }

    private function executeRoute($handler, $params = [])
    {
        list($controllerName, $methodName) = explode('@', $handler);
        
        $controllerClass = "App\\Controllers\\{$controllerName}";
        
        if (!class_exists($controllerClass)) {
            throw new \Exception("Controller {$controllerClass} not found");
        }

        $controller = new $controllerClass();
        
        if (!method_exists($controller, $methodName)) {
            throw new \Exception("Method {$methodName} not found in {$controllerClass}");
        }

        // Pass parameters to the method
        if (!empty($params)) {
            return call_user_func_array([$controller, $methodName], array_values($params));
        } else {
            return $controller->$methodName();
        }
    }

    public function getCurrentRoute()
    {
        return $this->currentRoute;
    }

    public function url($path)
    {
        $baseUrl = $this->getBaseUrl();
        return $baseUrl . $path;
    }

    private function getBaseUrl()
    {
        $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
        $host = $_SERVER['HTTP_HOST'];
        $scriptName = $_SERVER['SCRIPT_NAME'];
        $basePath = dirname($scriptName);
        
        if ($basePath === '/') {
            $basePath = '';
        }
        
        return $protocol . '://' . $host . $basePath;
    }

    public function redirect($path, $statusCode = 302)
    {
        $url = $this->url($path);
        header("Location: {$url}", true, $statusCode);
        exit();
    }
}
