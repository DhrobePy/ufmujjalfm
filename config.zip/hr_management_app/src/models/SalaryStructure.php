<?php

namespace App\Models;

class SalaryStructure extends BaseModel
{
    protected $table = 'salary_structures';
    protected $fillable = [
        'employee_id', 'basic_salary', 'gross_salary', 'net_salary', 'effective_from', 'is_active'
    ];

    public function createSalaryStructure($data)
    {
        // Deactivate previous salary structures for this employee
        $this->db->update(
            $this->table,
            ['is_active' => 0],
            'employee_id = :employee_id',
            ['employee_id' => $data['employee_id']]
        );
        
        $data['is_active'] = 1;
        $data['effective_from'] = $data['effective_from'] ?? date('Y-m-d');
        
        return $this->create($data);
    }

    public function getEmployeeSalaryStructure($employeeId, $effectiveDate = null)
    {
        if (!$effectiveDate) {
            $effectiveDate = date('Y-m-d');
        }
        
        $sql = "
            SELECT ss.*, 
                   e.first_name, e.last_name, e.employee_id as emp_code,
                   d.name as department_name, des.name as designation_name
            FROM {$this->table} ss
            JOIN employees e ON ss.employee_id = e.id
            LEFT JOIN departments d ON e.department_id = d.id
            LEFT JOIN designations des ON e.designation_id = des.id
            WHERE ss.employee_id = :employee_id 
            AND ss.effective_from <= :effective_date
            AND ss.is_active = 1
            ORDER BY ss.effective_from DESC
            LIMIT 1
        ";
        
        return $this->db->fetch($sql, [
            'employee_id' => $employeeId,
            'effective_date' => $effectiveDate
        ]);
    }

    public function getSalaryStructureWithComponents($salaryStructureId)
    {
        $structure = $this->find($salaryStructureId);
        
        if ($structure) {
            $sql = "
                SELECT ssc.*, sc.name, sc.type, sc.is_percentage
                FROM salary_structure_components ssc
                JOIN salary_components sc ON ssc.component_id = sc.id
                WHERE ssc.salary_structure_id = :structure_id
                ORDER BY sc.type, sc.name
            ";
            
            $components = $this->db->fetchAll($sql, ['structure_id' => $salaryStructureId]);
            $structure['components'] = $components;
        }
        
        return $structure;
    }

    public function addSalaryComponent($salaryStructureId, $componentId, $amount, $percentage = null)
    {
        $data = [
            'salary_structure_id' => $salaryStructureId,
            'component_id' => $componentId,
            'amount' => $amount,
            'percentage' => $percentage
        ];
        
        return $this->db->insert('salary_structure_components', $data);
    }

    public function updateSalaryComponent($componentId, $amount, $percentage = null)
    {
        $data = [
            'amount' => $amount,
            'percentage' => $percentage
        ];
        
        return $this->db->update(
            'salary_structure_components',
            $data,
            'id = :id',
            ['id' => $componentId]
        );
    }

    public function deleteSalaryComponent($componentId)
    {
        return $this->db->delete(
            'salary_structure_components',
            'id = :id',
            ['id' => $componentId]
        );
    }

    public function calculateSalary($basicSalary, $components)
    {
        $grossSalary = $basicSalary;
        $totalAllowances = 0;
        $totalDeductions = 0;
        
        foreach ($components as $component) {
            $amount = $component['amount'];
            
            if ($component['is_percentage'] && $component['percentage']) {
                $amount = ($basicSalary * $component['percentage']) / 100;
            }
            
            if ($component['type'] === 'allowance') {
                $totalAllowances += $amount;
                $grossSalary += $amount;
            } else {
                $totalDeductions += $amount;
            }
        }
        
        $netSalary = $grossSalary - $totalDeductions;
        
        return [
            'basic_salary' => $basicSalary,
            'total_allowances' => $totalAllowances,
            'gross_salary' => $grossSalary,
            'total_deductions' => $totalDeductions,
            'net_salary' => $netSalary
        ];
    }

    public function getAllSalaryStructures($filters = [])
    {
        $sql = "
            SELECT ss.*, 
                   e.employee_id as emp_code, e.first_name, e.last_name,
                   d.name as department_name, des.name as designation_name,
                   b.name as branch_name
            FROM {$this->table} ss
            JOIN employees e ON ss.employee_id = e.id
            LEFT JOIN departments d ON e.department_id = d.id
            LEFT JOIN designations des ON e.designation_id = des.id
            LEFT JOIN branches b ON e.branch_id = b.id
            WHERE ss.is_active = 1
        ";
        
        $params = [];
        
        if (isset($filters['department_id'])) {
            $sql .= " AND e.department_id = :department_id";
            $params['department_id'] = $filters['department_id'];
        }
        
        if (isset($filters['designation_id'])) {
            $sql .= " AND e.designation_id = :designation_id";
            $params['designation_id'] = $filters['designation_id'];
        }
        
        if (isset($filters['branch_id'])) {
            $sql .= " AND e.branch_id = :branch_id";
            $params['branch_id'] = $filters['branch_id'];
        }
        
        if (isset($filters['search'])) {
            $sql .= " AND (e.first_name LIKE :search OR e.last_name LIKE :search OR e.employee_id LIKE :search)";
            $params['search'] = '%' . $filters['search'] . '%';
        }
        
        $sql .= " ORDER BY e.first_name, e.last_name";
        
        return $this->db->fetchAll($sql, $params);
    }

    public function getSalaryStatistics()
    {
        $sql = "
            SELECT 
                COUNT(*) as total_employees,
                AVG(basic_salary) as avg_basic_salary,
                AVG(gross_salary) as avg_gross_salary,
                AVG(net_salary) as avg_net_salary,
                MIN(net_salary) as min_salary,
                MAX(net_salary) as max_salary,
                SUM(net_salary) as total_salary_cost
            FROM {$this->table}
            WHERE is_active = 1
        ";
        
        return $this->db->fetch($sql);
    }

    public function getDepartmentWiseSalaryStats()
    {
        $sql = "
            SELECT 
                d.name as department_name,
                COUNT(ss.id) as employee_count,
                AVG(ss.net_salary) as avg_salary,
                SUM(ss.net_salary) as total_salary
            FROM {$this->table} ss
            JOIN employees e ON ss.employee_id = e.id
            LEFT JOIN departments d ON e.department_id = d.id
            WHERE ss.is_active = 1
            GROUP BY d.id, d.name
            ORDER BY total_salary DESC
        ";
        
        return $this->db->fetchAll($sql);
    }

    public function getDesignationWiseSalaryStats()
    {
        $sql = "
            SELECT 
                des.name as designation_name,
                COUNT(ss.id) as employee_count,
                AVG(ss.net_salary) as avg_salary,
                MIN(ss.net_salary) as min_salary,
                MAX(ss.net_salary) as max_salary
            FROM {$this->table} ss
            JOIN employees e ON ss.employee_id = e.id
            LEFT JOIN designations des ON e.designation_id = des.id
            WHERE ss.is_active = 1
            GROUP BY des.id, des.name
            ORDER BY avg_salary DESC
        ";
        
        return $this->db->fetchAll($sql);
    }

    public function copySalaryStructure($fromEmployeeId, $toEmployeeId)
    {
        $sourceStructure = $this->getEmployeeSalaryStructure($fromEmployeeId);
        
        if (!$sourceStructure) {
            return false;
        }
        
        $sourceComponents = $this->getSalaryStructureWithComponents($sourceStructure['id']);
        
        // Create new salary structure
        $newStructureData = [
            'employee_id' => $toEmployeeId,
            'basic_salary' => $sourceStructure['basic_salary'],
            'gross_salary' => $sourceStructure['gross_salary'],
            'net_salary' => $sourceStructure['net_salary']
        ];
        
        $newStructure = $this->createSalaryStructure($newStructureData);
        
        if ($newStructure && isset($sourceComponents['components'])) {
            // Copy components
            foreach ($sourceComponents['components'] as $component) {
                $this->addSalaryComponent(
                    $newStructure['id'],
                    $component['component_id'],
                    $component['amount'],
                    $component['percentage']
                );
            }
        }
        
        return $newStructure;
    }

    public function bulkUpdateSalary($employeeIds, $increasePercentage)
    {
        $updated = 0;
        
        foreach ($employeeIds as $employeeId) {
            $currentStructure = $this->getEmployeeSalaryStructure($employeeId);
            
            if ($currentStructure) {
                $newBasicSalary = $currentStructure['basic_salary'] * (1 + $increasePercentage / 100);
                $newGrossSalary = $currentStructure['gross_salary'] * (1 + $increasePercentage / 100);
                $newNetSalary = $currentStructure['net_salary'] * (1 + $increasePercentage / 100);
                
                $newStructureData = [
                    'employee_id' => $employeeId,
                    'basic_salary' => round($newBasicSalary, 2),
                    'gross_salary' => round($newGrossSalary, 2),
                    'net_salary' => round($newNetSalary, 2)
                ];
                
                if ($this->createSalaryStructure($newStructureData)) {
                    $updated++;
                }
            }
        }
        
        return $updated;
    }
}
