<?php

namespace App\Models;

class Loan extends BaseModel
{
    protected $table = 'loans';
    protected $fillable = [
        'employee_id', 'amount', 'reason', 'payment_type', 'emi_amount',
        'tenure_months', 'status', 'approved_by', 'approved_at', 'rejection_reason'
    ];

    public function applyLoan($data)
    {
        $data['status'] = 'Pending';
        
        // Calculate EMI if payment type is EMI
        if ($data['payment_type'] === 'emi' && isset($data['tenure_months'])) {
            $data['emi_amount'] = $this->calculateEMI($data['amount'], $data['tenure_months']);
        }
        
        return $this->create($data);
    }

    public function getEmployeeLoans($employeeId, $year = null)
    {
        $sql = "
            SELECT l.*, u.email as approved_by_email
            FROM {$this->table} l
            LEFT JOIN users u ON l.approved_by = u.id
            WHERE l.employee_id = :employee_id
        ";
        
        $params = ['employee_id' => $employeeId];
        
        if ($year) {
            $sql .= " AND YEAR(l.created_at) = :year";
            $params['year'] = $year;
        }
        
        $sql .= " ORDER BY l.created_at DESC";
        
        return $this->db->fetchAll($sql, $params);
    }

    public function getPendingLoans()
    {
        $sql = "
            SELECT l.*, 
                   e.employee_id as emp_code, e.first_name, e.last_name,
                   d.name as department_name, des.name as designation_name
            FROM {$this->table} l
            JOIN employees e ON l.employee_id = e.id
            LEFT JOIN departments d ON e.department_id = d.id
            LEFT JOIN designations des ON e.designation_id = des.id
            WHERE l.status = 'Pending'
            ORDER BY l.created_at ASC
        ";
        
        return $this->db->fetchAll($sql);
    }

    public function approveLoan($loanId, $approvedBy, $rejectionReason = null)
    {
        $data = [
            'approved_by' => $approvedBy,
            'approved_at' => date('Y-m-d H:i:s')
        ];
        
        if ($rejectionReason) {
            $data['status'] = 'Rejected';
            $data['rejection_reason'] = $rejectionReason;
        } else {
            $data['status'] = 'Approved';
        }
        
        return $this->update($loanId, $data);
    }

    public function activateLoan($loanId)
    {
        return $this->update($loanId, ['status' => 'Active']);
    }

    public function completeLoan($loanId)
    {
        return $this->update($loanId, ['status' => 'Completed']);
    }

    public function getLoanWithPayments($loanId)
    {
        $loan = $this->find($loanId);
        
        if ($loan) {
            $payments = $this->db->fetchAll(
                "SELECT * FROM loan_payments WHERE loan_id = :loan_id ORDER BY payment_date DESC",
                ['loan_id' => $loanId]
            );
            
            $loan['payments'] = $payments;
            $loan['total_paid'] = array_sum(array_column($payments, 'amount'));
            $loan['remaining_amount'] = $loan['amount'] - $loan['total_paid'];
        }
        
        return $loan;
    }

    public function addLoanPayment($loanId, $amount, $paymentDate, $paymentMethod = null, $notes = null)
    {
        $paymentData = [
            'loan_id' => $loanId,
            'amount' => $amount,
            'payment_date' => $paymentDate,
            'payment_method' => $paymentMethod,
            'notes' => $notes
        ];
        
        $paymentId = $this->db->insert('loan_payments', $paymentData);
        
        // Check if loan is fully paid
        $loan = $this->getLoanWithPayments($loanId);
        if ($loan && $loan['remaining_amount'] <= 0) {
            $this->completeLoan($loanId);
        }
        
        return $paymentId;
    }

    public function getLoanReport($filters = [])
    {
        $sql = "
            SELECT l.*,
                   e.employee_id as emp_code, e.first_name, e.last_name,
                   d.name as department_name, des.name as designation_name,
                   b.name as branch_name,
                   u.email as approved_by_email,
                   COALESCE(SUM(lp.amount), 0) as total_paid,
                   (l.amount - COALESCE(SUM(lp.amount), 0)) as remaining_amount
            FROM {$this->table} l
            JOIN employees e ON l.employee_id = e.id
            LEFT JOIN departments d ON e.department_id = d.id
            LEFT JOIN designations des ON e.designation_id = des.id
            LEFT JOIN branches b ON e.branch_id = b.id
            LEFT JOIN users u ON l.approved_by = u.id
            LEFT JOIN loan_payments lp ON l.id = lp.loan_id
            WHERE 1=1
        ";
        
        $params = [];
        
        if (isset($filters['employee_id'])) {
            $sql .= " AND l.employee_id = :employee_id";
            $params['employee_id'] = $filters['employee_id'];
        }
        
        if (isset($filters['department_id'])) {
            $sql .= " AND e.department_id = :department_id";
            $params['department_id'] = $filters['department_id'];
        }
        
        if (isset($filters['status'])) {
            $sql .= " AND l.status = :status";
            $params['status'] = $filters['status'];
        }
        
        if (isset($filters['payment_type'])) {
            $sql .= " AND l.payment_type = :payment_type";
            $params['payment_type'] = $filters['payment_type'];
        }
        
        if (isset($filters['year'])) {
            $sql .= " AND YEAR(l.created_at) = :year";
            $params['year'] = $filters['year'];
        }
        
        $sql .= " GROUP BY l.id ORDER BY l.created_at DESC";
        
        return $this->db->fetchAll($sql, $params);
    }

    public function getLoanStatistics($year = null)
    {
        if (!$year) {
            $year = date('Y');
        }
        
        $sql = "
            SELECT 
                COUNT(*) as total_applications,
                SUM(CASE WHEN status = 'Approved' THEN 1 ELSE 0 END) as approved,
                SUM(CASE WHEN status = 'Rejected' THEN 1 ELSE 0 END) as rejected,
                SUM(CASE WHEN status = 'Pending' THEN 1 ELSE 0 END) as pending,
                SUM(CASE WHEN status = 'Active' THEN 1 ELSE 0 END) as active,
                SUM(CASE WHEN status = 'Completed' THEN 1 ELSE 0 END) as completed,
                SUM(CASE WHEN status IN ('Approved', 'Active', 'Completed') THEN amount ELSE 0 END) as total_amount_approved,
                AVG(CASE WHEN status IN ('Approved', 'Active', 'Completed') THEN amount ELSE NULL END) as average_amount
            FROM {$this->table}
            WHERE YEAR(created_at) = :year
        ";
        
        return $this->db->fetch($sql, ['year' => $year]);
    }

    public function getActiveLoansForEmployee($employeeId)
    {
        $sql = "
            SELECT l.*, 
                   COALESCE(SUM(lp.amount), 0) as total_paid,
                   (l.amount - COALESCE(SUM(lp.amount), 0)) as remaining_amount
            FROM {$this->table} l
            LEFT JOIN loan_payments lp ON l.id = lp.loan_id
            WHERE l.employee_id = :employee_id AND l.status = 'Active'
            GROUP BY l.id
            ORDER BY l.created_at DESC
        ";
        
        return $this->db->fetchAll($sql, ['employee_id' => $employeeId]);
    }

    public function getUpcomingEMIs($month = null, $year = null)
    {
        if (!$month) $month = date('n');
        if (!$year) $year = date('Y');
        
        $sql = "
            SELECT l.*, e.employee_id as emp_code, e.first_name, e.last_name,
                   d.name as department_name
            FROM {$this->table} l
            JOIN employees e ON l.employee_id = e.id
            LEFT JOIN departments d ON e.department_id = d.id
            WHERE l.status = 'Active' 
            AND l.payment_type = 'emi'
            AND l.emi_amount > 0
            ORDER BY e.first_name, e.last_name
        ";
        
        return $this->db->fetchAll($sql);
    }

    private function calculateEMI($principal, $tenureMonths, $interestRate = 12)
    {
        // Simple EMI calculation without interest for now
        // In real implementation, you might want to include interest calculation
        return round($principal / $tenureMonths, 2);
    }

    public function canApplyForLoan($employeeId, $requestedAmount)
    {
        // Check if employee has any pending loans
        $pendingCount = $this->count([
            'employee_id' => $employeeId,
            'status' => 'Pending'
        ]);
        
        if ($pendingCount > 0) {
            return [
                'can_apply' => false,
                'reason' => 'You have a pending loan request'
            ];
        }
        
        // Check if employee has active loans
        $activeLoans = $this->getActiveLoansForEmployee($employeeId);
        $totalActiveAmount = array_sum(array_column($activeLoans, 'remaining_amount'));
        
        // Assuming maximum loan limit is 500,000
        $maxLoanLimit = 500000;
        
        if (($totalActiveAmount + $requestedAmount) > $maxLoanLimit) {
            return [
                'can_apply' => false,
                'reason' => 'Requested amount exceeds maximum loan limit'
            ];
        }
        
        return ['can_apply' => true];
    }
}
