<?php

namespace App\Models;

use Dompdf\Dompdf;
use Dompdf\Options;

class Report extends BaseModel
{
    protected $table = 'reports'; // This could be used for storing report metadata
    
    private $attendanceModel;
    private $leaveModel;
    private $payrollModel;
    private $transactionModel;
    private $employeeModel;

    public function __construct()
    {
        parent::__construct();
        $this->attendanceModel = new Attendance();
        $this->leaveModel = new Leave();
        $this->payrollModel = new Payroll();
        $this->transactionModel = new Transaction();
        $this->employeeModel = new Employee();
    }

    public function generateAttendanceReport($filters = [])
    {
        $attendanceData = $this->attendanceModel->getAttendanceReport($filters);
        
        // Group by employee for summary
        $employeeSummary = [];
        foreach ($attendanceData as $record) {
            $empId = $record['employee_id'];
            if (!isset($employeeSummary[$empId])) {
                $employeeSummary[$empId] = [
                    'employee_id' => $record['emp_code'],
                    'name' => $record['first_name'] . ' ' . $record['last_name'],
                    'department' => $record['department_name'],
                    'present' => 0,
                    'absent' => 0,
                    'leave' => 0,
                    'half_day' => 0,
                    'total' => 0
                ];
            }
            
            $employeeSummary[$empId]['total']++;
            switch ($record['status']) {
                case 'Present':
                    $employeeSummary[$empId]['present']++;
                    break;
                case 'Absent':
                    $employeeSummary[$empId]['absent']++;
                    break;
                case 'Leave':
                    $employeeSummary[$empId]['leave']++;
                    break;
                case 'Half Day':
                    $employeeSummary[$empId]['half_day']++;
                    break;
            }
        }
        
        return [
            'detailed_data' => $attendanceData,
            'summary' => array_values($employeeSummary),
            'filters' => $filters,
            'generated_at' => date('Y-m-d H:i:s')
        ];
    }

    public function generateLeaveReport($filters = [])
    {
        $leaveData = $this->leaveModel->getLeaveReport($filters);
        $leaveStats = $this->leaveModel->getLeaveStatistics($filters['year'] ?? date('Y'));
        
        // Calculate leave utilization by employee
        $employeeUtilization = [];
        foreach ($leaveData as $leave) {
            $empId = $leave['employee_id'];
            if (!isset($employeeUtilization[$empId])) {
                $employeeUtilization[$empId] = [
                    'employee_id' => $leave['emp_code'],
                    'name' => $leave['first_name'] . ' ' . $leave['last_name'],
                    'department' => $leave['department_name'],
                    'total_days_taken' => 0,
                    'applications' => 0,
                    'approved' => 0,
                    'rejected' => 0,
                    'pending' => 0
                ];
            }
            
            $employeeUtilization[$empId]['applications']++;
            if ($leave['status'] === 'Approved') {
                $employeeUtilization[$empId]['approved']++;
                $employeeUtilization[$empId]['total_days_taken'] += $leave['days_requested'];
            } elseif ($leave['status'] === 'Rejected') {
                $employeeUtilization[$empId]['rejected']++;
            } else {
                $employeeUtilization[$empId]['pending']++;
            }
        }
        
        return [
            'detailed_data' => $leaveData,
            'statistics' => $leaveStats,
            'employee_utilization' => array_values($employeeUtilization),
            'filters' => $filters,
            'generated_at' => date('Y-m-d H:i:s')
        ];
    }

    public function generatePayrollReport($filters = [])
    {
        $payrollData = $this->payrollModel->getAllPayrolls($filters);
        $payrollStats = $this->payrollModel->getPayrollStatistics($filters['year'] ?? date('Y'));
        $monthlyStats = $this->payrollModel->getMonthlyPayrollStats($filters['year'] ?? date('Y'));
        
        // Get detailed payroll items for specific payroll if requested
        $detailedItems = [];
        if (isset($filters['payroll_id'])) {
            $payrollWithItems = $this->payrollModel->getPayrollWithItems($filters['payroll_id']);
            $detailedItems = $payrollWithItems['items'] ?? [];
        }
        
        return [
            'payroll_data' => $payrollData,
            'statistics' => $payrollStats,
            'monthly_stats' => $monthlyStats,
            'detailed_items' => $detailedItems,
            'filters' => $filters,
            'generated_at' => date('Y-m-d H:i:s')
        ];
    }

    public function generateFinancialReport($filters = [])
    {
        $year = $filters['year'] ?? date('Y');
        
        $financialSummary = $this->transactionModel->getFinancialSummary($year);
        $monthlyStats = $this->transactionModel->getMonthlyTransactionStats($year);
        $categoryExpenses = $this->transactionModel->getCategoryWiseExpenses(['year' => $year]);
        $cashFlow = $this->transactionModel->getCashFlowData($year);
        $recentTransactions = $this->transactionModel->getTransactions(array_merge($filters, ['limit' => 100]));
        
        return [
            'financial_summary' => $financialSummary,
            'monthly_stats' => $monthlyStats,
            'category_expenses' => $categoryExpenses,
            'cash_flow' => $cashFlow,
            'recent_transactions' => $recentTransactions,
            'filters' => $filters,
            'generated_at' => date('Y-m-d H:i:s')
        ];
    }

    public function generateEmployeeReport($filters = [])
    {
        $employees = $this->employeeModel->getAllEmployeesWithDetails($filters);
        $departmentStats = $this->employeeModel->getEmployeeCountByDepartment();
        
        // Get additional employee statistics
        $totalEmployees = count($employees);
        $activeEmployees = count(array_filter($employees, fn($e) => $e['is_active']));
        
        // Age distribution
        $ageGroups = ['20-30' => 0, '31-40' => 0, '41-50' => 0, '51+' => 0];
        $genderDistribution = ['Male' => 0, 'Female' => 0, 'Other' => 0];
        
        foreach ($employees as $employee) {
            // Calculate age if date_of_birth is available
            if ($employee['date_of_birth']) {
                $age = date_diff(date_create($employee['date_of_birth']), date_create('today'))->y;
                if ($age <= 30) $ageGroups['20-30']++;
                elseif ($age <= 40) $ageGroups['31-40']++;
                elseif ($age <= 50) $ageGroups['41-50']++;
                else $ageGroups['51+']++;
            }
            
            // Gender distribution
            if (isset($genderDistribution[$employee['gender']])) {
                $genderDistribution[$employee['gender']]++;
            }
        }
        
        return [
            'employees' => $employees,
            'department_stats' => $departmentStats,
            'total_employees' => $totalEmployees,
            'active_employees' => $activeEmployees,
            'age_distribution' => $ageGroups,
            'gender_distribution' => $genderDistribution,
            'filters' => $filters,
            'generated_at' => date('Y-m-d H:i:s')
        ];
    }

    public function generateComprehensiveReport($year = null)
    {
        if (!$year) $year = date('Y');
        
        $report = [
            'year' => $year,
            'generated_at' => date('Y-m-d H:i:s'),
            'company_name' => 'HR Management Company',
            'report_title' => "Annual HR Report - {$year}"
        ];
        
        // Employee Overview
        $report['employee_overview'] = $this->generateEmployeeReport();
        
        // Financial Summary
        $report['financial_summary'] = $this->generateFinancialReport(['year' => $year]);
        
        // Payroll Summary
        $report['payroll_summary'] = $this->generatePayrollReport(['year' => $year]);
        
        // Leave Summary
        $report['leave_summary'] = $this->generateLeaveReport(['year' => $year]);
        
        // Attendance Overview (current month)
        $currentMonth = date('n');
        $report['attendance_overview'] = $this->generateAttendanceReport([
            'year' => $year,
            'month' => $currentMonth
        ]);
        
        return $report;
    }

    public function exportToPDF($reportData, $template = 'default')
    {
        $options = new Options();
        $options->set('defaultFont', 'Arial');
        $options->set('isRemoteEnabled', true);
        
        $dompdf = new Dompdf($options);
        
        $html = $this->generateHTMLTemplate($reportData, $template);
        
        $dompdf->loadHtml($html);
        $dompdf->setPaper('A4', 'portrait');
        $dompdf->render();
        
        return $dompdf->output();
    }

    public function exportToCSV($data, $filename = 'report.csv')
    {
        $output = fopen('php://temp', 'w');
        
        if (!empty($data)) {
            // Write headers
            fputcsv($output, array_keys($data[0]));
            
            // Write data
            foreach ($data as $row) {
                fputcsv($output, $row);
            }
        }
        
        rewind($output);
        $csv = stream_get_contents($output);
        fclose($output);
        
        return $csv;
    }

    public function exportToExcel($data, $filename = 'report.xlsx')
    {
        // This would require a library like PhpSpreadsheet
        // For now, we'll return CSV format
        return $this->exportToCSV($data, $filename);
    }

    private function generateHTMLTemplate($reportData, $template)
    {
        $html = '<!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <title>' . ($reportData['report_title'] ?? 'HR Report') . '</title>
            <style>
                body { font-family: Arial, sans-serif; margin: 20px; }
                .header { text-align: center; margin-bottom: 30px; }
                .company-name { font-size: 24px; font-weight: bold; color: #333; }
                .report-title { font-size: 18px; color: #666; margin-top: 10px; }
                .section { margin-bottom: 30px; }
                .section-title { font-size: 16px; font-weight: bold; color: #333; border-bottom: 2px solid #ddd; padding-bottom: 5px; margin-bottom: 15px; }
                table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
                th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
                th { background-color: #f5f5f5; font-weight: bold; }
                .summary-box { background-color: #f9f9f9; padding: 15px; border-radius: 5px; margin-bottom: 20px; }
                .stat-item { display: inline-block; margin-right: 30px; }
                .stat-value { font-size: 24px; font-weight: bold; color: #2563eb; }
                .stat-label { font-size: 12px; color: #666; }
                .footer { text-align: center; margin-top: 50px; font-size: 12px; color: #666; }
            </style>
        </head>
        <body>';
        
        // Header
        $html .= '<div class="header">
            <div class="company-name">' . ($reportData['company_name'] ?? 'HR Management Company') . '</div>
            <div class="report-title">' . ($reportData['report_title'] ?? 'HR Report') . '</div>
            <div>Generated on: ' . ($reportData['generated_at'] ?? date('Y-m-d H:i:s')) . '</div>
        </div>';
        
        // Content based on template
        switch ($template) {
            case 'attendance':
                $html .= $this->generateAttendanceHTML($reportData);
                break;
            case 'leave':
                $html .= $this->generateLeaveHTML($reportData);
                break;
            case 'payroll':
                $html .= $this->generatePayrollHTML($reportData);
                break;
            case 'financial':
                $html .= $this->generateFinancialHTML($reportData);
                break;
            case 'employee':
                $html .= $this->generateEmployeeHTML($reportData);
                break;
            default:
                $html .= $this->generateComprehensiveHTML($reportData);
                break;
        }
        
        // Footer
        $html .= '<div class="footer">
            <p>This report was generated automatically by the HR Management System</p>
        </div>';
        
        $html .= '</body></html>';
        
        return $html;
    }

    private function generateAttendanceHTML($data)
    {
        $html = '<div class="section">
            <div class="section-title">Attendance Report</div>';
        
        if (isset($data['summary']) && !empty($data['summary'])) {
            $html .= '<table>
                <thead>
                    <tr>
                        <th>Employee ID</th>
                        <th>Name</th>
                        <th>Department</th>
                        <th>Present</th>
                        <th>Absent</th>
                        <th>Leave</th>
                        <th>Half Day</th>
                        <th>Total</th>
                        <th>Attendance %</th>
                    </tr>
                </thead>
                <tbody>';
            
            foreach ($data['summary'] as $employee) {
                $attendancePercentage = $employee['total'] > 0 ? round(($employee['present'] / $employee['total']) * 100, 2) : 0;
                $html .= '<tr>
                    <td>' . htmlspecialchars($employee['employee_id']) . '</td>
                    <td>' . htmlspecialchars($employee['name']) . '</td>
                    <td>' . htmlspecialchars($employee['department']) . '</td>
                    <td>' . $employee['present'] . '</td>
                    <td>' . $employee['absent'] . '</td>
                    <td>' . $employee['leave'] . '</td>
                    <td>' . $employee['half_day'] . '</td>
                    <td>' . $employee['total'] . '</td>
                    <td>' . $attendancePercentage . '%</td>
                </tr>';
            }
            
            $html .= '</tbody></table>';
        }
        
        $html .= '</div>';
        return $html;
    }

    private function generateLeaveHTML($data)
    {
        $html = '<div class="section">
            <div class="section-title">Leave Report</div>';
        
        if (isset($data['statistics']) && !empty($data['statistics'])) {
            $html .= '<div class="summary-box">
                <h4>Leave Statistics</h4>
                <table>
                    <thead>
                        <tr>
                            <th>Leave Type</th>
                            <th>Total Applications</th>
                            <th>Approved</th>
                            <th>Rejected</th>
                            <th>Pending</th>
                            <th>Total Days Taken</th>
                        </tr>
                    </thead>
                    <tbody>';
            
            foreach ($data['statistics'] as $stat) {
                $html .= '<tr>
                    <td>' . htmlspecialchars($stat['leave_type']) . '</td>
                    <td>' . $stat['total_applications'] . '</td>
                    <td>' . $stat['approved'] . '</td>
                    <td>' . $stat['rejected'] . '</td>
                    <td>' . $stat['pending'] . '</td>
                    <td>' . $stat['total_days_taken'] . '</td>
                </tr>';
            }
            
            $html .= '</tbody></table></div>';
        }
        
        $html .= '</div>';
        return $html;
    }

    private function generatePayrollHTML($data)
    {
        $html = '<div class="section">
            <div class="section-title">Payroll Report</div>';
        
        if (isset($data['statistics'])) {
            $stats = $data['statistics'];
            $html .= '<div class="summary-box">
                <div class="stat-item">
                    <div class="stat-value">' . $stats['total_payrolls'] . '</div>
                    <div class="stat-label">Total Payrolls</div>
                </div>
                <div class="stat-item">
                    <div class="stat-value">$' . number_format($stats['total_disbursed'], 2) . '</div>
                    <div class="stat-label">Total Disbursed</div>
                </div>
                <div class="stat-item">
                    <div class="stat-value">$' . number_format($stats['avg_payroll_amount'], 2) . '</div>
                    <div class="stat-label">Average Payroll</div>
                </div>
            </div>';
        }
        
        $html .= '</div>';
        return $html;
    }

    private function generateFinancialHTML($data)
    {
        $html = '<div class="section">
            <div class="section-title">Financial Report</div>';
        
        if (isset($data['financial_summary'])) {
            $summary = $data['financial_summary'];
            $html .= '<div class="summary-box">
                <div class="stat-item">
                    <div class="stat-value">$' . number_format($summary['total_expenses'], 2) . '</div>
                    <div class="stat-label">Total Expenses</div>
                </div>
                <div class="stat-item">
                    <div class="stat-value">$' . number_format($summary['total_salaries'], 2) . '</div>
                    <div class="stat-label">Total Salaries</div>
                </div>
                <div class="stat-item">
                    <div class="stat-value">$' . number_format($summary['total_amount'], 2) . '</div>
                    <div class="stat-label">Total Amount</div>
                </div>
            </div>';
        }
        
        $html .= '</div>';
        return $html;
    }

    private function generateEmployeeHTML($data)
    {
        $html = '<div class="section">
            <div class="section-title">Employee Report</div>';
        
        $html .= '<div class="summary-box">
            <div class="stat-item">
                <div class="stat-value">' . $data['total_employees'] . '</div>
                <div class="stat-label">Total Employees</div>
            </div>
            <div class="stat-item">
                <div class="stat-value">' . $data['active_employees'] . '</div>
                <div class="stat-label">Active Employees</div>
            </div>
        </div>';
        
        if (isset($data['department_stats']) && !empty($data['department_stats'])) {
            $html .= '<h4>Department-wise Distribution</h4>
                <table>
                    <thead>
                        <tr>
                            <th>Department</th>
                            <th>Employee Count</th>
                        </tr>
                    </thead>
                    <tbody>';
            
            foreach ($data['department_stats'] as $dept) {
                $html .= '<tr>
                    <td>' . htmlspecialchars($dept['department_name']) . '</td>
                    <td>' . $dept['employee_count'] . '</td>
                </tr>';
            }
            
            $html .= '</tbody></table>';
        }
        
        $html .= '</div>';
        return $html;
    }

    private function generateComprehensiveHTML($data)
    {
        $html = '';
        
        // Add each section
        if (isset($data['employee_overview'])) {
            $html .= $this->generateEmployeeHTML($data['employee_overview']);
        }
        
        if (isset($data['financial_summary'])) {
            $html .= $this->generateFinancialHTML($data['financial_summary']);
        }
        
        if (isset($data['payroll_summary'])) {
            $html .= $this->generatePayrollHTML($data['payroll_summary']);
        }
        
        if (isset($data['leave_summary'])) {
            $html .= $this->generateLeaveHTML($data['leave_summary']);
        }
        
        if (isset($data['attendance_overview'])) {
            $html .= $this->generateAttendanceHTML($data['attendance_overview']);
        }
        
        return $html;
    }
}
