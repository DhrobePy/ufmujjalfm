<?php

namespace App\Models;

class SalaryAdvance extends BaseModel
{
    protected $table = 'salary_advances';
    protected $fillable = [
        'employee_id', 'amount', 'reason', 'status', 'approved_by',
        'approved_at', 'disbursed_at', 'rejection_reason'
    ];

    public function applySalaryAdvance($data)
    {
        $data['status'] = 'Pending';
        return $this->create($data);
    }

    public function getEmployeeSalaryAdvances($employeeId, $year = null)
    {
        $sql = "
            SELECT sa.*, u.email as approved_by_email
            FROM {$this->table} sa
            LEFT JOIN users u ON sa.approved_by = u.id
            WHERE sa.employee_id = :employee_id
        ";
        
        $params = ['employee_id' => $employeeId];
        
        if ($year) {
            $sql .= " AND YEAR(sa.created_at) = :year";
            $params['year'] = $year;
        }
        
        $sql .= " ORDER BY sa.created_at DESC";
        
        return $this->db->fetchAll($sql, $params);
    }

    public function getPendingSalaryAdvances()
    {
        $sql = "
            SELECT sa.*, 
                   e.employee_id as emp_code, e.first_name, e.last_name,
                   d.name as department_name, des.name as designation_name
            FROM {$this->table} sa
            JOIN employees e ON sa.employee_id = e.id
            LEFT JOIN departments d ON e.department_id = d.id
            LEFT JOIN designations des ON e.designation_id = des.id
            WHERE sa.status = 'Pending'
            ORDER BY sa.created_at ASC
        ";
        
        return $this->db->fetchAll($sql);
    }

    public function approveSalaryAdvance($advanceId, $approvedBy, $rejectionReason = null)
    {
        $data = [
            'status' => 'Approved',
            'approved_by' => $approvedBy,
            'approved_at' => date('Y-m-d H:i:s')
        ];
        
        if ($rejectionReason) {
            $data['status'] = 'Rejected';
            $data['rejection_reason'] = $rejectionReason;
        }
        
        return $this->update($advanceId, $data);
    }

    public function disburseSalaryAdvance($advanceId)
    {
        return $this->update($advanceId, [
            'status' => 'Disbursed',
            'disbursed_at' => date('Y-m-d H:i:s')
        ]);
    }

    public function getSalaryAdvanceReport($filters = [])
    {
        $sql = "
            SELECT sa.*,
                   e.employee_id as emp_code, e.first_name, e.last_name,
                   d.name as department_name, des.name as designation_name,
                   b.name as branch_name,
                   u.email as approved_by_email
            FROM {$this->table} sa
            JOIN employees e ON sa.employee_id = e.id
            LEFT JOIN departments d ON e.department_id = d.id
            LEFT JOIN designations des ON e.designation_id = des.id
            LEFT JOIN branches b ON e.branch_id = b.id
            LEFT JOIN users u ON sa.approved_by = u.id
            WHERE 1=1
        ";
        
        $params = [];
        
        if (isset($filters['employee_id'])) {
            $sql .= " AND sa.employee_id = :employee_id";
            $params['employee_id'] = $filters['employee_id'];
        }
        
        if (isset($filters['department_id'])) {
            $sql .= " AND e.department_id = :department_id";
            $params['department_id'] = $filters['department_id'];
        }
        
        if (isset($filters['status'])) {
            $sql .= " AND sa.status = :status";
            $params['status'] = $filters['status'];
        }
        
        if (isset($filters['year'])) {
            $sql .= " AND YEAR(sa.created_at) = :year";
            $params['year'] = $filters['year'];
        }
        
        if (isset($filters['month'])) {
            $sql .= " AND MONTH(sa.created_at) = :month";
            $params['month'] = $filters['month'];
        }
        
        $sql .= " ORDER BY sa.created_at DESC";
        
        return $this->db->fetchAll($sql, $params);
    }

    public function getSalaryAdvanceStatistics($year = null)
    {
        if (!$year) {
            $year = date('Y');
        }
        
        $sql = "
            SELECT 
                COUNT(*) as total_applications,
                SUM(CASE WHEN status = 'Approved' THEN 1 ELSE 0 END) as approved,
                SUM(CASE WHEN status = 'Rejected' THEN 1 ELSE 0 END) as rejected,
                SUM(CASE WHEN status = 'Pending' THEN 1 ELSE 0 END) as pending,
                SUM(CASE WHEN status = 'Disbursed' THEN 1 ELSE 0 END) as disbursed,
                SUM(CASE WHEN status IN ('Approved', 'Disbursed') THEN amount ELSE 0 END) as total_amount_approved,
                SUM(CASE WHEN status = 'Disbursed' THEN amount ELSE 0 END) as total_amount_disbursed,
                AVG(CASE WHEN status IN ('Approved', 'Disbursed') THEN amount ELSE NULL END) as average_amount
            FROM {$this->table}
            WHERE YEAR(created_at) = :year
        ";
        
        return $this->db->fetch($sql, ['year' => $year]);
    }

    public function getMonthlyAdvanceStats($year = null)
    {
        if (!$year) {
            $year = date('Y');
        }
        
        $sql = "
            SELECT 
                MONTH(created_at) as month,
                MONTHNAME(created_at) as month_name,
                COUNT(*) as total_applications,
                SUM(CASE WHEN status IN ('Approved', 'Disbursed') THEN amount ELSE 0 END) as total_amount
            FROM {$this->table}
            WHERE YEAR(created_at) = :year
            GROUP BY MONTH(created_at), MONTHNAME(created_at)
            ORDER BY MONTH(created_at)
        ";
        
        return $this->db->fetchAll($sql, ['year' => $year]);
    }

    public function getTotalAdvanceByEmployee($employeeId, $year = null)
    {
        $sql = "
            SELECT 
                SUM(CASE WHEN status IN ('Approved', 'Disbursed') THEN amount ELSE 0 END) as total_approved,
                SUM(CASE WHEN status = 'Disbursed' THEN amount ELSE 0 END) as total_disbursed,
                COUNT(CASE WHEN status = 'Pending' THEN 1 END) as pending_count
            FROM {$this->table}
            WHERE employee_id = :employee_id
        ";
        
        $params = ['employee_id' => $employeeId];
        
        if ($year) {
            $sql .= " AND YEAR(created_at) = :year";
            $params['year'] = $year;
        }
        
        return $this->db->fetch($sql, $params);
    }

    public function canApplyForAdvance($employeeId, $requestedAmount)
    {
        // Check if employee has any pending advances
        $pendingCount = $this->count([
            'employee_id' => $employeeId,
            'status' => 'Pending'
        ]);
        
        if ($pendingCount > 0) {
            return [
                'can_apply' => false,
                'reason' => 'You have a pending salary advance request'
            ];
        }
        
        // Check total advances in current year
        $currentYear = date('Y');
        $yearlyTotal = $this->getTotalAdvanceByEmployee($employeeId, $currentYear);
        
        // Assuming maximum advance limit is 3 times monthly salary or 50,000 (whichever is lower)
        $maxAdvanceLimit = 50000;
        
        if (($yearlyTotal['total_approved'] + $requestedAmount) > $maxAdvanceLimit) {
            return [
                'can_apply' => false,
                'reason' => 'Requested amount exceeds annual advance limit'
            ];
        }
        
        return ['can_apply' => true];
    }
}
