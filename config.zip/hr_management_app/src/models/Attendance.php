<?php

namespace App\Models;

class Attendance extends BaseModel
{
    protected $table = 'attendance';
    protected $fillable = [
        'employee_id', 'date', 'check_in', 'check_out', 'status', 'notes'
    ];

    public function markAttendance($employeeId, $date, $status, $checkIn = null, $checkOut = null, $notes = null)
    {
        // Check if attendance already exists for this date
        $existing = $this->getAttendanceByDate($employeeId, $date);
        
        $data = [
            'employee_id' => $employeeId,
            'date' => $date,
            'status' => $status,
            'check_in' => $checkIn,
            'check_out' => $checkOut,
            'notes' => $notes
        ];
        
        if ($existing) {
            return $this->update($existing['id'], $data);
        } else {
            return $this->create($data);
        }
    }

    public function getAttendanceByDate($employeeId, $date)
    {
        $sql = "SELECT * FROM {$this->table} WHERE employee_id = :employee_id AND date = :date";
        return $this->db->fetch($sql, ['employee_id' => $employeeId, 'date' => $date]);
    }

    public function getEmployeeAttendance($employeeId, $month = null, $year = null)
    {
        $sql = "SELECT * FROM {$this->table} WHERE employee_id = :employee_id";
        $params = ['employee_id' => $employeeId];
        
        if ($month && $year) {
            $sql .= " AND MONTH(date) = :month AND YEAR(date) = :year";
            $params['month'] = $month;
            $params['year'] = $year;
        }
        
        $sql .= " ORDER BY date DESC";
        
        return $this->db->fetchAll($sql, $params);
    }

    public function getAttendanceReport($filters = [])
    {
        $sql = "
            SELECT a.*, e.employee_id as emp_code, e.first_name, e.last_name,
                   d.name as department_name, des.name as designation_name,
                   b.name as branch_name
            FROM {$this->table} a
            JOIN employees e ON a.employee_id = e.id
            LEFT JOIN departments d ON e.department_id = d.id
            LEFT JOIN designations des ON e.designation_id = des.id
            LEFT JOIN branches b ON e.branch_id = b.id
            WHERE 1=1
        ";
        
        $params = [];
        
        if (isset($filters['employee_id'])) {
            $sql .= " AND a.employee_id = :employee_id";
            $params['employee_id'] = $filters['employee_id'];
        }
        
        if (isset($filters['department_id'])) {
            $sql .= " AND e.department_id = :department_id";
            $params['department_id'] = $filters['department_id'];
        }
        
        if (isset($filters['branch_id'])) {
            $sql .= " AND e.branch_id = :branch_id";
            $params['branch_id'] = $filters['branch_id'];
        }
        
        if (isset($filters['date_from'])) {
            $sql .= " AND a.date >= :date_from";
            $params['date_from'] = $filters['date_from'];
        }
        
        if (isset($filters['date_to'])) {
            $sql .= " AND a.date <= :date_to";
            $params['date_to'] = $filters['date_to'];
        }
        
        if (isset($filters['status'])) {
            $sql .= " AND a.status = :status";
            $params['status'] = $filters['status'];
        }
        
        $sql .= " ORDER BY a.date DESC, e.first_name";
        
        return $this->db->fetchAll($sql, $params);
    }

    public function getAttendanceSummary($employeeId, $month, $year)
    {
        $sql = "
            SELECT 
                COUNT(*) as total_days,
                SUM(CASE WHEN status = 'Present' THEN 1 ELSE 0 END) as present_days,
                SUM(CASE WHEN status = 'Absent' THEN 1 ELSE 0 END) as absent_days,
                SUM(CASE WHEN status = 'Leave' THEN 1 ELSE 0 END) as leave_days,
                SUM(CASE WHEN status = 'Half Day' THEN 0.5 ELSE 0 END) as half_days
            FROM {$this->table}
            WHERE employee_id = :employee_id 
            AND MONTH(date) = :month 
            AND YEAR(date) = :year
        ";
        
        return $this->db->fetch($sql, [
            'employee_id' => $employeeId,
            'month' => $month,
            'year' => $year
        ]);
    }

    public function getMonthlyAttendanceStats($month, $year)
    {
        $sql = "
            SELECT 
                e.department_id,
                d.name as department_name,
                COUNT(DISTINCT a.employee_id) as total_employees,
                COUNT(CASE WHEN a.status = 'Present' THEN 1 END) as total_present,
                COUNT(CASE WHEN a.status = 'Absent' THEN 1 END) as total_absent,
                COUNT(CASE WHEN a.status = 'Leave' THEN 1 END) as total_leave
            FROM attendance a
            JOIN employees e ON a.employee_id = e.id
            LEFT JOIN departments d ON e.department_id = d.id
            WHERE MONTH(a.date) = :month AND YEAR(a.date) = :year
            GROUP BY e.department_id, d.name
            ORDER BY d.name
        ";
        
        return $this->db->fetchAll($sql, ['month' => $month, 'year' => $year]);
    }

    public function getTodayAttendance()
    {
        $today = date('Y-m-d');
        
        $sql = "
            SELECT a.*, e.employee_id as emp_code, e.first_name, e.last_name,
                   d.name as department_name
            FROM {$this->table} a
            JOIN employees e ON a.employee_id = e.id
            LEFT JOIN departments d ON e.department_id = d.id
            WHERE a.date = :today
            ORDER BY a.check_in DESC
        ";
        
        return $this->db->fetchAll($sql, ['today' => $today]);
    }

    public function getWorkingDaysInMonth($month, $year)
    {
        // Calculate working days (excluding weekends)
        $startDate = new \DateTime("$year-$month-01");
        $endDate = new \DateTime($startDate->format('Y-m-t'));
        
        $workingDays = 0;
        $currentDate = clone $startDate;
        
        while ($currentDate <= $endDate) {
            $dayOfWeek = $currentDate->format('N');
            if ($dayOfWeek < 6) { // Monday to Friday
                $workingDays++;
            }
            $currentDate->add(new \DateInterval('P1D'));
        }
        
        return $workingDays;
    }
}
