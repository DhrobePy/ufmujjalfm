<?php

namespace App\Models;

class Employee extends BaseModel
{
    protected $table = 'employees';
    protected $fillable = [
        'user_id', 'employee_id', 'department_id', 'designation_id', 'branch_id',
        'first_name', 'last_name', 'date_of_birth', 'gender', 'phone_number',
        'address', 'date_of_joining', 'profile_picture', 'is_active'
    ];

    public function getEmployeeWithDetails($employeeId)
    {
        $sql = "
            SELECT e.*, u.email, u.role,
                   d.name as department_name, des.name as designation_name,
                   b.name as branch_name
            FROM employees e
            JOIN users u ON e.user_id = u.id
            LEFT JOIN departments d ON e.department_id = d.id
            LEFT JOIN designations des ON e.designation_id = des.id
            LEFT JOIN branches b ON e.branch_id = b.id
            WHERE e.id = :employee_id AND e.is_active = 1
        ";
        
        return $this->db->fetch($sql, ['employee_id' => $employeeId]);
    }

    public function getEmployeeByUserId($userId)
    {
        return $this->findBy('user_id', $userId);
    }

    public function getAllEmployeesWithDetails($filters = [])
    {
        $sql = "
            SELECT e.*, u.email, u.role,
                   d.name as department_name, des.name as designation_name,
                   b.name as branch_name
            FROM employees e
            JOIN users u ON e.user_id = u.id
            LEFT JOIN departments d ON e.department_id = d.id
            LEFT JOIN designations des ON e.designation_id = des.id
            LEFT JOIN branches b ON e.branch_id = b.id
            WHERE e.is_active = 1
        ";
        
        $params = [];
        
        if (isset($filters['department_id'])) {
            $sql .= " AND e.department_id = :department_id";
            $params['department_id'] = $filters['department_id'];
        }
        
        if (isset($filters['designation_id'])) {
            $sql .= " AND e.designation_id = :designation_id";
            $params['designation_id'] = $filters['designation_id'];
        }
        
        if (isset($filters['branch_id'])) {
            $sql .= " AND e.branch_id = :branch_id";
            $params['branch_id'] = $filters['branch_id'];
        }
        
        if (isset($filters['search'])) {
            $sql .= " AND (e.first_name LIKE :search OR e.last_name LIKE :search OR e.employee_id LIKE :search OR u.email LIKE :search)";
            $params['search'] = '%' . $filters['search'] . '%';
        }
        
        $sql .= " ORDER BY e.first_name, e.last_name";
        
        return $this->db->fetchAll($sql, $params);
    }

    public function generateEmployeeId()
    {
        $sql = "SELECT employee_id FROM employees ORDER BY id DESC LIMIT 1";
        $result = $this->db->fetch($sql);
        
        if ($result) {
            $lastId = $result['employee_id'];
            $number = (int) substr($lastId, 3) + 1;
            return 'EMP' . str_pad($number, 3, '0', STR_PAD_LEFT);
        }
        
        return 'EMP001';
    }

    public function isEmployeeIdExists($employeeId, $excludeId = null)
    {
        $sql = "SELECT COUNT(*) as count FROM {$this->table} WHERE employee_id = :employee_id";
        $params = ['employee_id' => $employeeId];
        
        if ($excludeId) {
            $sql .= " AND id != :exclude_id";
            $params['exclude_id'] = $excludeId;
        }
        
        $result = $this->db->fetch($sql, $params);
        return $result['count'] > 0;
    }

    public function getEmployeesByDepartment($departmentId)
    {
        return $this->all(['department_id' => $departmentId, 'is_active' => 1]);
    }

    public function getEmployeesByBranch($branchId)
    {
        return $this->all(['branch_id' => $branchId, 'is_active' => 1]);
    }

    public function getActiveEmployees()
    {
        return $this->all(['is_active' => 1]);
    }

    public function getEmployeeCount()
    {
        return $this->count(['is_active' => 1]);
    }

    public function getEmployeeCountByDepartment()
    {
        $sql = "
            SELECT d.name as department_name, COUNT(e.id) as employee_count
            FROM departments d
            LEFT JOIN employees e ON d.id = e.department_id AND e.is_active = 1
            GROUP BY d.id, d.name
            ORDER BY d.name
        ";
        
        return $this->db->fetchAll($sql);
    }

    public function getRecentJoinings($limit = 5)
    {
        $sql = "
            SELECT e.*, d.name as department_name, des.name as designation_name
            FROM employees e
            LEFT JOIN departments d ON e.department_id = d.id
            LEFT JOIN designations des ON e.designation_id = des.id
            WHERE e.is_active = 1
            ORDER BY e.date_of_joining DESC
            LIMIT :limit
        ";
        
        return $this->db->fetchAll($sql, ['limit' => $limit]);
    }

    public function updateProfile($employeeId, $data)
    {
        $allowedFields = [
            'first_name', 'last_name', 'date_of_birth', 'gender', 
            'phone_number', 'address', 'profile_picture'
        ];
        
        $updateData = array_intersect_key($data, array_flip($allowedFields));
        
        if (!empty($updateData)) {
            return $this->update($employeeId, $updateData);
        }
        
        return false;
    }
}
