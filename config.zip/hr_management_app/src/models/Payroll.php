<?php

namespace App\Models;

class Payroll extends BaseModel
{
    protected $table = 'payrolls';
    protected $fillable = [
        'month', 'year', 'status', 'total_amount', 'created_by', 'approved_by', 'approved_at', 'disbursed_at'
    ];

    public function createPayroll($month, $year, $createdBy, $employeeIds = [])
    {
        // Check if payroll already exists for this month/year
        $existing = $this->findBy('month', $month);
        if ($existing && $existing['year'] == $year) {
            return false;
        }
        
        $this->db->beginTransaction();
        
        try {
            // Create payroll record
            $payrollData = [
                'month' => $month,
                'year' => $year,
                'status' => 'Draft',
                'created_by' => $createdBy
            ];
            
            $payroll = $this->create($payrollData);
            
            if (!$payroll) {
                throw new \Exception('Failed to create payroll');
            }
            
            // Get employees to include in payroll
            $employees = $this->getEmployeesForPayroll($employeeIds);
            $totalAmount = 0;
            
            foreach ($employees as $employee) {
                $payrollItem = $this->generatePayrollItem($payroll['id'], $employee, $month, $year);
                if ($payrollItem) {
                    $totalAmount += $payrollItem['net_salary'];
                }
            }
            
            // Update total amount
            $this->update($payroll['id'], ['total_amount' => $totalAmount]);
            
            $this->db->commit();
            return $this->find($payroll['id']);
            
        } catch (\Exception $e) {
            $this->db->rollback();
            throw $e;
        }
    }

    public function generatePayrollItem($payrollId, $employee, $month, $year)
    {
        $salaryStructureModel = new SalaryStructure();
        $attendanceModel = new Attendance();
        
        // Get employee salary structure
        $salaryStructure = $salaryStructureModel->getEmployeeSalaryStructure($employee['id']);
        
        if (!$salaryStructure) {
            return false;
        }
        
        // Get attendance summary for the month
        $attendanceSummary = $attendanceModel->getAttendanceSummary($employee['id'], $month, $year);
        $workingDays = $attendanceModel->getWorkingDaysInMonth($month, $year);
        
        $presentDays = $attendanceSummary['present_days'] ?? 0;
        $leaveDays = $attendanceSummary['leave_days'] ?? 0;
        $halfDays = $attendanceSummary['half_days'] ?? 0;
        
        // Calculate effective working days
        $effectiveWorkingDays = $presentDays + $leaveDays + ($halfDays * 0.5);
        
        // Calculate pro-rated salary based on attendance
        $salaryRatio = $workingDays > 0 ? $effectiveWorkingDays / $workingDays : 1;
        
        $basicSalary = $salaryStructure['basic_salary'] * $salaryRatio;
        $grossSalary = $salaryStructure['gross_salary'] * $salaryRatio;
        
        // Get salary components and calculate deductions
        $structureWithComponents = $salaryStructureModel->getSalaryStructureWithComponents($salaryStructure['id']);
        $totalDeductions = 0;
        
        if (isset($structureWithComponents['components'])) {
            foreach ($structureWithComponents['components'] as $component) {
                if ($component['type'] === 'deduction') {
                    $amount = $component['amount'];
                    if ($component['is_percentage'] && $component['percentage']) {
                        $amount = ($basicSalary * $component['percentage']) / 100;
                    }
                    $totalDeductions += $amount;
                }
            }
        }
        
        $netSalary = $grossSalary - $totalDeductions;
        
        // Prepare salary details
        $salaryDetails = [
            'basic_salary' => $basicSalary,
            'gross_salary' => $grossSalary,
            'total_deductions' => $totalDeductions,
            'working_days' => $workingDays,
            'present_days' => $presentDays,
            'leave_days' => $leaveDays,
            'half_days' => $halfDays,
            'effective_working_days' => $effectiveWorkingDays,
            'salary_ratio' => $salaryRatio,
            'components' => $structureWithComponents['components'] ?? []
        ];
        
        $payrollItemData = [
            'payroll_id' => $payrollId,
            'employee_id' => $employee['id'],
            'basic_salary' => round($basicSalary, 2),
            'gross_salary' => round($grossSalary, 2),
            'total_deductions' => round($totalDeductions, 2),
            'net_salary' => round($netSalary, 2),
            'working_days' => $workingDays,
            'present_days' => $presentDays,
            'leave_days' => $leaveDays,
            'salary_details' => json_encode($salaryDetails)
        ];
        
        $itemId = $this->db->insert('payroll_items', $payrollItemData);
        $payrollItemData['id'] = $itemId;
        
        return $payrollItemData;
    }

    public function getPayrollWithItems($payrollId)
    {
        $payroll = $this->find($payrollId);
        
        if ($payroll) {
            $sql = "
                SELECT pi.*, 
                       e.employee_id as emp_code, e.first_name, e.last_name,
                       d.name as department_name, des.name as designation_name
                FROM payroll_items pi
                JOIN employees e ON pi.employee_id = e.id
                LEFT JOIN departments d ON e.department_id = d.id
                LEFT JOIN designations des ON e.designation_id = des.id
                WHERE pi.payroll_id = :payroll_id
                ORDER BY e.first_name, e.last_name
            ";
            
            $items = $this->db->fetchAll($sql, ['payroll_id' => $payrollId]);
            
            foreach ($items as &$item) {
                $item['salary_details'] = json_decode($item['salary_details'], true);
            }
            
            $payroll['items'] = $items;
        }
        
        return $payroll;
    }

    public function getAllPayrolls($filters = [])
    {
        $sql = "
            SELECT p.*, 
                   u1.email as created_by_email,
                   u2.email as approved_by_email,
                   COUNT(pi.id) as employee_count
            FROM {$this->table} p
            LEFT JOIN users u1 ON p.created_by = u1.id
            LEFT JOIN users u2 ON p.approved_by = u2.id
            LEFT JOIN payroll_items pi ON p.id = pi.payroll_id
            WHERE 1=1
        ";
        
        $params = [];
        
        if (isset($filters['year'])) {
            $sql .= " AND p.year = :year";
            $params['year'] = $filters['year'];
        }
        
        if (isset($filters['month'])) {
            $sql .= " AND p.month = :month";
            $params['month'] = $filters['month'];
        }
        
        if (isset($filters['status'])) {
            $sql .= " AND p.status = :status";
            $params['status'] = $filters['status'];
        }
        
        $sql .= " GROUP BY p.id ORDER BY p.year DESC, p.month DESC";
        
        return $this->db->fetchAll($sql, $params);
    }

    public function submitForApproval($payrollId)
    {
        return $this->update($payrollId, ['status' => 'Pending']);
    }

    public function approvePayroll($payrollId, $approvedBy)
    {
        return $this->update($payrollId, [
            'status' => 'Approved',
            'approved_by' => $approvedBy,
            'approved_at' => date('Y-m-d H:i:s')
        ]);
    }

    public function disbursePayroll($payrollId)
    {
        $result = $this->update($payrollId, [
            'status' => 'Disbursed',
            'disbursed_at' => date('Y-m-d H:i:s')
        ]);
        
        if ($result) {
            // Create salary transactions
            $payroll = $this->getPayrollWithItems($payrollId);
            
            foreach ($payroll['items'] as $item) {
                $transactionData = [
                    'reference_id' => "PAY-{$payrollId}-{$item['employee_id']}",
                    'description' => "Salary for {$payroll['month']}/{$payroll['year']} - {$item['first_name']} {$item['last_name']}",
                    'amount' => $item['net_salary'],
                    'type' => 'Salary',
                    'employee_id' => $item['employee_id'],
                    'created_by' => $payroll['approved_by'],
                    'transaction_date' => date('Y-m-d')
                ];
                
                $this->db->insert('transactions', $transactionData);
            }
        }
        
        return $result;
    }

    public function getPayrollStatistics($year = null)
    {
        if (!$year) {
            $year = date('Y');
        }
        
        $sql = "
            SELECT 
                COUNT(*) as total_payrolls,
                SUM(CASE WHEN status = 'Draft' THEN 1 ELSE 0 END) as draft_count,
                SUM(CASE WHEN status = 'Pending' THEN 1 ELSE 0 END) as pending_count,
                SUM(CASE WHEN status = 'Approved' THEN 1 ELSE 0 END) as approved_count,
                SUM(CASE WHEN status = 'Disbursed' THEN 1 ELSE 0 END) as disbursed_count,
                SUM(CASE WHEN status = 'Disbursed' THEN total_amount ELSE 0 END) as total_disbursed,
                AVG(CASE WHEN status = 'Disbursed' THEN total_amount ELSE NULL END) as avg_payroll_amount
            FROM {$this->table}
            WHERE year = :year
        ";
        
        return $this->db->fetch($sql, ['year' => $year]);
    }

    public function getMonthlyPayrollStats($year = null)
    {
        if (!$year) {
            $year = date('Y');
        }
        
        $sql = "
            SELECT 
                month,
                MONTHNAME(STR_TO_DATE(month, '%m')) as month_name,
                status,
                total_amount,
                COUNT(pi.id) as employee_count
            FROM {$this->table} p
            LEFT JOIN payroll_items pi ON p.id = pi.payroll_id
            WHERE p.year = :year
            GROUP BY p.id, month, status, total_amount
            ORDER BY month
        ";
        
        return $this->db->fetchAll($sql, ['year' => $year]);
    }

    public function getDepartmentWisePayrollStats($month, $year)
    {
        $sql = "
            SELECT 
                d.name as department_name,
                COUNT(pi.id) as employee_count,
                SUM(pi.net_salary) as total_salary,
                AVG(pi.net_salary) as avg_salary
            FROM payroll_items pi
            JOIN {$this->table} p ON pi.payroll_id = p.id
            JOIN employees e ON pi.employee_id = e.id
            LEFT JOIN departments d ON e.department_id = d.id
            WHERE p.month = :month AND p.year = :year
            GROUP BY d.id, d.name
            ORDER BY total_salary DESC
        ";
        
        return $this->db->fetchAll($sql, ['month' => $month, 'year' => $year]);
    }

    public function getEmployeePayrollHistory($employeeId, $limit = 12)
    {
        $sql = "
            SELECT p.month, p.year, p.status, pi.net_salary, pi.salary_details
            FROM {$this->table} p
            JOIN payroll_items pi ON p.id = pi.payroll_id
            WHERE pi.employee_id = :employee_id
            ORDER BY p.year DESC, p.month DESC
            LIMIT :limit
        ";
        
        $results = $this->db->fetchAll($sql, ['employee_id' => $employeeId, 'limit' => $limit]);
        
        foreach ($results as &$result) {
            $result['salary_details'] = json_decode($result['salary_details'], true);
        }
        
        return $results;
    }

    private function getEmployeesForPayroll($employeeIds = [])
    {
        $sql = "SELECT * FROM employees WHERE is_active = 1";
        $params = [];
        
        if (!empty($employeeIds)) {
            $placeholders = str_repeat('?,', count($employeeIds) - 1) . '?';
            $sql .= " AND id IN ($placeholders)";
            $params = $employeeIds;
        }
        
        $sql .= " ORDER BY first_name, last_name";
        
        return $this->db->fetchAll($sql, $params);
    }

    public function deletePayroll($payrollId)
    {
        $this->db->beginTransaction();
        
        try {
            // Delete payroll items first
            $this->db->delete('payroll_items', 'payroll_id = :payroll_id', ['payroll_id' => $payrollId]);
            
            // Delete payroll
            $result = $this->delete($payrollId);
            
            $this->db->commit();
            return $result;
            
        } catch (\Exception $e) {
            $this->db->rollback();
            throw $e;
        }
    }

    public function regeneratePayrollItem($payrollId, $employeeId)
    {
        // Delete existing payroll item
        $this->db->delete(
            'payroll_items', 
            'payroll_id = :payroll_id AND employee_id = :employee_id',
            ['payroll_id' => $payrollId, 'employee_id' => $employeeId]
        );
        
        // Get payroll details
        $payroll = $this->find($payrollId);
        $employee = $this->db->fetch("SELECT * FROM employees WHERE id = :id", ['id' => $employeeId]);
        
        if ($payroll && $employee) {
            return $this->generatePayrollItem($payrollId, $employee, $payroll['month'], $payroll['year']);
        }
        
        return false;
    }
}
