<?php

namespace App\Models;

class User extends BaseModel
{
    protected $table = 'users';
    protected $fillable = ['email', 'password', 'role', 'is_active'];
    protected $hidden = ['password'];

    public function authenticate($email, $password)
    {
        $user = $this->findBy('email', $email);
        
        if ($user && password_verify($password, $user['password'])) {
            return $user;
        }
        
        return false;
    }

    public function createUser($data)
    {
        if (isset($data['password'])) {
            $data['password'] = password_hash($data['password'], PASSWORD_DEFAULT);
        }
        
        return $this->create($data);
    }

    public function updatePassword($userId, $newPassword)
    {
        $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
        return $this->update($userId, ['password' => $hashedPassword]);
    }

    public function getByRole($role)
    {
        return $this->all(['role' => $role, 'is_active' => 1]);
    }

    public function isEmailExists($email, $excludeId = null)
    {
        $sql = "SELECT COUNT(*) as count FROM {$this->table} WHERE email = :email";
        $params = ['email' => $email];
        
        if ($excludeId) {
            $sql .= " AND id != :exclude_id";
            $params['exclude_id'] = $excludeId;
        }
        
        $result = $this->db->fetch($sql, $params);
        return $result['count'] > 0;
    }

    public function activate($userId)
    {
        return $this->update($userId, ['is_active' => 1]);
    }

    public function deactivate($userId)
    {
        return $this->update($userId, ['is_active' => 0]);
    }

    public function getActiveUsers()
    {
        return $this->all(['is_active' => 1]);
    }

    public function getUserWithEmployee($userId)
    {
        $sql = "
            SELECT u.*, e.id as employee_id, e.employee_id as emp_code, 
                   e.first_name, e.last_name, e.profile_picture,
                   d.name as department_name, des.name as designation_name,
                   b.name as branch_name
            FROM users u
            LEFT JOIN employees e ON u.id = e.user_id
            LEFT JOIN departments d ON e.department_id = d.id
            LEFT JOIN designations des ON e.designation_id = des.id
            LEFT JOIN branches b ON e.branch_id = b.id
            WHERE u.id = :user_id AND u.is_active = 1
        ";
        
        $result = $this->db->fetch($sql, ['user_id' => $userId]);
        
        if ($result) {
            return $this->hideFields($result);
        }
        
        return null;
    }
}
