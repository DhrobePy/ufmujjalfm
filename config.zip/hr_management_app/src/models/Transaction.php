<?php

namespace App\Models;

class Transaction extends BaseModel
{
    protected $table = 'transactions';
    protected $fillable = [
        'reference_id', 'description', 'amount', 'type', 'category', 
        'employee_id', 'created_by', 'transaction_date'
    ];

    public function addTransaction($data)
    {
        $data['transaction_date'] = $data['transaction_date'] ?? date('Y-m-d');
        $data['reference_id'] = $data['reference_id'] ?? $this->generateReferenceId($data['type']);
        
        return $this->create($data);
    }

    public function getTransactions($filters = [])
    {
        $sql = "
            SELECT t.*, 
                   e.employee_id as emp_code, e.first_name, e.last_name,
                   u.email as created_by_email
            FROM {$this->table} t
            LEFT JOIN employees e ON t.employee_id = e.id
            LEFT JOIN users u ON t.created_by = u.id
            WHERE 1=1
        ";
        
        $params = [];
        
        if (isset($filters['type'])) {
            $sql .= " AND t.type = :type";
            $params['type'] = $filters['type'];
        }
        
        if (isset($filters['category'])) {
            $sql .= " AND t.category = :category";
            $params['category'] = $filters['category'];
        }
        
        if (isset($filters['employee_id'])) {
            $sql .= " AND t.employee_id = :employee_id";
            $params['employee_id'] = $filters['employee_id'];
        }
        
        if (isset($filters['date_from'])) {
            $sql .= " AND t.transaction_date >= :date_from";
            $params['date_from'] = $filters['date_from'];
        }
        
        if (isset($filters['date_to'])) {
            $sql .= " AND t.transaction_date <= :date_to";
            $params['date_to'] = $filters['date_to'];
        }
        
        if (isset($filters['month'])) {
            $sql .= " AND MONTH(t.transaction_date) = :month";
            $params['month'] = $filters['month'];
        }
        
        if (isset($filters['year'])) {
            $sql .= " AND YEAR(t.transaction_date) = :year";
            $params['year'] = $filters['year'];
        }
        
        if (isset($filters['search'])) {
            $sql .= " AND (t.description LIKE :search OR t.reference_id LIKE :search OR e.first_name LIKE :search OR e.last_name LIKE :search)";
            $params['search'] = '%' . $filters['search'] . '%';
        }
        
        $sql .= " ORDER BY t.transaction_date DESC, t.created_at DESC";
        
        if (isset($filters['limit'])) {
            $sql .= " LIMIT " . (int)$filters['limit'];
        }
        
        return $this->db->fetchAll($sql, $params);
    }

    public function getTransactionSummary($filters = [])
    {
        $sql = "
            SELECT 
                type,
                COUNT(*) as transaction_count,
                SUM(amount) as total_amount,
                AVG(amount) as average_amount
            FROM {$this->table}
            WHERE 1=1
        ";
        
        $params = [];
        
        if (isset($filters['date_from'])) {
            $sql .= " AND transaction_date >= :date_from";
            $params['date_from'] = $filters['date_from'];
        }
        
        if (isset($filters['date_to'])) {
            $sql .= " AND transaction_date <= :date_to";
            $params['date_to'] = $filters['date_to'];
        }
        
        if (isset($filters['month'])) {
            $sql .= " AND MONTH(transaction_date) = :month";
            $params['month'] = $filters['month'];
        }
        
        if (isset($filters['year'])) {
            $sql .= " AND YEAR(transaction_date) = :year";
            $params['year'] = $filters['year'];
        }
        
        $sql .= " GROUP BY type ORDER BY type";
        
        return $this->db->fetchAll($sql, $params);
    }

    public function getMonthlyTransactionStats($year = null)
    {
        if (!$year) {
            $year = date('Y');
        }
        
        $sql = "
            SELECT 
                MONTH(transaction_date) as month,
                MONTHNAME(transaction_date) as month_name,
                type,
                SUM(amount) as total_amount,
                COUNT(*) as transaction_count
            FROM {$this->table}
            WHERE YEAR(transaction_date) = :year
            GROUP BY MONTH(transaction_date), MONTHNAME(transaction_date), type
            ORDER BY MONTH(transaction_date), type
        ";
        
        return $this->db->fetchAll($sql, ['year' => $year]);
    }

    public function getCategoryWiseExpenses($filters = [])
    {
        $sql = "
            SELECT 
                category,
                COUNT(*) as transaction_count,
                SUM(amount) as total_amount,
                AVG(amount) as average_amount
            FROM {$this->table}
            WHERE type = 'Expense'
        ";
        
        $params = [];
        
        if (isset($filters['year'])) {
            $sql .= " AND YEAR(transaction_date) = :year";
            $params['year'] = $filters['year'];
        }
        
        if (isset($filters['month'])) {
            $sql .= " AND MONTH(transaction_date) = :month";
            $params['month'] = $filters['month'];
        }
        
        $sql .= " GROUP BY category ORDER BY total_amount DESC";
        
        return $this->db->fetchAll($sql, $params);
    }

    public function getDailyTransactionStats($month = null, $year = null)
    {
        if (!$month) $month = date('n');
        if (!$year) $year = date('Y');
        
        $sql = "
            SELECT 
                DAY(transaction_date) as day,
                transaction_date,
                SUM(CASE WHEN type = 'Expense' THEN amount ELSE 0 END) as total_expenses,
                SUM(CASE WHEN type = 'Salary' THEN amount ELSE 0 END) as total_salaries,
                SUM(CASE WHEN type = 'Advance' THEN amount ELSE 0 END) as total_advances,
                SUM(CASE WHEN type = 'Loan' THEN amount ELSE 0 END) as total_loans,
                COUNT(*) as total_transactions
            FROM {$this->table}
            WHERE MONTH(transaction_date) = :month AND YEAR(transaction_date) = :year
            GROUP BY DAY(transaction_date), transaction_date
            ORDER BY transaction_date
        ";
        
        return $this->db->fetchAll($sql, ['month' => $month, 'year' => $year]);
    }

    public function getEmployeeTransactions($employeeId, $filters = [])
    {
        $sql = "
            SELECT t.*, u.email as created_by_email
            FROM {$this->table} t
            LEFT JOIN users u ON t.created_by = u.id
            WHERE t.employee_id = :employee_id
        ";
        
        $params = ['employee_id' => $employeeId];
        
        if (isset($filters['type'])) {
            $sql .= " AND t.type = :type";
            $params['type'] = $filters['type'];
        }
        
        if (isset($filters['year'])) {
            $sql .= " AND YEAR(t.transaction_date) = :year";
            $params['year'] = $filters['year'];
        }
        
        $sql .= " ORDER BY t.transaction_date DESC";
        
        return $this->db->fetchAll($sql, $params);
    }

    public function getFinancialSummary($year = null)
    {
        if (!$year) {
            $year = date('Y');
        }
        
        $sql = "
            SELECT 
                SUM(CASE WHEN type = 'Expense' THEN amount ELSE 0 END) as total_expenses,
                SUM(CASE WHEN type = 'Salary' THEN amount ELSE 0 END) as total_salaries,
                SUM(CASE WHEN type = 'Advance' THEN amount ELSE 0 END) as total_advances,
                SUM(CASE WHEN type = 'Loan' THEN amount ELSE 0 END) as total_loans,
                COUNT(CASE WHEN type = 'Expense' THEN 1 END) as expense_count,
                COUNT(CASE WHEN type = 'Salary' THEN 1 END) as salary_count,
                COUNT(CASE WHEN type = 'Advance' THEN 1 END) as advance_count,
                COUNT(CASE WHEN type = 'Loan' THEN 1 END) as loan_count,
                COUNT(*) as total_transactions,
                SUM(amount) as total_amount
            FROM {$this->table}
            WHERE YEAR(transaction_date) = :year
        ";
        
        return $this->db->fetch($sql, ['year' => $year]);
    }

    public function getTopExpenseCategories($limit = 10, $year = null)
    {
        if (!$year) {
            $year = date('Y');
        }
        
        $sql = "
            SELECT 
                category,
                SUM(amount) as total_amount,
                COUNT(*) as transaction_count,
                AVG(amount) as average_amount
            FROM {$this->table}
            WHERE type = 'Expense' AND YEAR(transaction_date) = :year
            GROUP BY category
            ORDER BY total_amount DESC
            LIMIT :limit
        ";
        
        return $this->db->fetchAll($sql, ['year' => $year, 'limit' => $limit]);
    }

    public function getRecentTransactions($limit = 10)
    {
        $sql = "
            SELECT t.*, 
                   e.employee_id as emp_code, e.first_name, e.last_name,
                   u.email as created_by_email
            FROM {$this->table} t
            LEFT JOIN employees e ON t.employee_id = e.id
            LEFT JOIN users u ON t.created_by = u.id
            ORDER BY t.created_at DESC
            LIMIT :limit
        ";
        
        return $this->db->fetchAll($sql, ['limit' => $limit]);
    }

    public function getCashFlowData($year = null)
    {
        if (!$year) {
            $year = date('Y');
        }
        
        $sql = "
            SELECT 
                MONTH(transaction_date) as month,
                MONTHNAME(transaction_date) as month_name,
                SUM(CASE WHEN type IN ('Expense', 'Salary', 'Advance', 'Loan') THEN amount ELSE 0 END) as total_outflow,
                SUM(CASE WHEN type = 'Expense' THEN amount ELSE 0 END) as expenses,
                SUM(CASE WHEN type = 'Salary' THEN amount ELSE 0 END) as salaries,
                SUM(CASE WHEN type = 'Advance' THEN amount ELSE 0 END) as advances,
                SUM(CASE WHEN type = 'Loan' THEN amount ELSE 0 END) as loans
            FROM {$this->table}
            WHERE YEAR(transaction_date) = :year
            GROUP BY MONTH(transaction_date), MONTHNAME(transaction_date)
            ORDER BY MONTH(transaction_date)
        ";
        
        return $this->db->fetchAll($sql, ['year' => $year]);
    }

    private function generateReferenceId($type)
    {
        $prefix = strtoupper(substr($type, 0, 3));
        $timestamp = time();
        $random = mt_rand(100, 999);
        
        return "{$prefix}-{$timestamp}-{$random}";
    }

    public function updateTransaction($id, $data)
    {
        // Don't allow updating certain fields
        unset($data['reference_id'], $data['created_by'], $data['created_at']);
        
        return $this->update($id, $data);
    }

    public function deleteTransaction($id)
    {
        return $this->delete($id);
    }

    public function getTransactionsByReference($referenceId)
    {
        return $this->all(['reference_id' => $referenceId]);
    }

    public function bulkAddTransactions($transactions)
    {
        $this->db->beginTransaction();
        
        try {
            $addedCount = 0;
            
            foreach ($transactions as $transaction) {
                if ($this->addTransaction($transaction)) {
                    $addedCount++;
                }
            }
            
            $this->db->commit();
            return $addedCount;
            
        } catch (\Exception $e) {
            $this->db->rollback();
            throw $e;
        }
    }
}
