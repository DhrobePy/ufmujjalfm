<?php

namespace App\Models;

class Leave extends BaseModel
{
    protected $table = 'leaves';
    protected $fillable = [
        'employee_id', 'leave_type_id', 'start_date', 'end_date', 
        'days_requested', 'reason', 'status', 'approved_by', 
        'approved_at', 'rejection_reason'
    ];

    public function applyLeave($data)
    {
        // Calculate days requested
        $startDate = new \DateTime($data['start_date']);
        $endDate = new \DateTime($data['end_date']);
        $interval = $startDate->diff($endDate);
        $daysRequested = $interval->days + 1;
        
        // Check for weekends and exclude them
        $workingDays = $this->calculateWorkingDays($data['start_date'], $data['end_date']);
        
        $data['days_requested'] = $workingDays;
        $data['status'] = 'Pending';
        
        return $this->create($data);
    }

    public function getEmployeeLeaves($employeeId, $year = null)
    {
        $sql = "
            SELECT l.*, lt.name as leave_type_name, 
                   u.email as approved_by_email
            FROM {$this->table} l
            LEFT JOIN leave_types lt ON l.leave_type_id = lt.id
            LEFT JOIN users u ON l.approved_by = u.id
            WHERE l.employee_id = :employee_id
        ";
        
        $params = ['employee_id' => $employeeId];
        
        if ($year) {
            $sql .= " AND YEAR(l.start_date) = :year";
            $params['year'] = $year;
        }
        
        $sql .= " ORDER BY l.created_at DESC";
        
        return $this->db->fetchAll($sql, $params);
    }

    public function getPendingLeaves()
    {
        $sql = "
            SELECT l.*, lt.name as leave_type_name,
                   e.employee_id as emp_code, e.first_name, e.last_name,
                   d.name as department_name, des.name as designation_name
            FROM {$this->table} l
            JOIN employees e ON l.employee_id = e.id
            LEFT JOIN leave_types lt ON l.leave_type_id = lt.id
            LEFT JOIN departments d ON e.department_id = d.id
            LEFT JOIN designations des ON e.designation_id = des.id
            WHERE l.status = 'Pending'
            ORDER BY l.created_at ASC
        ";
        
        return $this->db->fetchAll($sql);
    }

    public function approveLeave($leaveId, $approvedBy, $rejectionReason = null)
    {
        $data = [
            'status' => 'Approved',
            'approved_by' => $approvedBy,
            'approved_at' => date('Y-m-d H:i:s')
        ];
        
        if ($rejectionReason) {
            $data['status'] = 'Rejected';
            $data['rejection_reason'] = $rejectionReason;
        }
        
        return $this->update($leaveId, $data);
    }

    public function getLeaveBalance($employeeId, $leaveTypeId, $year = null)
    {
        if (!$year) {
            $year = date('Y');
        }
        
        // Get leave type allowance
        $leaveType = $this->db->fetch(
            "SELECT days_allowed FROM leave_types WHERE id = :id",
            ['id' => $leaveTypeId]
        );
        
        if (!$leaveType) {
            return 0;
        }
        
        // Get used leaves for this year
        $usedLeaves = $this->db->fetch(
            "SELECT SUM(days_requested) as used_days 
             FROM {$this->table} 
             WHERE employee_id = :employee_id 
             AND leave_type_id = :leave_type_id 
             AND status = 'Approved' 
             AND YEAR(start_date) = :year",
            [
                'employee_id' => $employeeId,
                'leave_type_id' => $leaveTypeId,
                'year' => $year
            ]
        );
        
        $usedDays = $usedLeaves['used_days'] ?? 0;
        $allowedDays = $leaveType['days_allowed'];
        
        return max(0, $allowedDays - $usedDays);
    }

    public function getLeaveReport($filters = [])
    {
        $sql = "
            SELECT l.*, lt.name as leave_type_name,
                   e.employee_id as emp_code, e.first_name, e.last_name,
                   d.name as department_name, des.name as designation_name,
                   b.name as branch_name,
                   u.email as approved_by_email
            FROM {$this->table} l
            JOIN employees e ON l.employee_id = e.id
            LEFT JOIN leave_types lt ON l.leave_type_id = lt.id
            LEFT JOIN departments d ON e.department_id = d.id
            LEFT JOIN designations des ON e.designation_id = des.id
            LEFT JOIN branches b ON e.branch_id = b.id
            LEFT JOIN users u ON l.approved_by = u.id
            WHERE 1=1
        ";
        
        $params = [];
        
        if (isset($filters['employee_id'])) {
            $sql .= " AND l.employee_id = :employee_id";
            $params['employee_id'] = $filters['employee_id'];
        }
        
        if (isset($filters['department_id'])) {
            $sql .= " AND e.department_id = :department_id";
            $params['department_id'] = $filters['department_id'];
        }
        
        if (isset($filters['leave_type_id'])) {
            $sql .= " AND l.leave_type_id = :leave_type_id";
            $params['leave_type_id'] = $filters['leave_type_id'];
        }
        
        if (isset($filters['status'])) {
            $sql .= " AND l.status = :status";
            $params['status'] = $filters['status'];
        }
        
        if (isset($filters['year'])) {
            $sql .= " AND YEAR(l.start_date) = :year";
            $params['year'] = $filters['year'];
        }
        
        $sql .= " ORDER BY l.created_at DESC";
        
        return $this->db->fetchAll($sql, $params);
    }

    public function getLeaveStatistics($year = null)
    {
        if (!$year) {
            $year = date('Y');
        }
        
        $sql = "
            SELECT 
                lt.name as leave_type,
                COUNT(l.id) as total_applications,
                SUM(CASE WHEN l.status = 'Approved' THEN 1 ELSE 0 END) as approved,
                SUM(CASE WHEN l.status = 'Rejected' THEN 1 ELSE 0 END) as rejected,
                SUM(CASE WHEN l.status = 'Pending' THEN 1 ELSE 0 END) as pending,
                SUM(CASE WHEN l.status = 'Approved' THEN l.days_requested ELSE 0 END) as total_days_taken
            FROM leave_types lt
            LEFT JOIN {$this->table} l ON lt.id = l.leave_type_id AND YEAR(l.start_date) = :year
            GROUP BY lt.id, lt.name
            ORDER BY lt.name
        ";
        
        return $this->db->fetchAll($sql, ['year' => $year]);
    }

    private function calculateWorkingDays($startDate, $endDate)
    {
        $start = new \DateTime($startDate);
        $end = new \DateTime($endDate);
        $workingDays = 0;
        
        while ($start <= $end) {
            $dayOfWeek = $start->format('N');
            if ($dayOfWeek < 6) { // Monday to Friday
                $workingDays++;
            }
            $start->add(new \DateInterval('P1D'));
        }
        
        return $workingDays;
    }

    public function hasOverlappingLeave($employeeId, $startDate, $endDate, $excludeId = null)
    {
        $sql = "
            SELECT COUNT(*) as count 
            FROM {$this->table} 
            WHERE employee_id = :employee_id 
            AND status IN ('Pending', 'Approved')
            AND (
                (start_date <= :start_date AND end_date >= :start_date) OR
                (start_date <= :end_date AND end_date >= :end_date) OR
                (start_date >= :start_date AND end_date <= :end_date)
            )
        ";
        
        $params = [
            'employee_id' => $employeeId,
            'start_date' => $startDate,
            'end_date' => $endDate
        ];
        
        if ($excludeId) {
            $sql .= " AND id != :exclude_id";
            $params['exclude_id'] = $excludeId;
        }
        
        $result = $this->db->fetch($sql, $params);
        return $result['count'] > 0;
    }
}
