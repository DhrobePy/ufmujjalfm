<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $title ?? 'HR Management System' ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: {
                            50: '#eff6ff',
                            100: '#dbeafe',
                            200: '#bfdbfe',
                            300: '#93c5fd',
                            400: '#60a5fa',
                            500: '#3b82f6',
                            600: '#2563eb',
                            700: '#1d4ed8',
                            800: '#1e40af',
                            900: '#1e3a8a',
                        }
                    }
                }
            }
        }
    </script>
    <style>
        .sidebar-transition {
            transition: transform 0.3s ease-in-out;
        }
        
        .fade-in {
            animation: fadeIn 0.3s ease-in;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .hover-scale {
            transition: transform 0.2s ease;
        }
        
        .hover-scale:hover {
            transform: scale(1.02);
        }
        
        .card-shadow {
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
        }
        
        .card-shadow:hover {
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
        }
    </style>
</head>
<body class="bg-gray-50 font-sans">
    <?php if (isset($_SESSION['user_id'])): ?>
        <!-- Navigation -->
        <nav class="bg-white shadow-lg border-b border-gray-200">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="flex justify-between h-16">
                    <div class="flex items-center">
                        <!-- Mobile menu button -->
                        <button id="mobile-menu-button" class="md:hidden inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-gray-500 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-primary-500">
                            <i class="fas fa-bars text-xl"></i>
                        </button>
                        
                        <!-- Logo -->
                        <div class="flex-shrink-0 flex items-center ml-4 md:ml-0">
                            <i class="fas fa-building text-primary-600 text-2xl mr-3"></i>
                            <h1 class="text-xl font-bold text-gray-900">HR Management</h1>
                        </div>
                    </div>
                    
                    <!-- User menu -->
                    <div class="flex items-center space-x-4">
                        <!-- Notifications -->
                        <button class="p-2 text-gray-400 hover:text-gray-500 hover:bg-gray-100 rounded-full">
                            <i class="fas fa-bell text-lg"></i>
                        </button>
                        
                        <!-- User dropdown -->
                        <div class="relative">
                            <button id="user-menu-button" class="flex items-center space-x-3 text-sm rounded-full focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500">
                                <div class="w-8 h-8 bg-primary-600 rounded-full flex items-center justify-center">
                                    <i class="fas fa-user text-white text-sm"></i>
                                </div>
                                <span class="hidden md:block text-gray-700 font-medium"><?= htmlspecialchars($_SESSION['user_email'] ?? 'User') ?></span>
                                <i class="fas fa-chevron-down text-gray-400 text-xs"></i>
                            </button>
                            
                            <!-- Dropdown menu -->
                            <div id="user-dropdown" class="hidden absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 z-50">
                                <a href="/employee/profile" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                                    <i class="fas fa-user mr-2"></i>Profile
                                </a>
                                <a href="/logout" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                                    <i class="fas fa-sign-out-alt mr-2"></i>Logout
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </nav>
        
        <div class="flex h-screen pt-16">
            <!-- Sidebar -->
            <aside id="sidebar" class="fixed inset-y-0 left-0 z-40 w-64 bg-white shadow-lg transform -translate-x-full md:translate-x-0 sidebar-transition mt-16">
                <div class="flex flex-col h-full">
                    <div class="flex-1 flex flex-col pt-5 pb-4 overflow-y-auto">
                        <nav class="mt-5 flex-1 px-2 space-y-1">
                            <?php
                            $userRole = $_SESSION['user_role'] ?? 'employee';
                            $currentPath = $_SERVER['REQUEST_URI'];
                            
                            function isActive($path, $currentPath) {
                                return strpos($currentPath, $path) === 0 ? 'bg-primary-100 text-primary-700' : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900';
                            }
                            ?>
                            
                            <?php if ($userRole === 'admin'): ?>
                                <a href="/admin/dashboard" class="<?= isActive('/admin/dashboard', $currentPath) ?> group flex items-center px-2 py-2 text-sm font-medium rounded-md">
                                    <i class="fas fa-tachometer-alt mr-3 text-lg"></i>Dashboard
                                </a>
                                <a href="/admin/employees" class="<?= isActive('/admin/employees', $currentPath) ?> group flex items-center px-2 py-2 text-sm font-medium rounded-md">
                                    <i class="fas fa-users mr-3 text-lg"></i>Employees
                                </a>
                                <a href="/admin/approvals" class="<?= isActive('/admin/approvals', $currentPath) ?> group flex items-center px-2 py-2 text-sm font-medium rounded-md">
                                    <i class="fas fa-check-circle mr-3 text-lg"></i>Approvals
                                </a>
                                <a href="/admin/reports" class="<?= isActive('/admin/reports', $currentPath) ?> group flex items-center px-2 py-2 text-sm font-medium rounded-md">
                                    <i class="fas fa-chart-bar mr-3 text-lg"></i>Reports
                                </a>
                            <?php elseif ($userRole === 'accounts'): ?>
                                <a href="/accounts/dashboard" class="<?= isActive('/accounts/dashboard', $currentPath) ?> group flex items-center px-2 py-2 text-sm font-medium rounded-md">
                                    <i class="fas fa-tachometer-alt mr-3 text-lg"></i>Dashboard
                                </a>
                                <a href="/accounts/salary-structures" class="<?= isActive('/accounts/salary-structures', $currentPath) ?> group flex items-center px-2 py-2 text-sm font-medium rounded-md">
                                    <i class="fas fa-money-bill-wave mr-3 text-lg"></i>Salary Structures
                                </a>
                                <a href="/accounts/payroll" class="<?= isActive('/accounts/payroll', $currentPath) ?> group flex items-center px-2 py-2 text-sm font-medium rounded-md">
                                    <i class="fas fa-calculator mr-3 text-lg"></i>Payroll
                                </a>
                                <a href="/accounts/attendance-reports" class="<?= isActive('/accounts/attendance-reports', $currentPath) ?> group flex items-center px-2 py-2 text-sm font-medium rounded-md">
                                    <i class="fas fa-calendar-check mr-3 text-lg"></i>Attendance Reports
                                </a>
                                <a href="/accounts/transactions" class="<?= isActive('/accounts/transactions', $currentPath) ?> group flex items-center px-2 py-2 text-sm font-medium rounded-md">
                                    <i class="fas fa-exchange-alt mr-3 text-lg"></i>Transactions
                                </a>
                            <?php else: ?>
                                <a href="/employee/dashboard" class="<?= isActive('/employee/dashboard', $currentPath) ?> group flex items-center px-2 py-2 text-sm font-medium rounded-md">
                                    <i class="fas fa-tachometer-alt mr-3 text-lg"></i>Dashboard
                                </a>
                                <a href="/employee/profile" class="<?= isActive('/employee/profile', $currentPath) ?> group flex items-center px-2 py-2 text-sm font-medium rounded-md">
                                    <i class="fas fa-user mr-3 text-lg"></i>Profile
                                </a>
                                <a href="/employee/attendance" class="<?= isActive('/employee/attendance', $currentPath) ?> group flex items-center px-2 py-2 text-sm font-medium rounded-md">
                                    <i class="fas fa-calendar-check mr-3 text-lg"></i>Attendance
                                </a>
                                <a href="/employee/leaves" class="<?= isActive('/employee/leaves', $currentPath) ?> group flex items-center px-2 py-2 text-sm font-medium rounded-md">
                                    <i class="fas fa-calendar-times mr-3 text-lg"></i>Leave Applications
                                </a>
                                <a href="/employee/salary-advances" class="<?= isActive('/employee/salary-advances', $currentPath) ?> group flex items-center px-2 py-2 text-sm font-medium rounded-md">
                                    <i class="fas fa-hand-holding-usd mr-3 text-lg"></i>Salary Advances
                                </a>
                                <a href="/employee/loans" class="<?= isActive('/employee/loans', $currentPath) ?> group flex items-center px-2 py-2 text-sm font-medium rounded-md">
                                    <i class="fas fa-piggy-bank mr-3 text-lg"></i>Loans
                                </a>
                                <a href="/employee/payslips" class="<?= isActive('/employee/payslips', $currentPath) ?> group flex items-center px-2 py-2 text-sm font-medium rounded-md">
                                    <i class="fas fa-file-invoice-dollar mr-3 text-lg"></i>Payslips
                                </a>
                            <?php endif; ?>
                        </nav>
                    </div>
                </div>
            </aside>
            
            <!-- Main content -->
            <main class="flex-1 md:ml-64 overflow-y-auto">
                <div class="py-6">
                    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                        <!-- Flash messages -->
                        <?php if (isset($_SESSION['flash_message'])): ?>
                            <div class="mb-4 p-4 rounded-md <?= $_SESSION['flash_type'] === 'error' ? 'bg-red-50 text-red-700 border border-red-200' : 'bg-green-50 text-green-700 border border-green-200' ?>">
                                <div class="flex">
                                    <div class="flex-shrink-0">
                                        <i class="fas <?= $_SESSION['flash_type'] === 'error' ? 'fa-exclamation-circle' : 'fa-check-circle' ?> text-lg"></i>
                                    </div>
                                    <div class="ml-3">
                                        <p class="text-sm font-medium"><?= htmlspecialchars($_SESSION['flash_message']) ?></p>
                                    </div>
                                </div>
                            </div>
                            <?php unset($_SESSION['flash_message'], $_SESSION['flash_type']); ?>
                        <?php endif; ?>
                        
                        <!-- Page content -->
                        <div class="fade-in">
                            <?= $content ?>
                        </div>
                    </div>
                </div>
            </main>
        </div>
        
        <!-- Mobile sidebar overlay -->
        <div id="sidebar-overlay" class="hidden fixed inset-0 z-30 bg-gray-600 bg-opacity-50 md:hidden"></div>
    <?php else: ?>
        <!-- Login page content -->
        <div class="min-h-screen flex items-center justify-center bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
            <?= $content ?>
        </div>
    <?php endif; ?>
    
    <script>
        // Mobile menu toggle
        const mobileMenuButton = document.getElementById('mobile-menu-button');
        const sidebar = document.getElementById('sidebar');
        const sidebarOverlay = document.getElementById('sidebar-overlay');
        
        if (mobileMenuButton) {
            mobileMenuButton.addEventListener('click', function() {
                sidebar.classList.toggle('-translate-x-full');
                sidebarOverlay.classList.toggle('hidden');
            });
        }
        
        if (sidebarOverlay) {
            sidebarOverlay.addEventListener('click', function() {
                sidebar.classList.add('-translate-x-full');
                sidebarOverlay.classList.add('hidden');
            });
        }
        
        // User dropdown toggle
        const userMenuButton = document.getElementById('user-menu-button');
        const userDropdown = document.getElementById('user-dropdown');
        
        if (userMenuButton) {
            userMenuButton.addEventListener('click', function() {
                userDropdown.classList.toggle('hidden');
            });
            
            // Close dropdown when clicking outside
            document.addEventListener('click', function(event) {
                if (!userMenuButton.contains(event.target) && !userDropdown.contains(event.target)) {
                    userDropdown.classList.add('hidden');
                }
            });
        }
        
        // Auto-hide flash messages
        setTimeout(function() {
            const flashMessages = document.querySelectorAll('[class*="bg-red-50"], [class*="bg-green-50"]');
            flashMessages.forEach(function(message) {
                if (message.parentElement) {
                    message.style.transition = 'opacity 0.5s ease-out';
                    message.style.opacity = '0';
                    setTimeout(function() {
                        message.remove();
                    }, 500);
                }
            });
        }, 5000);
    </script>
</body>
</html>
