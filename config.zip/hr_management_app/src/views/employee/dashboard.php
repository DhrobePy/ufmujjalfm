<?php
$pageTitle = 'Employee Dashboard';
ob_start();
?>

<!-- Page Header -->
<div class="mb-8">
    <div class="flex items-center justify-between">
        <div>
            <h1 class="text-3xl font-bold text-gray-900">Welcome back, <?= htmlspecialchars($employee['first_name'] ?? 'Employee') ?>!</h1>
            <p class="mt-2 text-gray-600">Here's what's happening with your account today.</p>
        </div>
        <div class="flex items-center space-x-3">
            <div class="text-right">
                <p class="text-sm text-gray-500">Today's Date</p>
                <p class="text-lg font-semibold text-gray-900"><?= date('M d, Y') ?></p>
            </div>
        </div>
    </div>
</div>

<!-- Quick Stats -->
<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
    <!-- Attendance This Month -->
    <div class="bg-white overflow-hidden shadow-sm rounded-lg card-shadow hover-scale">
        <div class="p-6">
            <div class="flex items-center">
                <div class="flex-shrink-0">
                    <div class="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                        <i class="fas fa-calendar-check text-green-600 text-xl"></i>
                    </div>
                </div>
                <div class="ml-4">
                    <p class="text-sm font-medium text-gray-500">Attendance This Month</p>
                    <p class="text-2xl font-bold text-gray-900"><?= $attendance_summary['present_days'] ?? 0 ?>/<?= $attendance_summary['working_days'] ?? 0 ?></p>
                    <p class="text-sm text-green-600"><?= round((($attendance_summary['present_days'] ?? 0) / max($attendance_summary['working_days'] ?? 1, 1)) * 100, 1) ?>% Present</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Leave Balance -->
    <div class="bg-white overflow-hidden shadow-sm rounded-lg card-shadow hover-scale">
        <div class="p-6">
            <div class="flex items-center">
                <div class="flex-shrink-0">
                    <div class="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                        <i class="fas fa-calendar-times text-blue-600 text-xl"></i>
                    </div>
                </div>
                <div class="ml-4">
                    <p class="text-sm font-medium text-gray-500">Leave Balance</p>
                    <p class="text-2xl font-bold text-gray-900"><?= $leave_balance['remaining'] ?? 0 ?></p>
                    <p class="text-sm text-blue-600">of <?= $leave_balance['total'] ?? 0 ?> days</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Pending Applications -->
    <div class="bg-white overflow-hidden shadow-sm rounded-lg card-shadow hover-scale">
        <div class="p-6">
            <div class="flex items-center">
                <div class="flex-shrink-0">
                    <div class="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
                        <i class="fas fa-clock text-yellow-600 text-xl"></i>
                    </div>
                </div>
                <div class="ml-4">
                    <p class="text-sm font-medium text-gray-500">Pending Applications</p>
                    <p class="text-2xl font-bold text-gray-900"><?= $pending_applications ?? 0 ?></p>
                    <p class="text-sm text-yellow-600">Awaiting approval</p>
                </div>
            </div>
        </div>
    </div>

    <!-- This Month Salary -->
    <div class="bg-white overflow-hidden shadow-sm rounded-lg card-shadow hover-scale">
        <div class="p-6">
            <div class="flex items-center">
                <div class="flex-shrink-0">
                    <div class="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                        <i class="fas fa-dollar-sign text-purple-600 text-xl"></i>
                    </div>
                </div>
                <div class="ml-4">
                    <p class="text-sm font-medium text-gray-500">This Month Salary</p>
                    <p class="text-2xl font-bold text-gray-900">$<?= number_format($current_salary ?? 0, 2) ?></p>
                    <p class="text-sm text-purple-600">Net amount</p>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Quick Actions -->
<div class="mb-8">
    <h2 class="text-xl font-semibold text-gray-900 mb-4">Quick Actions</h2>
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <a href="/employee/attendance" class="bg-white p-6 rounded-lg shadow-sm border border-gray-200 hover:border-primary-300 hover:shadow-md transition-all duration-200 group">
            <div class="flex items-center">
                <div class="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center group-hover:bg-green-200 transition-colors">
                    <i class="fas fa-clock text-green-600"></i>
                </div>
                <div class="ml-3">
                    <p class="text-sm font-medium text-gray-900">Mark Attendance</p>
                    <p class="text-xs text-gray-500">Clock in/out</p>
                </div>
            </div>
        </a>

        <a href="/employee/leaves" class="bg-white p-6 rounded-lg shadow-sm border border-gray-200 hover:border-primary-300 hover:shadow-md transition-all duration-200 group">
            <div class="flex items-center">
                <div class="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center group-hover:bg-blue-200 transition-colors">
                    <i class="fas fa-calendar-plus text-blue-600"></i>
                </div>
                <div class="ml-3">
                    <p class="text-sm font-medium text-gray-900">Apply for Leave</p>
                    <p class="text-xs text-gray-500">Request time off</p>
                </div>
            </div>
        </a>

        <a href="/employee/salary-advances" class="bg-white p-6 rounded-lg shadow-sm border border-gray-200 hover:border-primary-300 hover:shadow-md transition-all duration-200 group">
            <div class="flex items-center">
                <div class="w-10 h-10 bg-yellow-100 rounded-lg flex items-center justify-center group-hover:bg-yellow-200 transition-colors">
                    <i class="fas fa-hand-holding-usd text-yellow-600"></i>
                </div>
                <div class="ml-3">
                    <p class="text-sm font-medium text-gray-900">Salary Advance</p>
                    <p class="text-xs text-gray-500">Request advance</p>
                </div>
            </div>
        </a>

        <a href="/employee/payslips" class="bg-white p-6 rounded-lg shadow-sm border border-gray-200 hover:border-primary-300 hover:shadow-md transition-all duration-200 group">
            <div class="flex items-center">
                <div class="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center group-hover:bg-purple-200 transition-colors">
                    <i class="fas fa-file-invoice-dollar text-purple-600"></i>
                </div>
                <div class="ml-3">
                    <p class="text-sm font-medium text-gray-900">View Payslips</p>
                    <p class="text-xs text-gray-500">Download payslips</p>
                </div>
            </div>
        </a>
    </div>
</div>

<!-- Recent Activity & Upcoming Events -->
<div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
    <!-- Recent Activity -->
    <div class="bg-white shadow-sm rounded-lg card-shadow">
        <div class="px-6 py-4 border-b border-gray-200">
            <h3 class="text-lg font-medium text-gray-900">Recent Activity</h3>
        </div>
        <div class="p-6">
            <div class="space-y-4">
                <?php if (!empty($recent_activities)): ?>
                    <?php foreach ($recent_activities as $activity): ?>
                        <div class="flex items-start space-x-3">
                            <div class="flex-shrink-0">
                                <div class="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center">
                                    <i class="fas <?= $activity['icon'] ?? 'fa-circle' ?> text-gray-600 text-sm"></i>
                                </div>
                            </div>
                            <div class="flex-1 min-w-0">
                                <p class="text-sm text-gray-900"><?= htmlspecialchars($activity['description']) ?></p>
                                <p class="text-xs text-gray-500"><?= $activity['time'] ?></p>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="text-center py-8">
                        <i class="fas fa-history text-gray-300 text-3xl mb-3"></i>
                        <p class="text-gray-500">No recent activity</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Upcoming Events -->
    <div class="bg-white shadow-sm rounded-lg card-shadow">
        <div class="px-6 py-4 border-b border-gray-200">
            <h3 class="text-lg font-medium text-gray-900">Upcoming Events</h3>
        </div>
        <div class="p-6">
            <div class="space-y-4">
                <?php if (!empty($upcoming_events)): ?>
                    <?php foreach ($upcoming_events as $event): ?>
                        <div class="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
                            <div class="flex-shrink-0">
                                <div class="w-8 h-8 bg-primary-100 rounded-full flex items-center justify-center">
                                    <i class="fas fa-calendar text-primary-600 text-sm"></i>
                                </div>
                            </div>
                            <div class="flex-1 min-w-0">
                                <p class="text-sm font-medium text-gray-900"><?= htmlspecialchars($event['title']) ?></p>
                                <p class="text-xs text-gray-500"><?= $event['date'] ?></p>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="text-center py-8">
                        <i class="fas fa-calendar-alt text-gray-300 text-3xl mb-3"></i>
                        <p class="text-gray-500">No upcoming events</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php
$content = ob_get_clean();
$title = $pageTitle;
include __DIR__ . '/../layout.php';
?>
