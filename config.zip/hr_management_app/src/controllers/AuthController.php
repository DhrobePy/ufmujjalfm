<?php

namespace App\Controllers;

use App\Models\User;

class AuthController extends BaseController
{
    private $userModel;

    public function __construct()
    {
        $this->userModel = new User();
    }

    public function showLogin()
    {
        if ($this->isAuthenticated()) {
            $this->redirect('/dashboard');
        }
        
        $this->renderView('auth/login');
    }

    public function login()
    {
        $data = $this->getRequestData();
        
        $errors = $this->validateRequired($data, ['email', 'password']);
        
        if (!empty($errors)) {
            $this->setFlashMessage('error', 'Please fill in all required fields');
            $this->redirect('/login');
        }
        
        $email = $this->sanitizeInput($data['email']);
        $password = $data['password'];
        
        if (!$this->validateEmail($email)) {
            $this->setFlashMessage('error', 'Please enter a valid email address');
            $this->redirect('/login');
        }
        
        $user = $this->userModel->authenticate($email, $password);
        
        if ($user) {
            $this->createSession($user);
            $this->redirect('/dashboard');
        } else {
            $this->setFlashMessage('error', 'Invalid email or password');
            $this->redirect('/login');
        }
    }

    public function logout()
    {
        $this->destroySession();
        $this->redirect('/login');
    }

    private function createSession($user)
    {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_email'] = $user['email'];
        $_SESSION['user_role'] = $user['role'];
        $_SESSION['user'] = $user;
        
        // Get employee details if user is an employee
        if ($user['role'] === 'employee') {
            $userWithEmployee = $this->userModel->getUserWithEmployee($user['id']);
            if ($userWithEmployee) {
                $_SESSION['employee_id'] = $userWithEmployee['employee_id'];
                $_SESSION['employee_name'] = $userWithEmployee['first_name'] . ' ' . $userWithEmployee['last_name'];
                $_SESSION['user'] = $userWithEmployee;
            }
        }
        
        // Regenerate session ID for security
        session_regenerate_id(true);
    }

    private function destroySession()
    {
        session_unset();
        session_destroy();
        session_start();
    }
}
