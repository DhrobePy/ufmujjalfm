<?php

namespace App\Controllers\Api;

use App\Controllers\BaseController;

class CommonController extends BaseController
{
    public function getDepartments()
    {
        $this->requireAuth();
        
        $departments = $this->db->fetchAll("SELECT * FROM departments ORDER BY name");
        $this->successResponse($departments);
    }

    public function getDesignations()
    {
        $this->requireAuth();
        
        $departmentId = $_GET['department_id'] ?? null;
        
        $sql = "SELECT * FROM designations";
        $params = [];
        
        if ($departmentId) {
            $sql .= " WHERE department_id = :department_id";
            $params['department_id'] = $departmentId;
        }
        
        $sql .= " ORDER BY name";
        
        $designations = $this->db->fetchAll($sql, $params);
        $this->successResponse($designations);
    }

    public function getBranches()
    {
        $this->requireAuth();
        
        $branches = $this->db->fetchAll("SELECT * FROM branches ORDER BY name");
        $this->successResponse($branches);
    }

    public function getLeaveTypes()
    {
        $this->requireAuth();
        
        $leaveTypes = $this->db->fetchAll("SELECT * FROM leave_types ORDER BY name");
        $this->successResponse($leaveTypes);
    }

    public function getSalaryComponents()
    {
        $this->requireRole(['accounts', 'admin']);
        
        $type = $_GET['type'] ?? null;
        
        $sql = "SELECT * FROM salary_components";
        $params = [];
        
        if ($type && in_array($type, ['allowance', 'deduction'])) {
            $sql .= " WHERE type = :type";
            $params['type'] = $type;
        }
        
        $sql .= " ORDER BY type, name";
        
        $components = $this->db->fetchAll($sql, $params);
        $this->successResponse($components);
    }

    public function getSystemStats()
    {
        $this->requireAuth();
        
        $stats = [
            'total_employees' => $this->db->fetch("SELECT COUNT(*) as count FROM employees WHERE is_active = 1")['count'],
            'total_departments' => $this->db->fetch("SELECT COUNT(*) as count FROM departments")['count'],
            'total_designations' => $this->db->fetch("SELECT COUNT(*) as count FROM designations")['count'],
            'total_branches' => $this->db->fetch("SELECT COUNT(*) as count FROM branches")['count'],
            'total_leave_types' => $this->db->fetch("SELECT COUNT(*) as count FROM leave_types")['count']
        ];
        
        $this->successResponse($stats);
    }

    public function getMonths()
    {
        $this->requireAuth();
        
        $months = [
            ['value' => 1, 'name' => 'January'],
            ['value' => 2, 'name' => 'February'],
            ['value' => 3, 'name' => 'March'],
            ['value' => 4, 'name' => 'April'],
            ['value' => 5, 'name' => 'May'],
            ['value' => 6, 'name' => 'June'],
            ['value' => 7, 'name' => 'July'],
            ['value' => 8, 'name' => 'August'],
            ['value' => 9, 'name' => 'September'],
            ['value' => 10, 'name' => 'October'],
            ['value' => 11, 'name' => 'November'],
            ['value' => 12, 'name' => 'December']
        ];
        
        $this->successResponse($months);
    }

    public function getYears()
    {
        $this->requireAuth();
        
        $currentYear = date('Y');
        $years = [];
        
        // Generate years from 5 years ago to 2 years in the future
        for ($year = $currentYear - 5; $year <= $currentYear + 2; $year++) {
            $years[] = ['value' => $year, 'name' => (string)$year];
        }
        
        $this->successResponse($years);
    }

    public function getEmployeeOptions()
    {
        $this->requireRole(['accounts', 'admin']);
        
        $sql = "
            SELECT e.id, e.employee_id as emp_code, 
                   CONCAT(e.first_name, ' ', e.last_name) as full_name,
                   d.name as department_name
            FROM employees e
            LEFT JOIN departments d ON e.department_id = d.id
            WHERE e.is_active = 1
            ORDER BY e.first_name, e.last_name
        ";
        
        $employees = $this->db->fetchAll($sql);
        $this->successResponse($employees);
    }

    public function searchEmployees()
    {
        $this->requireAuth();
        
        $query = $_GET['q'] ?? '';
        $limit = $_GET['limit'] ?? 10;
        
        if (strlen($query) < 2) {
            $this->successResponse([]);
        }
        
        $sql = "
            SELECT e.id, e.employee_id as emp_code, 
                   CONCAT(e.first_name, ' ', e.last_name) as full_name,
                   d.name as department_name,
                   des.name as designation_name
            FROM employees e
            LEFT JOIN departments d ON e.department_id = d.id
            LEFT JOIN designations des ON e.designation_id = des.id
            WHERE e.is_active = 1
            AND (
                e.first_name LIKE :query OR 
                e.last_name LIKE :query OR 
                e.employee_id LIKE :query OR
                CONCAT(e.first_name, ' ', e.last_name) LIKE :query
            )
            ORDER BY e.first_name, e.last_name
            LIMIT :limit
        ";
        
        $employees = $this->db->fetchAll($sql, [
            'query' => '%' . $query . '%',
            'limit' => (int)$limit
        ]);
        
        $this->successResponse($employees);
    }

    public function getTransactionCategories()
    {
        $this->requireRole(['accounts', 'admin']);
        
        $categories = $this->db->fetchAll(
            "SELECT DISTINCT category FROM transactions WHERE category IS NOT NULL ORDER BY category"
        );
        
        $categoryList = array_column($categories, 'category');
        
        // Add some default categories if not present
        $defaultCategories = [
            'Office Supplies', 'Travel & Transportation', 'Utilities', 
            'Equipment', 'Training & Development', 'Marketing', 
            'Maintenance', 'Insurance', 'Legal & Professional'
        ];
        
        foreach ($defaultCategories as $category) {
            if (!in_array($category, $categoryList)) {
                $categoryList[] = $category;
            }
        }
        
        sort($categoryList);
        $this->successResponse($categoryList);
    }

    public function getAttendanceStatuses()
    {
        $this->requireAuth();
        
        $statuses = [
            ['value' => 'Present', 'name' => 'Present'],
            ['value' => 'Absent', 'name' => 'Absent'],
            ['value' => 'Leave', 'name' => 'Leave'],
            ['value' => 'Half Day', 'name' => 'Half Day']
        ];
        
        $this->successResponse($statuses);
    }

    public function getApplicationStatuses()
    {
        $this->requireAuth();
        
        $statuses = [
            ['value' => 'Pending', 'name' => 'Pending'],
            ['value' => 'Approved', 'name' => 'Approved'],
            ['value' => 'Rejected', 'name' => 'Rejected']
        ];
        
        $this->successResponse($statuses);
    }

    public function getPayrollStatuses()
    {
        $this->requireRole(['accounts', 'admin']);
        
        $statuses = [
            ['value' => 'Draft', 'name' => 'Draft'],
            ['value' => 'Pending', 'name' => 'Pending'],
            ['value' => 'Approved', 'name' => 'Approved'],
            ['value' => 'Disbursed', 'name' => 'Disbursed']
        ];
        
        $this->successResponse($statuses);
    }

    public function getTransactionTypes()
    {
        $this->requireRole(['accounts', 'admin']);
        
        $types = [
            ['value' => 'Expense', 'name' => 'Expense'],
            ['value' => 'Salary', 'name' => 'Salary'],
            ['value' => 'Advance', 'name' => 'Advance'],
            ['value' => 'Loan', 'name' => 'Loan']
        ];
        
        $this->successResponse($types);
    }

    public function getGenderOptions()
    {
        $this->requireAuth();
        
        $genders = [
            ['value' => 'Male', 'name' => 'Male'],
            ['value' => 'Female', 'name' => 'Female'],
            ['value' => 'Other', 'name' => 'Other']
        ];
        
        $this->successResponse($genders);
    }

    public function getUserRoles()
    {
        $this->requireRole('admin');
        
        $roles = [
            ['value' => 'employee', 'name' => 'Employee'],
            ['value' => 'accounts', 'name' => 'Accounts'],
            ['value' => 'admin', 'name' => 'Admin']
        ];
        
        $this->successResponse($roles);
    }
}
