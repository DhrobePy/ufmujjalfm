<?php

namespace App\Controllers\Api;

use App\Controllers\BaseController;
use App\Models\Employee;
use App\Models\Attendance;
use App\Models\Leave;
use App\Models\SalaryAdvance;
use App\Models\Loan;

class EmployeeController extends BaseController
{
    private $employeeModel;
    private $attendanceModel;
    private $leaveModel;
    private $salaryAdvanceModel;
    private $loanModel;

    public function __construct()
    {
        $this->employeeModel = new Employee();
        $this->attendanceModel = new Attendance();
        $this->leaveModel = new Leave();
        $this->salaryAdvanceModel = new SalaryAdvance();
        $this->loanModel = new Loan();
    }

    public function getProfile()
    {
        $this->requireRole('employee');
        
        $userId = $this->getCurrentUserId();
        $employee = $this->employeeModel->getEmployeeByUserId($userId);
        
        if (!$employee) {
            $this->errorResponse('Employee profile not found', 404);
        }
        
        $employeeDetails = $this->employeeModel->getEmployeeWithDetails($employee['id']);
        $this->successResponse($employeeDetails);
    }

    public function updateProfile()
    {
        $this->requireRole('employee');
        
        $data = $this->getRequestData();
        $userId = $this->getCurrentUserId();
        $employee = $this->employeeModel->getEmployeeByUserId($userId);
        
        if (!$employee) {
            $this->errorResponse('Employee profile not found', 404);
        }
        
        // Handle file upload for profile picture
        if (isset($_FILES['profile_picture'])) {
            $uploadResult = $this->uploadFile($_FILES['profile_picture'], 'uploads/profiles/', ['jpg', 'jpeg', 'png']);
            if ($uploadResult['success']) {
                $data['profile_picture'] = $uploadResult['file_path'];
            }
        }
        
        $result = $this->employeeModel->updateProfile($employee['id'], $data);
        
        if ($result) {
            $updatedEmployee = $this->employeeModel->getEmployeeWithDetails($employee['id']);
            $this->successResponse($updatedEmployee, 'Profile updated successfully');
        } else {
            $this->errorResponse('Failed to update profile', 500);
        }
    }

    public function markAttendance()
    {
        $this->requireRole('employee');
        
        $data = $this->getRequestData();
        $userId = $this->getCurrentUserId();
        $employee = $this->employeeModel->getEmployeeByUserId($userId);
        
        if (!$employee) {
            $this->errorResponse('Employee profile not found', 404);
        }
        
        $errors = $this->validateRequired($data, ['status']);
        if (!empty($errors)) {
            $this->errorResponse('Validation failed', 422, $errors);
        }
        
        $date = $data['date'] ?? date('Y-m-d');
        $status = $data['status'];
        $checkIn = $data['check_in'] ?? null;
        $checkOut = $data['check_out'] ?? null;
        $notes = $data['notes'] ?? null;
        
        // Validate status
        $validStatuses = ['Present', 'Absent', 'Leave', 'Half Day'];
        if (!in_array($status, $validStatuses)) {
            $this->errorResponse('Invalid attendance status', 422);
        }
        
        $result = $this->attendanceModel->markAttendance(
            $employee['id'], 
            $date, 
            $status, 
            $checkIn, 
            $checkOut, 
            $notes
        );
        
        if ($result) {
            $this->successResponse($result, 'Attendance marked successfully');
        } else {
            $this->errorResponse('Failed to mark attendance', 500);
        }
    }

    public function getAttendance()
    {
        $this->requireRole('employee');
        
        $userId = $this->getCurrentUserId();
        $employee = $this->employeeModel->getEmployeeByUserId($userId);
        
        if (!$employee) {
            $this->errorResponse('Employee profile not found', 404);
        }
        
        $month = $_GET['month'] ?? date('n');
        $year = $_GET['year'] ?? date('Y');
        
        $attendance = $this->attendanceModel->getEmployeeAttendance($employee['id'], $month, $year);
        $summary = $this->attendanceModel->getAttendanceSummary($employee['id'], $month, $year);
        $workingDays = $this->attendanceModel->getWorkingDaysInMonth($month, $year);
        
        $this->successResponse([
            'attendance' => $attendance,
            'summary' => $summary,
            'working_days' => $workingDays,
            'month' => (int)$month,
            'year' => (int)$year
        ]);
    }

    public function applyLeave()
    {
        $this->requireRole('employee');
        
        $data = $this->getRequestData();
        $userId = $this->getCurrentUserId();
        $employee = $this->employeeModel->getEmployeeByUserId($userId);
        
        if (!$employee) {
            $this->errorResponse('Employee profile not found', 404);
        }
        
        $errors = $this->validateRequired($data, ['leave_type_id', 'start_date', 'end_date', 'reason']);
        if (!empty($errors)) {
            $this->errorResponse('Validation failed', 422, $errors);
        }
        
        // Validate dates
        if (!$this->validateDate($data['start_date']) || !$this->validateDate($data['end_date'])) {
            $this->errorResponse('Invalid date format', 422);
        }
        
        if ($data['start_date'] > $data['end_date']) {
            $this->errorResponse('Start date cannot be after end date', 422);
        }
        
        // Check for overlapping leaves
        if ($this->leaveModel->hasOverlappingLeave($employee['id'], $data['start_date'], $data['end_date'])) {
            $this->errorResponse('You have overlapping leave applications for the selected dates', 422);
        }
        
        // Check leave balance
        $balance = $this->leaveModel->getLeaveBalance($employee['id'], $data['leave_type_id']);
        $startDate = new \DateTime($data['start_date']);
        $endDate = new \DateTime($data['end_date']);
        $requestedDays = $startDate->diff($endDate)->days + 1;
        
        if ($requestedDays > $balance) {
            $this->errorResponse('Insufficient leave balance', 422);
        }
        
        $data['employee_id'] = $employee['id'];
        $result = $this->leaveModel->applyLeave($data);
        
        if ($result) {
            $this->successResponse($result, 'Leave application submitted successfully');
        } else {
            $this->errorResponse('Failed to submit leave application', 500);
        }
    }

    public function getLeaves()
    {
        $this->requireRole('employee');
        
        $userId = $this->getCurrentUserId();
        $employee = $this->employeeModel->getEmployeeByUserId($userId);
        
        if (!$employee) {
            $this->errorResponse('Employee profile not found', 404);
        }
        
        $year = $_GET['year'] ?? date('Y');
        $leaves = $this->leaveModel->getEmployeeLeaves($employee['id'], $year);
        
        // Get leave types and balances
        $leaveTypes = $this->db->fetchAll("SELECT * FROM leave_types ORDER BY name");
        $leaveBalances = [];
        
        foreach ($leaveTypes as $leaveType) {
            $leaveBalances[$leaveType['id']] = $this->leaveModel->getLeaveBalance(
                $employee['id'], 
                $leaveType['id'], 
                $year
            );
        }
        
        $this->successResponse([
            'leaves' => $leaves,
            'leave_types' => $leaveTypes,
            'leave_balances' => $leaveBalances,
            'year' => (int)$year
        ]);
    }

    public function applySalaryAdvance()
    {
        $this->requireRole('employee');
        
        $data = $this->getRequestData();
        $userId = $this->getCurrentUserId();
        $employee = $this->employeeModel->getEmployeeByUserId($userId);
        
        if (!$employee) {
            $this->errorResponse('Employee profile not found', 404);
        }
        
        $errors = $this->validateRequired($data, ['amount', 'reason']);
        if (!empty($errors)) {
            $this->errorResponse('Validation failed', 422, $errors);
        }
        
        $amount = (float)$data['amount'];
        
        if ($amount <= 0) {
            $this->errorResponse('Amount must be greater than zero', 422);
        }
        
        // Check if employee can apply for advance
        $canApply = $this->salaryAdvanceModel->canApplyForAdvance($employee['id'], $amount);
        if (!$canApply['can_apply']) {
            $this->errorResponse($canApply['reason'], 422);
        }
        
        $data['employee_id'] = $employee['id'];
        $result = $this->salaryAdvanceModel->applySalaryAdvance($data);
        
        if ($result) {
            $this->successResponse($result, 'Salary advance application submitted successfully');
        } else {
            $this->errorResponse('Failed to submit salary advance application', 500);
        }
    }

    public function getSalaryAdvances()
    {
        $this->requireRole('employee');
        
        $userId = $this->getCurrentUserId();
        $employee = $this->employeeModel->getEmployeeByUserId($userId);
        
        if (!$employee) {
            $this->errorResponse('Employee profile not found', 404);
        }
        
        $year = $_GET['year'] ?? date('Y');
        $advances = $this->salaryAdvanceModel->getEmployeeSalaryAdvances($employee['id'], $year);
        $statistics = $this->salaryAdvanceModel->getTotalAdvanceByEmployee($employee['id'], $year);
        
        $this->successResponse([
            'advances' => $advances,
            'statistics' => $statistics,
            'year' => (int)$year
        ]);
    }

    public function applyLoan()
    {
        $this->requireRole('employee');
        
        $data = $this->getRequestData();
        $userId = $this->getCurrentUserId();
        $employee = $this->employeeModel->getEmployeeByUserId($userId);
        
        if (!$employee) {
            $this->errorResponse('Employee profile not found', 404);
        }
        
        $errors = $this->validateRequired($data, ['amount', 'reason', 'payment_type']);
        if (!empty($errors)) {
            $this->errorResponse('Validation failed', 422, $errors);
        }
        
        $amount = (float)$data['amount'];
        
        if ($amount <= 0) {
            $this->errorResponse('Amount must be greater than zero', 422);
        }
        
        // Validate payment type
        if (!in_array($data['payment_type'], ['emi', 'random'])) {
            $this->errorResponse('Invalid payment type', 422);
        }
        
        // If EMI, validate tenure
        if ($data['payment_type'] === 'emi') {
            if (!isset($data['tenure_months']) || $data['tenure_months'] <= 0) {
                $this->errorResponse('Tenure in months is required for EMI loans', 422);
            }
        }
        
        // Check if employee can apply for loan
        $canApply = $this->loanModel->canApplyForLoan($employee['id'], $amount);
        if (!$canApply['can_apply']) {
            $this->errorResponse($canApply['reason'], 422);
        }
        
        $data['employee_id'] = $employee['id'];
        $result = $this->loanModel->applyLoan($data);
        
        if ($result) {
            $this->successResponse($result, 'Loan application submitted successfully');
        } else {
            $this->errorResponse('Failed to submit loan application', 500);
        }
    }

    public function getLoans()
    {
        $this->requireRole('employee');
        
        $userId = $this->getCurrentUserId();
        $employee = $this->employeeModel->getEmployeeByUserId($userId);
        
        if (!$employee) {
            $this->errorResponse('Employee profile not found', 404);
        }
        
        $year = $_GET['year'] ?? date('Y');
        $loans = $this->loanModel->getEmployeeLoans($employee['id'], $year);
        $activeLoans = $this->loanModel->getActiveLoansForEmployee($employee['id']);
        
        // Get loan details with payments
        foreach ($loans as &$loan) {
            $loanDetails = $this->loanModel->getLoanWithPayments($loan['id']);
            $loan['total_paid'] = $loanDetails['total_paid'] ?? 0;
            $loan['remaining_amount'] = $loanDetails['remaining_amount'] ?? $loan['amount'];
        }
        
        $this->successResponse([
            'loans' => $loans,
            'active_loans' => $activeLoans,
            'year' => (int)$year
        ]);
    }

    public function generateCertificate($type)
    {
        $this->requireRole('employee');
        
        $userId = $this->getCurrentUserId();
        $employee = $this->employeeModel->getEmployeeByUserId($userId);
        
        if (!$employee) {
            $this->errorResponse('Employee profile not found', 404);
        }
        
        $validTypes = ['employment', 'salary', 'experience'];
        if (!in_array(strtolower($type), $validTypes)) {
            $this->errorResponse('Invalid certificate type', 422);
        }
        
        $employeeDetails = $this->employeeModel->getEmployeeWithDetails($employee['id']);
        
        // Generate certificate content based on type
        $certificateContent = $this->generateCertificateContent($type, $employeeDetails);
        
        // Save certificate to database
        $certificateData = [
            'employee_id' => $employee['id'],
            'type' => ucfirst($type),
            'content' => $certificateContent
        ];
        
        $certificateId = $this->db->insert('certificates', $certificateData);
        
        $this->successResponse([
            'certificate_id' => $certificateId,
            'content' => $certificateContent,
            'type' => $type
        ], 'Certificate generated successfully');
    }

    public function getPayslip($month, $year)
    {
        $this->requireRole('employee');
        
        $userId = $this->getCurrentUserId();
        $employee = $this->employeeModel->getEmployeeByUserId($userId);
        
        if (!$employee) {
            $this->errorResponse('Employee profile not found', 404);
        }
        
        $sql = "
            SELECT p.*, pi.*, e.first_name, e.last_name, e.employee_id as emp_code,
                   d.name as department_name, des.name as designation_name
            FROM payrolls p
            JOIN payroll_items pi ON p.id = pi.payroll_id
            JOIN employees e ON pi.employee_id = e.id
            LEFT JOIN departments d ON e.department_id = d.id
            LEFT JOIN designations des ON e.designation_id = des.id
            WHERE pi.employee_id = :employee_id AND p.month = :month AND p.year = :year
        ";
        
        $payslip = $this->db->fetch($sql, [
            'employee_id' => $employee['id'],
            'month' => $month,
            'year' => $year
        ]);
        
        if (!$payslip) {
            $this->errorResponse('Payslip not found', 404);
        }
        
        $this->successResponse($payslip);
    }

    private function generateCertificateContent($type, $employee)
    {
        $companyName = "HR Management Company";
        $currentDate = date('F j, Y');
        
        switch (strtolower($type)) {
            case 'employment':
                return "TO WHOM IT MAY CONCERN\n\n" .
                       "This is to certify that {$employee['first_name']} {$employee['last_name']} " .
                       "(Employee ID: {$employee['employee_id']}) is employed with {$companyName} " .
                       "as {$employee['designation_name']} in the {$employee['department_name']} department " .
                       "since {$employee['date_of_joining']}.\n\n" .
                       "This certificate is issued upon the request of the employee.\n\n" .
                       "Date: {$currentDate}";
                       
            case 'salary':
                return "TO WHOM IT MAY CONCERN\n\n" .
                       "This is to certify that {$employee['first_name']} {$employee['last_name']} " .
                       "(Employee ID: {$employee['employee_id']}) is employed with {$companyName} " .
                       "as {$employee['designation_name']}.\n\n" .
                       "This certificate is issued for salary verification purposes.\n\n" .
                       "Date: {$currentDate}";
                       
            case 'experience':
                return "TO WHOM IT MAY CONCERN\n\n" .
                       "This is to certify that {$employee['first_name']} {$employee['last_name']} " .
                       "(Employee ID: {$employee['employee_id']}) has been working with {$companyName} " .
                       "as {$employee['designation_name']} in the {$employee['department_name']} department " .
                       "since {$employee['date_of_joining']}.\n\n" .
                       "During the tenure, the employee has shown dedication and professionalism.\n\n" .
                       "Date: {$currentDate}";
                       
            default:
                return "Certificate content not available.";
        }
    }
}
