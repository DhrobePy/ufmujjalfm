<?php

namespace App\Controllers\Api;

use App\Controllers\BaseController;
use App\Models\Employee;
use App\Models\Report;

class DocumentController extends BaseController
{
    private $employeeModel;
    private $reportModel;

    public function __construct()
    {
        $this->employeeModel = new Employee();
        $this->reportModel = new Report();
    }

    public function generateEmploymentCertificate()
    {
        $this->requireAuth();
        
        $employeeId = $_GET['employee_id'] ?? null;
        $format = $_GET['format'] ?? 'pdf';
        
        // Check permissions
        $userRole = $this->getCurrentUserRole();
        if ($userRole === 'employee') {
            // Employees can only generate their own certificates
            $userId = $this->getCurrentUserId();
            $employee = $this->employeeModel->getEmployeeByUserId($userId);
            if (!$employee) {
                $this->errorResponse('Employee profile not found', 404);
            }
            $employeeId = $employee['id'];
        } elseif (!in_array($userRole, ['accounts', 'admin'])) {
            $this->errorResponse('Insufficient permissions', 403);
        }
        
        if (!$employeeId) {
            $this->errorResponse('Employee ID is required', 422);
        }
        
        try {
            $employee = $this->employeeModel->getEmployeeWithDetails($employeeId);
            
            if (!$employee) {
                $this->errorResponse('Employee not found', 404);
            }
            
            $certificateData = [
                'employee' => $employee,
                'company_name' => 'HR Management Company',
                'company_address' => '123 Business Street, City, State 12345',
                'document_title' => 'Employment Certificate',
                'generated_at' => date('Y-m-d H:i:s'),
                'certificate_number' => 'EMP-CERT-' . $employee['employee_id'] . '-' . date('Ymd')
            ];
            
            if ($format === 'pdf') {
                $pdf = $this->generateEmploymentCertificatePDF($certificateData);
                
                header('Content-Type: application/pdf');
                header('Content-Disposition: attachment; filename="employment_certificate_' . $employee['employee_id'] . '.pdf"');
                echo $pdf;
                exit();
            } else {
                $this->successResponse($certificateData);
            }
            
        } catch (\Exception $e) {
            $this->errorResponse('Failed to generate employment certificate: ' . $e->getMessage(), 500);
        }
    }

    public function generateSalaryCertificate()
    {
        $this->requireAuth();
        
        $employeeId = $_GET['employee_id'] ?? null;
        $format = $_GET['format'] ?? 'pdf';
        
        // Check permissions
        $userRole = $this->getCurrentUserRole();
        if ($userRole === 'employee') {
            // Employees can only generate their own certificates
            $userId = $this->getCurrentUserId();
            $employee = $this->employeeModel->getEmployeeByUserId($userId);
            if (!$employee) {
                $this->errorResponse('Employee profile not found', 404);
            }
            $employeeId = $employee['id'];
        } elseif (!in_array($userRole, ['accounts', 'admin'])) {
            $this->errorResponse('Insufficient permissions', 403);
        }
        
        if (!$employeeId) {
            $this->errorResponse('Employee ID is required', 422);
        }
        
        try {
            $employee = $this->employeeModel->getEmployeeWithDetails($employeeId);
            
            if (!$employee) {
                $this->errorResponse('Employee not found', 404);
            }
            
            // Get salary structure
            $salaryStructureModel = new \App\Models\SalaryStructure();
            $salaryStructure = $salaryStructureModel->getEmployeeSalaryStructure($employeeId);
            
            if (!$salaryStructure) {
                $this->errorResponse('Salary structure not found for this employee', 404);
            }
            
            $certificateData = [
                'employee' => $employee,
                'salary_structure' => $salaryStructure,
                'company_name' => 'HR Management Company',
                'company_address' => '123 Business Street, City, State 12345',
                'document_title' => 'Salary Certificate',
                'generated_at' => date('Y-m-d H:i:s'),
                'certificate_number' => 'SAL-CERT-' . $employee['employee_id'] . '-' . date('Ymd')
            ];
            
            if ($format === 'pdf') {
                $pdf = $this->generateSalaryCertificatePDF($certificateData);
                
                header('Content-Type: application/pdf');
                header('Content-Disposition: attachment; filename="salary_certificate_' . $employee['employee_id'] . '.pdf"');
                echo $pdf;
                exit();
            } else {
                $this->successResponse($certificateData);
            }
            
        } catch (\Exception $e) {
            $this->errorResponse('Failed to generate salary certificate: ' . $e->getMessage(), 500);
        }
    }

    public function generateExperienceLetter()
    {
        $this->requireRole(['accounts', 'admin']);
        
        $employeeId = $_GET['employee_id'] ?? null;
        $format = $_GET['format'] ?? 'pdf';
        $lastWorkingDay = $_GET['last_working_day'] ?? date('Y-m-d');
        
        if (!$employeeId) {
            $this->errorResponse('Employee ID is required', 422);
        }
        
        if (!$this->validateDate($lastWorkingDay)) {
            $this->errorResponse('Invalid last working day format', 422);
        }
        
        try {
            $employee = $this->employeeModel->getEmployeeWithDetails($employeeId);
            
            if (!$employee) {
                $this->errorResponse('Employee not found', 404);
            }
            
            // Calculate experience
            $joiningDate = new \DateTime($employee['date_of_joining']);
            $lastDay = new \DateTime($lastWorkingDay);
            $experience = $joiningDate->diff($lastDay);
            
            $letterData = [
                'employee' => $employee,
                'last_working_day' => $lastWorkingDay,
                'experience' => $experience,
                'company_name' => 'HR Management Company',
                'company_address' => '123 Business Street, City, State 12345',
                'document_title' => 'Experience Letter',
                'generated_at' => date('Y-m-d H:i:s'),
                'letter_number' => 'EXP-LTR-' . $employee['employee_id'] . '-' . date('Ymd')
            ];
            
            if ($format === 'pdf') {
                $pdf = $this->generateExperienceLetterPDF($letterData);
                
                header('Content-Type: application/pdf');
                header('Content-Disposition: attachment; filename="experience_letter_' . $employee['employee_id'] . '.pdf"');
                echo $pdf;
                exit();
            } else {
                $this->successResponse($letterData);
            }
            
        } catch (\Exception $e) {
            $this->errorResponse('Failed to generate experience letter: ' . $e->getMessage(), 500);
        }
    }

    private function generateEmploymentCertificatePDF($data)
    {
        $employee = $data['employee'];
        
        $html = '<!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <title>Employment Certificate</title>
            <style>
                body { font-family: Arial, sans-serif; margin: 40px; line-height: 1.6; }
                .letterhead { text-align: center; margin-bottom: 40px; border-bottom: 2px solid #333; padding-bottom: 20px; }
                .company-name { font-size: 24px; font-weight: bold; color: #333; }
                .company-address { font-size: 12px; color: #666; margin-top: 10px; }
                .document-title { font-size: 18px; font-weight: bold; text-align: center; margin: 30px 0; text-decoration: underline; }
                .certificate-number { text-align: right; margin-bottom: 20px; font-size: 12px; }
                .content { text-align: justify; margin-bottom: 30px; }
                .employee-details { margin: 20px 0; }
                .signature-section { margin-top: 60px; }
                .signature-line { border-top: 1px solid #333; width: 200px; margin-top: 60px; }
                .date { text-align: right; margin-top: 30px; }
            </style>
        </head>
        <body>';
        
        // Letterhead
        $html .= '<div class="letterhead">
            <div class="company-name">' . htmlspecialchars($data['company_name']) . '</div>
            <div class="company-address">' . htmlspecialchars($data['company_address']) . '</div>
        </div>';
        
        // Certificate Number
        $html .= '<div class="certificate-number">
            Certificate No: ' . htmlspecialchars($data['certificate_number']) . '
        </div>';
        
        // Title
        $html .= '<div class="document-title">TO WHOM IT MAY CONCERN</div>';
        
        // Content
        $html .= '<div class="content">
            <p>This is to certify that <strong>' . htmlspecialchars($employee['first_name'] . ' ' . $employee['last_name']) . '</strong> 
            (Employee ID: <strong>' . htmlspecialchars($employee['employee_id']) . '</strong>) is currently employed with our organization.</p>
            
            <div class="employee-details">
                <p><strong>Employee Details:</strong></p>
                <ul>
                    <li><strong>Full Name:</strong> ' . htmlspecialchars($employee['first_name'] . ' ' . $employee['last_name']) . '</li>
                    <li><strong>Employee ID:</strong> ' . htmlspecialchars($employee['employee_id']) . '</li>
                    <li><strong>Department:</strong> ' . htmlspecialchars($employee['department_name']) . '</li>
                    <li><strong>Designation:</strong> ' . htmlspecialchars($employee['designation_name']) . '</li>
                    <li><strong>Date of Joining:</strong> ' . date('F d, Y', strtotime($employee['date_of_joining'])) . '</li>
                    <li><strong>Employment Status:</strong> Active</li>
                </ul>
            </div>
            
            <p>During the tenure of employment, the employee has shown dedication, professionalism, and commitment to their responsibilities.</p>
            
            <p>This certificate is issued upon the request of the employee for official purposes.</p>
        </div>';
        
        // Date
        $html .= '<div class="date">
            Date: ' . date('F d, Y') . '
        </div>';
        
        // Signature
        $html .= '<div class="signature-section">
            <div class="signature-line"></div>
            <p><strong>HR Manager</strong><br>
            ' . htmlspecialchars($data['company_name']) . '</p>
        </div>';
        
        $html .= '</body></html>';
        
        return $this->reportModel->exportToPDF(['html' => $html], 'certificate');
    }

    private function generateSalaryCertificatePDF($data)
    {
        $employee = $data['employee'];
        $salary = $data['salary_structure'];
        
        $html = '<!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <title>Salary Certificate</title>
            <style>
                body { font-family: Arial, sans-serif; margin: 40px; line-height: 1.6; }
                .letterhead { text-align: center; margin-bottom: 40px; border-bottom: 2px solid #333; padding-bottom: 20px; }
                .company-name { font-size: 24px; font-weight: bold; color: #333; }
                .company-address { font-size: 12px; color: #666; margin-top: 10px; }
                .document-title { font-size: 18px; font-weight: bold; text-align: center; margin: 30px 0; text-decoration: underline; }
                .certificate-number { text-align: right; margin-bottom: 20px; font-size: 12px; }
                .content { text-align: justify; margin-bottom: 30px; }
                .employee-details { margin: 20px 0; }
                .salary-table { width: 100%; border-collapse: collapse; margin: 20px 0; }
                .salary-table th, .salary-table td { border: 1px solid #333; padding: 10px; text-align: left; }
                .salary-table th { background-color: #f0f0f0; font-weight: bold; }
                .signature-section { margin-top: 60px; }
                .signature-line { border-top: 1px solid #333; width: 200px; margin-top: 60px; }
                .date { text-align: right; margin-top: 30px; }
            </style>
        </head>
        <body>';
        
        // Letterhead
        $html .= '<div class="letterhead">
            <div class="company-name">' . htmlspecialchars($data['company_name']) . '</div>
            <div class="company-address">' . htmlspecialchars($data['company_address']) . '</div>
        </div>';
        
        // Certificate Number
        $html .= '<div class="certificate-number">
            Certificate No: ' . htmlspecialchars($data['certificate_number']) . '
        </div>';
        
        // Title
        $html .= '<div class="document-title">SALARY CERTIFICATE</div>';
        
        // Content
        $html .= '<div class="content">
            <p>This is to certify that <strong>' . htmlspecialchars($employee['first_name'] . ' ' . $employee['last_name']) . '</strong> 
            (Employee ID: <strong>' . htmlspecialchars($employee['employee_id']) . '</strong>) is employed with our organization 
            with the following salary structure:</p>
            
            <div class="employee-details">
                <p><strong>Employee Information:</strong></p>
                <ul>
                    <li><strong>Full Name:</strong> ' . htmlspecialchars($employee['first_name'] . ' ' . $employee['last_name']) . '</li>
                    <li><strong>Employee ID:</strong> ' . htmlspecialchars($employee['employee_id']) . '</li>
                    <li><strong>Department:</strong> ' . htmlspecialchars($employee['department_name']) . '</li>
                    <li><strong>Designation:</strong> ' . htmlspecialchars($employee['designation_name']) . '</li>
                    <li><strong>Date of Joining:</strong> ' . date('F d, Y', strtotime($employee['date_of_joining'])) . '</li>
                </ul>
            </div>
            
            <p><strong>Salary Structure (Monthly):</strong></p>
            <table class="salary-table">
                <thead>
                    <tr>
                        <th>Component</th>
                        <th>Amount</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Basic Salary</td>
                        <td>$' . number_format($salary['basic_salary'], 2) . '</td>
                    </tr>
                    <tr>
                        <td>Gross Salary</td>
                        <td>$' . number_format($salary['gross_salary'], 2) . '</td>
                    </tr>
                    <tr style="background-color: #e6f3ff;">
                        <td><strong>Net Salary</strong></td>
                        <td><strong>$' . number_format($salary['net_salary'], 2) . '</strong></td>
                    </tr>
                </tbody>
            </table>
            
            <p>This certificate is issued upon the request of the employee for official purposes.</p>
        </div>';
        
        // Date
        $html .= '<div class="date">
            Date: ' . date('F d, Y') . '
        </div>';
        
        // Signature
        $html .= '<div class="signature-section">
            <div class="signature-line"></div>
            <p><strong>HR Manager</strong><br>
            ' . htmlspecialchars($data['company_name']) . '</p>
        </div>';
        
        $html .= '</body></html>';
        
        return $this->reportModel->exportToPDF(['html' => $html], 'certificate');
    }

    private function generateExperienceLetterPDF($data)
    {
        $employee = $data['employee'];
        $experience = $data['experience'];
        
        // Format experience
        $experienceText = '';
        if ($experience->y > 0) {
            $experienceText .= $experience->y . ' year' . ($experience->y > 1 ? 's' : '');
        }
        if ($experience->m > 0) {
            if ($experienceText) $experienceText .= ' and ';
            $experienceText .= $experience->m . ' month' . ($experience->m > 1 ? 's' : '');
        }
        if (!$experienceText) {
            $experienceText = 'Less than a month';
        }
        
        $html = '<!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <title>Experience Letter</title>
            <style>
                body { font-family: Arial, sans-serif; margin: 40px; line-height: 1.6; }
                .letterhead { text-align: center; margin-bottom: 40px; border-bottom: 2px solid #333; padding-bottom: 20px; }
                .company-name { font-size: 24px; font-weight: bold; color: #333; }
                .company-address { font-size: 12px; color: #666; margin-top: 10px; }
                .document-title { font-size: 18px; font-weight: bold; text-align: center; margin: 30px 0; text-decoration: underline; }
                .letter-number { text-align: right; margin-bottom: 20px; font-size: 12px; }
                .content { text-align: justify; margin-bottom: 30px; }
                .employee-details { margin: 20px 0; }
                .signature-section { margin-top: 60px; }
                .signature-line { border-top: 1px solid #333; width: 200px; margin-top: 60px; }
                .date { text-align: right; margin-top: 30px; }
            </style>
        </head>
        <body>';
        
        // Letterhead
        $html .= '<div class="letterhead">
            <div class="company-name">' . htmlspecialchars($data['company_name']) . '</div>
            <div class="company-address">' . htmlspecialchars($data['company_address']) . '</div>
        </div>';
        
        // Letter Number
        $html .= '<div class="letter-number">
            Letter No: ' . htmlspecialchars($data['letter_number']) . '
        </div>';
        
        // Title
        $html .= '<div class="document-title">EXPERIENCE LETTER</div>';
        
        // Content
        $html .= '<div class="content">
            <p>This is to certify that <strong>' . htmlspecialchars($employee['first_name'] . ' ' . $employee['last_name']) . '</strong> 
            (Employee ID: <strong>' . htmlspecialchars($employee['employee_id']) . '</strong>) was employed with our organization 
            from <strong>' . date('F d, Y', strtotime($employee['date_of_joining'])) . '</strong> to 
            <strong>' . date('F d, Y', strtotime($data['last_working_day'])) . '</strong>.</p>
            
            <div class="employee-details">
                <p><strong>Employment Details:</strong></p>
                <ul>
                    <li><strong>Full Name:</strong> ' . htmlspecialchars($employee['first_name'] . ' ' . $employee['last_name']) . '</li>
                    <li><strong>Employee ID:</strong> ' . htmlspecialchars($employee['employee_id']) . '</li>
                    <li><strong>Department:</strong> ' . htmlspecialchars($employee['department_name']) . '</li>
                    <li><strong>Designation:</strong> ' . htmlspecialchars($employee['designation_name']) . '</li>
                    <li><strong>Period of Employment:</strong> ' . $experienceText . '</li>
                    <li><strong>Last Working Day:</strong> ' . date('F d, Y', strtotime($data['last_working_day'])) . '</li>
                </ul>
            </div>
            
            <p>During the tenure of employment, the employee demonstrated professionalism, dedication, and commitment to their responsibilities. 
            The employee maintained good conduct and performed their duties satisfactorily.</p>
            
            <p>We wish them success in their future endeavors.</p>
            
            <p>This letter is issued upon the request of the employee for their records and future reference.</p>
        </div>';
        
        // Date
        $html .= '<div class="date">
            Date: ' . date('F d, Y') . '
        </div>';
        
        // Signature
        $html .= '<div class="signature-section">
            <div class="signature-line"></div>
            <p><strong>HR Manager</strong><br>
            ' . htmlspecialchars($data['company_name']) . '</p>
        </div>';
        
        $html .= '</body></html>';
        
        return $this->reportModel->exportToPDF(['html' => $html], 'letter');
    }
}
