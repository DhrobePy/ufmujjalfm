<?php

namespace App\Controllers\Api;

use App\Controllers\BaseController;
use App\Models\SalaryStructure;
use App\Models\Payroll;
use App\Models\Transaction;
use App\Models\Attendance;
use App\Models\Employee;

class AccountsController extends BaseController
{
    private $salaryStructureModel;
    private $payrollModel;
    private $transactionModel;
    private $attendanceModel;
    private $employeeModel;

    public function __construct()
    {
        $this->salaryStructureModel = new SalaryStructure();
        $this->payrollModel = new Payroll();
        $this->transactionModel = new Transaction();
        $this->attendanceModel = new Attendance();
        $this->employeeModel = new Employee();
    }

    public function setSalaryStructure()
    {
        $this->requireRole(['accounts', 'admin']);
        
        $data = $this->getRequestData();
        
        $errors = $this->validateRequired($data, ['employee_id', 'basic_salary']);
        if (!empty($errors)) {
            $this->errorResponse('Validation failed', 422, $errors);
        }
        
        $employeeId = $data['employee_id'];
        $basicSalary = (float)$data['basic_salary'];
        $components = $data['components'] ?? [];
        $effectiveFrom = $data['effective_from'] ?? date('Y-m-d');
        
        if ($basicSalary <= 0) {
            $this->errorResponse('Basic salary must be greater than zero', 422);
        }
        
        // Validate employee exists
        $employee = $this->employeeModel->find($employeeId);
        if (!$employee) {
            $this->errorResponse('Employee not found', 404);
        }
        
        // Calculate salary based on components
        $salaryCalculation = $this->salaryStructureModel->calculateSalary($basicSalary, $components);
        
        $structureData = [
            'employee_id' => $employeeId,
            'basic_salary' => $basicSalary,
            'gross_salary' => $salaryCalculation['gross_salary'],
            'net_salary' => $salaryCalculation['net_salary'],
            'effective_from' => $effectiveFrom
        ];
        
        $salaryStructure = $this->salaryStructureModel->createSalaryStructure($structureData);
        
        if ($salaryStructure) {
            // Add components
            foreach ($components as $component) {
                if (isset($component['component_id'], $component['amount'])) {
                    $this->salaryStructureModel->addSalaryComponent(
                        $salaryStructure['id'],
                        $component['component_id'],
                        $component['amount'],
                        $component['percentage'] ?? null
                    );
                }
            }
            
            $structureWithComponents = $this->salaryStructureModel->getSalaryStructureWithComponents($salaryStructure['id']);
            $this->successResponse($structureWithComponents, 'Salary structure created successfully');
        } else {
            $this->errorResponse('Failed to create salary structure', 500);
        }
    }

    public function getSalaryStructures()
    {
        $this->requireRole(['accounts', 'admin']);
        
        $filters = [
            'department_id' => $_GET['department_id'] ?? null,
            'designation_id' => $_GET['designation_id'] ?? null,
            'branch_id' => $_GET['branch_id'] ?? null,
            'search' => $_GET['search'] ?? null
        ];
        
        $salaryStructures = $this->salaryStructureModel->getAllSalaryStructures($filters);
        $statistics = $this->salaryStructureModel->getSalaryStatistics();
        
        $this->successResponse([
            'salary_structures' => $salaryStructures,
            'statistics' => $statistics
        ]);
    }

    public function getAttendanceReport()
    {
        $this->requireRole(['accounts', 'admin']);
        
        $filters = [
            'employee_id' => $_GET['employee_id'] ?? null,
            'department_id' => $_GET['department_id'] ?? null,
            'branch_id' => $_GET['branch_id'] ?? null,
            'date_from' => $_GET['date_from'] ?? date('Y-m-01'),
            'date_to' => $_GET['date_to'] ?? date('Y-m-t'),
            'status' => $_GET['status'] ?? null
        ];
        
        $attendanceReport = $this->attendanceModel->getAttendanceReport($filters);
        
        // Get summary statistics
        $totalRecords = count($attendanceReport);
        $presentCount = count(array_filter($attendanceReport, fn($r) => $r['status'] === 'Present'));
        $absentCount = count(array_filter($attendanceReport, fn($r) => $r['status'] === 'Absent'));
        $leaveCount = count(array_filter($attendanceReport, fn($r) => $r['status'] === 'Leave'));
        
        $summary = [
            'total_records' => $totalRecords,
            'present_count' => $presentCount,
            'absent_count' => $absentCount,
            'leave_count' => $leaveCount,
            'attendance_percentage' => $totalRecords > 0 ? round(($presentCount / $totalRecords) * 100, 2) : 0
        ];
        
        $this->successResponse([
            'attendance_report' => $attendanceReport,
            'summary' => $summary,
            'filters' => $filters
        ]);
    }

    public function generatePayroll()
    {
        $this->requireRole(['accounts', 'admin']);
        
        $data = $this->getRequestData();
        
        $errors = $this->validateRequired($data, ['month', 'year']);
        if (!empty($errors)) {
            $this->errorResponse('Validation failed', 422, $errors);
        }
        
        $month = (int)$data['month'];
        $year = (int)$data['year'];
        $employeeIds = $data['employee_ids'] ?? [];
        
        if ($month < 1 || $month > 12) {
            $this->errorResponse('Invalid month', 422);
        }
        
        if ($year < 2020 || $year > date('Y') + 1) {
            $this->errorResponse('Invalid year', 422);
        }
        
        $createdBy = $this->getCurrentUserId();
        
        try {
            $payroll = $this->payrollModel->createPayroll($month, $year, $createdBy, $employeeIds);
            
            if ($payroll) {
                $payrollWithItems = $this->payrollModel->getPayrollWithItems($payroll['id']);
                $this->successResponse($payrollWithItems, 'Payroll generated successfully');
            } else {
                $this->errorResponse('Payroll already exists for this month/year', 422);
            }
        } catch (\Exception $e) {
            $this->errorResponse('Failed to generate payroll: ' . $e->getMessage(), 500);
        }
    }

    public function getPayrolls()
    {
        $this->requireRole(['accounts', 'admin']);
        
        $filters = [
            'year' => $_GET['year'] ?? date('Y'),
            'month' => $_GET['month'] ?? null,
            'status' => $_GET['status'] ?? null
        ];
        
        $payrolls = $this->payrollModel->getAllPayrolls($filters);
        $statistics = $this->payrollModel->getPayrollStatistics($filters['year']);
        
        $this->successResponse([
            'payrolls' => $payrolls,
            'statistics' => $statistics,
            'filters' => $filters
        ]);
    }

    public function getPayrollDetails($payrollId)
    {
        $this->requireRole(['accounts', 'admin']);
        
        $payroll = $this->payrollModel->getPayrollWithItems($payrollId);
        
        if (!$payroll) {
            $this->errorResponse('Payroll not found', 404);
        }
        
        $this->successResponse($payroll);
    }

    public function submitPayrollForApproval()
    {
        $this->requireRole(['accounts', 'admin']);
        
        $data = $this->getRequestData();
        
        $errors = $this->validateRequired($data, ['payroll_id']);
        if (!empty($errors)) {
            $this->errorResponse('Validation failed', 422, $errors);
        }
        
        $payrollId = $data['payroll_id'];
        $payroll = $this->payrollModel->find($payrollId);
        
        if (!$payroll) {
            $this->errorResponse('Payroll not found', 404);
        }
        
        if ($payroll['status'] !== 'Draft') {
            $this->errorResponse('Only draft payrolls can be submitted for approval', 422);
        }
        
        $result = $this->payrollModel->submitForApproval($payrollId);
        
        if ($result) {
            $this->successResponse(null, 'Payroll submitted for approval successfully');
        } else {
            $this->errorResponse('Failed to submit payroll for approval', 500);
        }
    }

    public function addTransaction()
    {
        $this->requireRole(['accounts', 'admin']);
        
        $data = $this->getRequestData();
        
        $errors = $this->validateRequired($data, ['description', 'amount', 'type']);
        if (!empty($errors)) {
            $this->errorResponse('Validation failed', 422, $errors);
        }
        
        $amount = (float)$data['amount'];
        
        if ($amount <= 0) {
            $this->errorResponse('Amount must be greater than zero', 422);
        }
        
        // Validate type
        $validTypes = ['Expense', 'Salary', 'Advance', 'Loan'];
        if (!in_array($data['type'], $validTypes)) {
            $this->errorResponse('Invalid transaction type', 422);
        }
        
        // Validate employee if provided
        if (isset($data['employee_id'])) {
            $employee = $this->employeeModel->find($data['employee_id']);
            if (!$employee) {
                $this->errorResponse('Employee not found', 404);
            }
        }
        
        $data['created_by'] = $this->getCurrentUserId();
        $transaction = $this->transactionModel->addTransaction($data);
        
        if ($transaction) {
            $this->successResponse($transaction, 'Transaction added successfully');
        } else {
            $this->errorResponse('Failed to add transaction', 500);
        }
    }

    public function getTransactions()
    {
        $this->requireRole(['accounts', 'admin']);
        
        $filters = [
            'type' => $_GET['type'] ?? null,
            'category' => $_GET['category'] ?? null,
            'employee_id' => $_GET['employee_id'] ?? null,
            'date_from' => $_GET['date_from'] ?? null,
            'date_to' => $_GET['date_to'] ?? null,
            'month' => $_GET['month'] ?? null,
            'year' => $_GET['year'] ?? date('Y'),
            'search' => $_GET['search'] ?? null,
            'limit' => $_GET['limit'] ?? 50
        ];
        
        $transactions = $this->transactionModel->getTransactions($filters);
        $summary = $this->transactionModel->getTransactionSummary($filters);
        
        $this->successResponse([
            'transactions' => $transactions,
            'summary' => $summary,
            'filters' => $filters
        ]);
    }

    public function updateTransaction()
    {
        $this->requireRole(['accounts', 'admin']);
        
        $data = $this->getRequestData();
        
        $errors = $this->validateRequired($data, ['id']);
        if (!empty($errors)) {
            $this->errorResponse('Validation failed', 422, $errors);
        }
        
        $transactionId = $data['id'];
        $transaction = $this->transactionModel->find($transactionId);
        
        if (!$transaction) {
            $this->errorResponse('Transaction not found', 404);
        }
        
        unset($data['id']);
        
        if (isset($data['amount']) && $data['amount'] <= 0) {
            $this->errorResponse('Amount must be greater than zero', 422);
        }
        
        $result = $this->transactionModel->updateTransaction($transactionId, $data);
        
        if ($result) {
            $updatedTransaction = $this->transactionModel->find($transactionId);
            $this->successResponse($updatedTransaction, 'Transaction updated successfully');
        } else {
            $this->errorResponse('Failed to update transaction', 500);
        }
    }

    public function deleteTransaction()
    {
        $this->requireRole(['accounts', 'admin']);
        
        $data = $this->getRequestData();
        
        $errors = $this->validateRequired($data, ['id']);
        if (!empty($errors)) {
            $this->errorResponse('Validation failed', 422, $errors);
        }
        
        $transactionId = $data['id'];
        $transaction = $this->transactionModel->find($transactionId);
        
        if (!$transaction) {
            $this->errorResponse('Transaction not found', 404);
        }
        
        $result = $this->transactionModel->deleteTransaction($transactionId);
        
        if ($result) {
            $this->successResponse(null, 'Transaction deleted successfully');
        } else {
            $this->errorResponse('Failed to delete transaction', 500);
        }
    }

    public function getFinancialSummary()
    {
        $this->requireRole(['accounts', 'admin']);
        
        $year = $_GET['year'] ?? date('Y');
        
        $financialSummary = $this->transactionModel->getFinancialSummary($year);
        $monthlyStats = $this->transactionModel->getMonthlyTransactionStats($year);
        $categoryExpenses = $this->transactionModel->getCategoryWiseExpenses(['year' => $year]);
        $cashFlowData = $this->transactionModel->getCashFlowData($year);
        
        $this->successResponse([
            'financial_summary' => $financialSummary,
            'monthly_stats' => $monthlyStats,
            'category_expenses' => $categoryExpenses,
            'cash_flow_data' => $cashFlowData,
            'year' => (int)$year
        ]);
    }

    public function bulkUpdateSalary()
    {
        $this->requireRole(['accounts', 'admin']);
        
        $data = $this->getRequestData();
        
        $errors = $this->validateRequired($data, ['employee_ids', 'increase_percentage']);
        if (!empty($errors)) {
            $this->errorResponse('Validation failed', 422, $errors);
        }
        
        $employeeIds = $data['employee_ids'];
        $increasePercentage = (float)$data['increase_percentage'];
        
        if (!is_array($employeeIds) || empty($employeeIds)) {
            $this->errorResponse('Employee IDs must be a non-empty array', 422);
        }
        
        if ($increasePercentage < -50 || $increasePercentage > 100) {
            $this->errorResponse('Increase percentage must be between -50% and 100%', 422);
        }
        
        try {
            $updatedCount = $this->salaryStructureModel->bulkUpdateSalary($employeeIds, $increasePercentage);
            
            $this->successResponse([
                'updated_count' => $updatedCount,
                'total_employees' => count($employeeIds)
            ], "Successfully updated salary for {$updatedCount} employees");
            
        } catch (\Exception $e) {
            $this->errorResponse('Failed to update salaries: ' . $e->getMessage(), 500);
        }
    }
}
