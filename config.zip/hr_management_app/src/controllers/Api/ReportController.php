<?php

namespace App\Controllers\Api;

use App\Controllers\BaseController;
use App\Models\Report;

class ReportController extends BaseController
{
    private $reportModel;

    public function __construct()
    {
        $this->reportModel = new Report();
    }

    public function generateAttendanceReport()
    {
        $this->requireRole(['accounts', 'admin']);
        
        $filters = [
            'employee_id' => $_GET['employee_id'] ?? null,
            'department_id' => $_GET['department_id'] ?? null,
            'branch_id' => $_GET['branch_id'] ?? null,
            'date_from' => $_GET['date_from'] ?? null,
            'date_to' => $_GET['date_to'] ?? null,
            'month' => $_GET['month'] ?? null,
            'year' => $_GET['year'] ?? null,
            'status' => $_GET['status'] ?? null
        ];
        
        $format = $_GET['format'] ?? 'json';
        
        try {
            $reportData = $this->reportModel->generateAttendanceReport($filters);
            
            $this->handleReportOutput($reportData, $format, 'attendance_report', 'attendance');
            
        } catch (\Exception $e) {
            $this->errorResponse('Failed to generate attendance report: ' . $e->getMessage(), 500);
        }
    }

    public function generateLeaveReport()
    {
        $this->requireRole(['accounts', 'admin']);
        
        $filters = [
            'employee_id' => $_GET['employee_id'] ?? null,
            'department_id' => $_GET['department_id'] ?? null,
            'leave_type_id' => $_GET['leave_type_id'] ?? null,
            'status' => $_GET['status'] ?? null,
            'year' => $_GET['year'] ?? date('Y')
        ];
        
        $format = $_GET['format'] ?? 'json';
        
        try {
            $reportData = $this->reportModel->generateLeaveReport($filters);
            
            $this->handleReportOutput($reportData, $format, 'leave_report', 'leave');
            
        } catch (\Exception $e) {
            $this->errorResponse('Failed to generate leave report: ' . $e->getMessage(), 500);
        }
    }

    public function generatePayrollReport()
    {
        $this->requireRole(['accounts', 'admin']);
        
        $filters = [
            'year' => $_GET['year'] ?? date('Y'),
            'month' => $_GET['month'] ?? null,
            'status' => $_GET['status'] ?? null,
            'payroll_id' => $_GET['payroll_id'] ?? null
        ];
        
        $format = $_GET['format'] ?? 'json';
        
        try {
            $reportData = $this->reportModel->generatePayrollReport($filters);
            
            $this->handleReportOutput($reportData, $format, 'payroll_report', 'payroll');
            
        } catch (\Exception $e) {
            $this->errorResponse('Failed to generate payroll report: ' . $e->getMessage(), 500);
        }
    }

    public function generateFinancialReport()
    {
        $this->requireRole(['accounts', 'admin']);
        
        $filters = [
            'year' => $_GET['year'] ?? date('Y'),
            'month' => $_GET['month'] ?? null,
            'type' => $_GET['type'] ?? null,
            'category' => $_GET['category'] ?? null
        ];
        
        $format = $_GET['format'] ?? 'json';
        
        try {
            $reportData = $this->reportModel->generateFinancialReport($filters);
            
            $this->handleReportOutput($reportData, $format, 'financial_report', 'financial');
            
        } catch (\Exception $e) {
            $this->errorResponse('Failed to generate financial report: ' . $e->getMessage(), 500);
        }
    }

    public function generateEmployeeReport()
    {
        $this->requireRole(['accounts', 'admin']);
        
        $filters = [
            'department_id' => $_GET['department_id'] ?? null,
            'designation_id' => $_GET['designation_id'] ?? null,
            'branch_id' => $_GET['branch_id'] ?? null,
            'search' => $_GET['search'] ?? null
        ];
        
        $format = $_GET['format'] ?? 'json';
        
        try {
            $reportData = $this->reportModel->generateEmployeeReport($filters);
            
            $this->handleReportOutput($reportData, $format, 'employee_report', 'employee');
            
        } catch (\Exception $e) {
            $this->errorResponse('Failed to generate employee report: ' . $e->getMessage(), 500);
        }
    }

    public function generateComprehensiveReport()
    {
        $this->requireRole('admin');
        
        $year = $_GET['year'] ?? date('Y');
        $format = $_GET['format'] ?? 'json';
        
        try {
            $reportData = $this->reportModel->generateComprehensiveReport($year);
            
            $this->handleReportOutput($reportData, $format, 'comprehensive_report', 'comprehensive');
            
        } catch (\Exception $e) {
            $this->errorResponse('Failed to generate comprehensive report: ' . $e->getMessage(), 500);
        }
    }

    public function generatePayslip()
    {
        $this->requireAuth();
        
        $employeeId = $_GET['employee_id'] ?? null;
        $month = $_GET['month'] ?? null;
        $year = $_GET['year'] ?? null;
        $format = $_GET['format'] ?? 'pdf';
        
        if (!$month || !$year) {
            $this->errorResponse('Month and year are required', 422);
        }
        
        // Check permissions
        $userRole = $this->getCurrentUserRole();
        if ($userRole === 'employee') {
            // Employees can only generate their own payslips
            $userId = $this->getCurrentUserId();
            $employeeModel = new \App\Models\Employee();
            $employee = $employeeModel->getEmployeeByUserId($userId);
            if (!$employee) {
                $this->errorResponse('Employee profile not found', 404);
            }
            $employeeId = $employee['id'];
        } elseif (!in_array($userRole, ['accounts', 'admin'])) {
            $this->errorResponse('Insufficient permissions', 403);
        }
        
        if (!$employeeId) {
            $this->errorResponse('Employee ID is required', 422);
        }
        
        try {
            $payrollModel = new \App\Models\Payroll();
            $employeeModel = new \App\Models\Employee();
            
            // Get payslip data
            $sql = "
                SELECT p.*, pi.*, e.first_name, e.last_name, e.employee_id as emp_code,
                       d.name as department_name, des.name as designation_name,
                       b.name as branch_name
                FROM payrolls p
                JOIN payroll_items pi ON p.id = pi.payroll_id
                JOIN employees e ON pi.employee_id = e.id
                LEFT JOIN departments d ON e.department_id = d.id
                LEFT JOIN designations des ON e.designation_id = des.id
                LEFT JOIN branches b ON e.branch_id = b.id
                WHERE pi.employee_id = :employee_id AND p.month = :month AND p.year = :year
            ";
            
            $payslip = $this->db->fetch($sql, [
                'employee_id' => $employeeId,
                'month' => $month,
                'year' => $year
            ]);
            
            if (!$payslip) {
                $this->errorResponse('Payslip not found', 404);
            }
            
            // Decode salary details
            $payslip['salary_details'] = json_decode($payslip['salary_details'], true);
            
            // Generate payslip
            $payslipData = [
                'payslip' => $payslip,
                'company_name' => 'HR Management Company',
                'report_title' => "Payslip for {$payslip['first_name']} {$payslip['last_name']} - " . date('F Y', mktime(0, 0, 0, $month, 1, $year)),
                'generated_at' => date('Y-m-d H:i:s')
            ];
            
            if ($format === 'pdf') {
                $pdf = $this->generatePayslipPDF($payslipData);
                
                header('Content-Type: application/pdf');
                header('Content-Disposition: attachment; filename="payslip_' . $payslip['emp_code'] . '_' . $month . '_' . $year . '.pdf"');
                echo $pdf;
                exit();
            } else {
                $this->successResponse($payslipData);
            }
            
        } catch (\Exception $e) {
            $this->errorResponse('Failed to generate payslip: ' . $e->getMessage(), 500);
        }
    }

    private function handleReportOutput($reportData, $format, $filename, $template)
    {
        switch ($format) {
            case 'pdf':
                $pdf = $this->reportModel->exportToPDF($reportData, $template);
                
                header('Content-Type: application/pdf');
                header('Content-Disposition: attachment; filename="' . $filename . '_' . date('Y-m-d') . '.pdf"');
                echo $pdf;
                exit();
                
            case 'csv':
                $csvData = $this->prepareCsvData($reportData, $template);
                $csv = $this->reportModel->exportToCSV($csvData);
                
                header('Content-Type: text/csv');
                header('Content-Disposition: attachment; filename="' . $filename . '_' . date('Y-m-d') . '.csv"');
                echo $csv;
                exit();
                
            case 'excel':
                $csvData = $this->prepareCsvData($reportData, $template);
                $excel = $this->reportModel->exportToExcel($csvData);
                
                header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                header('Content-Disposition: attachment; filename="' . $filename . '_' . date('Y-m-d') . '.xlsx"');
                echo $excel;
                exit();
                
            default: // json
                $this->successResponse($reportData);
                break;
        }
    }

    private function prepareCsvData($reportData, $template)
    {
        switch ($template) {
            case 'attendance':
                return $reportData['detailed_data'] ?? [];
                
            case 'leave':
                return $reportData['detailed_data'] ?? [];
                
            case 'payroll':
                return $reportData['detailed_items'] ?? $reportData['payroll_data'] ?? [];
                
            case 'financial':
                return $reportData['recent_transactions'] ?? [];
                
            case 'employee':
                return $reportData['employees'] ?? [];
                
            default:
                return [];
        }
    }

    private function generatePayslipPDF($payslipData)
    {
        $payslip = $payslipData['payslip'];
        $salaryDetails = $payslip['salary_details'];
        
        $html = '<!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <title>Payslip</title>
            <style>
                body { font-family: Arial, sans-serif; margin: 20px; font-size: 12px; }
                .header { text-align: center; margin-bottom: 30px; border-bottom: 2px solid #333; padding-bottom: 20px; }
                .company-name { font-size: 20px; font-weight: bold; color: #333; }
                .payslip-title { font-size: 16px; color: #666; margin-top: 10px; }
                .employee-info { margin-bottom: 20px; }
                .info-table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
                .info-table td { padding: 8px; border: 1px solid #ddd; }
                .info-table .label { background-color: #f5f5f5; font-weight: bold; width: 30%; }
                .salary-table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
                .salary-table th, .salary-table td { border: 1px solid #333; padding: 10px; text-align: right; }
                .salary-table th { background-color: #f0f0f0; font-weight: bold; text-align: center; }
                .salary-table .description { text-align: left; }
                .total-row { background-color: #e6f3ff; font-weight: bold; }
                .net-salary { background-color: #d4edda; font-weight: bold; font-size: 14px; }
                .footer { text-align: center; margin-top: 30px; font-size: 10px; color: #666; }
            </style>
        </head>
        <body>';
        
        // Header
        $html .= '<div class="header">
            <div class="company-name">' . htmlspecialchars($payslipData['company_name']) . '</div>
            <div class="payslip-title">' . htmlspecialchars($payslipData['report_title']) . '</div>
        </div>';
        
        // Employee Information
        $html .= '<div class="employee-info">
            <table class="info-table">
                <tr>
                    <td class="label">Employee ID:</td>
                    <td>' . htmlspecialchars($payslip['emp_code']) . '</td>
                    <td class="label">Employee Name:</td>
                    <td>' . htmlspecialchars($payslip['first_name'] . ' ' . $payslip['last_name']) . '</td>
                </tr>
                <tr>
                    <td class="label">Department:</td>
                    <td>' . htmlspecialchars($payslip['department_name']) . '</td>
                    <td class="label">Designation:</td>
                    <td>' . htmlspecialchars($payslip['designation_name']) . '</td>
                </tr>
                <tr>
                    <td class="label">Pay Period:</td>
                    <td>' . date('F Y', mktime(0, 0, 0, $payslip['month'], 1, $payslip['year'])) . '</td>
                    <td class="label">Working Days:</td>
                    <td>' . $payslip['working_days'] . '</td>
                </tr>
                <tr>
                    <td class="label">Present Days:</td>
                    <td>' . $payslip['present_days'] . '</td>
                    <td class="label">Leave Days:</td>
                    <td>' . $payslip['leave_days'] . '</td>
                </tr>
            </table>
        </div>';
        
        // Salary Breakdown
        $html .= '<table class="salary-table">
            <thead>
                <tr>
                    <th class="description">Description</th>
                    <th>Amount</th>
                </tr>
            </thead>
            <tbody>';
        
        // Basic Salary
        $html .= '<tr>
            <td class="description">Basic Salary</td>
            <td>' . number_format($payslip['basic_salary'], 2) . '</td>
        </tr>';
        
        // Allowances
        if (isset($salaryDetails['components'])) {
            foreach ($salaryDetails['components'] as $component) {
                if ($component['type'] === 'allowance') {
                    $amount = $component['amount'];
                    if ($component['is_percentage'] && $component['percentage']) {
                        $amount = ($payslip['basic_salary'] * $component['percentage']) / 100;
                    }
                    $html .= '<tr>
                        <td class="description">' . htmlspecialchars($component['name']) . '</td>
                        <td>' . number_format($amount, 2) . '</td>
                    </tr>';
                }
            }
        }
        
        // Gross Salary
        $html .= '<tr class="total-row">
            <td class="description"><strong>Gross Salary</strong></td>
            <td><strong>' . number_format($payslip['gross_salary'], 2) . '</strong></td>
        </tr>';
        
        // Deductions
        if (isset($salaryDetails['components'])) {
            foreach ($salaryDetails['components'] as $component) {
                if ($component['type'] === 'deduction') {
                    $amount = $component['amount'];
                    if ($component['is_percentage'] && $component['percentage']) {
                        $amount = ($payslip['basic_salary'] * $component['percentage']) / 100;
                    }
                    $html .= '<tr>
                        <td class="description">' . htmlspecialchars($component['name']) . '</td>
                        <td>(' . number_format($amount, 2) . ')</td>
                    </tr>';
                }
            }
        }
        
        // Total Deductions
        $html .= '<tr class="total-row">
            <td class="description"><strong>Total Deductions</strong></td>
            <td><strong>(' . number_format($payslip['total_deductions'], 2) . ')</strong></td>
        </tr>';
        
        // Net Salary
        $html .= '<tr class="net-salary">
            <td class="description"><strong>Net Salary</strong></td>
            <td><strong>' . number_format($payslip['net_salary'], 2) . '</strong></td>
        </tr>';
        
        $html .= '</tbody></table>';
        
        // Footer
        $html .= '<div class="footer">
            <p>This is a computer-generated payslip and does not require a signature.</p>
            <p>Generated on: ' . $payslipData['generated_at'] . '</p>
        </div>';
        
        $html .= '</body></html>';
        
        return $this->reportModel->exportToPDF(['html' => $html], 'payslip');
    }
}
