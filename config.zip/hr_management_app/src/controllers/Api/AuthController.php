<?php

namespace App\Controllers\Api;

use App\Controllers\BaseController;
use App\Models\User;

class AuthController extends BaseController
{
    private $userModel;

    public function __construct()
    {
        $this->userModel = new User();
    }

    public function login()
    {
        $data = $this->getRequestData();
        
        $errors = $this->validateRequired($data, ['email', 'password']);
        
        if (!empty($errors)) {
            $this->errorResponse('Validation failed', 422, $errors);
        }
        
        $email = $this->sanitizeInput($data['email']);
        $password = $data['password'];
        
        if (!$this->validateEmail($email)) {
            $this->errorResponse('Please enter a valid email address', 422);
        }
        
        $user = $this->userModel->authenticate($email, $password);
        
        if ($user) {
            $this->createSession($user);
            
            $responseData = [
                'user' => $user,
                'session_id' => session_id()
            ];
            
            // Get employee details if user is an employee
            if ($user['role'] === 'employee') {
                $userWithEmployee = $this->userModel->getUserWithEmployee($user['id']);
                if ($userWithEmployee) {
                    $responseData['user'] = $userWithEmployee;
                }
            }
            
            $this->successResponse($responseData, 'Login successful');
        } else {
            $this->errorResponse('Invalid email or password', 401);
        }
    }

    public function logout()
    {
        $this->requireAuth();
        
        $this->destroySession();
        $this->successResponse(null, 'Logout successful');
    }

    public function me()
    {
        $this->requireAuth();
        
        $userId = $this->getCurrentUserId();
        $user = $this->userModel->getUserWithEmployee($userId);
        
        if ($user) {
            $this->successResponse($user);
        } else {
            $this->errorResponse('User not found', 404);
        }
    }

    public function changePassword()
    {
        $this->requireAuth();
        
        $data = $this->getRequestData();
        
        $errors = $this->validateRequired($data, ['current_password', 'new_password', 'confirm_password']);
        
        if (!empty($errors)) {
            $this->errorResponse('Validation failed', 422, $errors);
        }
        
        $userId = $this->getCurrentUserId();
        $currentPassword = $data['current_password'];
        $newPassword = $data['new_password'];
        $confirmPassword = $data['confirm_password'];
        
        if ($newPassword !== $confirmPassword) {
            $this->errorResponse('New password and confirm password do not match', 422);
        }
        
        if (strlen($newPassword) < 6) {
            $this->errorResponse('New password must be at least 6 characters long', 422);
        }
        
        // Verify current password
        $user = $this->userModel->find($userId);
        if (!$user || !password_verify($currentPassword, $user['password'])) {
            $this->errorResponse('Current password is incorrect', 422);
        }
        
        // Update password
        $result = $this->userModel->updatePassword($userId, $newPassword);
        
        if ($result) {
            $this->successResponse(null, 'Password changed successfully');
        } else {
            $this->errorResponse('Failed to change password', 500);
        }
    }

    private function createSession($user)
    {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_email'] = $user['email'];
        $_SESSION['user_role'] = $user['role'];
        $_SESSION['user'] = $user;
        
        // Get employee details if user is an employee
        if ($user['role'] === 'employee') {
            $userWithEmployee = $this->userModel->getUserWithEmployee($user['id']);
            if ($userWithEmployee) {
                $_SESSION['employee_id'] = $userWithEmployee['employee_id'];
                $_SESSION['employee_name'] = $userWithEmployee['first_name'] . ' ' . $userWithEmployee['last_name'];
                $_SESSION['user'] = $userWithEmployee;
            }
        }
        
        // Regenerate session ID for security
        session_regenerate_id(true);
    }

    private function destroySession()
    {
        session_unset();
        session_destroy();
        session_start();
    }
}
