<?php

namespace App\Controllers\Api;

use App\Controllers\BaseController;
use App\Models\Employee;
use App\Models\User;
use App\Models\Leave;
use App\Models\SalaryAdvance;
use App\Models\Loan;
use App\Models\Payroll;
use App\Models\Transaction;
use App\Models\Attendance;

class AdminController extends BaseController
{
    private $employeeModel;
    private $userModel;
    private $leaveModel;
    private $salaryAdvanceModel;
    private $loanModel;
    private $payrollModel;
    private $transactionModel;
    private $attendanceModel;

    public function __construct()
    {
        $this->employeeModel = new Employee();
        $this->userModel = new User();
        $this->leaveModel = new Leave();
        $this->salaryAdvanceModel = new SalaryAdvance();
        $this->loanModel = new Loan();
        $this->payrollModel = new Payroll();
        $this->transactionModel = new Transaction();
        $this->attendanceModel = new Attendance();
    }

    public function getDashboard()
    {
        $this->requireRole('admin');
        
        $currentMonth = date('n');
        $currentYear = date('Y');
        
        // Get key metrics
        $totalEmployees = $this->employeeModel->getEmployeeCount();
        $departmentStats = $this->employeeModel->getEmployeeCountByDepartment();
        $recentJoinings = $this->employeeModel->getRecentJoinings(5);
        
        // Get pending approvals count
        $pendingCounts = [
            'leaves' => count($this->leaveModel->getPendingLeaves()),
            'salary_advances' => count($this->salaryAdvanceModel->getPendingSalaryAdvances()),
            'loans' => count($this->loanModel->getPendingLoans()),
            'payrolls' => count($this->payrollModel->getAllPayrolls(['status' => 'Pending']))
        ];
        
        // Get financial summary
        $financialSummary = $this->transactionModel->getFinancialSummary($currentYear);
        $recentTransactions = $this->transactionModel->getRecentTransactions(5);
        
        // Get attendance summary for today
        $todayAttendance = $this->attendanceModel->getTodayAttendance();
        $attendanceStats = $this->attendanceModel->getMonthlyAttendanceStats($currentMonth, $currentYear);
        
        // Get monthly trends
        $monthlyTransactions = $this->transactionModel->getMonthlyTransactionStats($currentYear);
        $payrollStats = $this->payrollModel->getPayrollStatistics($currentYear);
        
        $this->successResponse([
            'total_employees' => $totalEmployees,
            'department_stats' => $departmentStats,
            'recent_joinings' => $recentJoinings,
            'pending_counts' => $pendingCounts,
            'financial_summary' => $financialSummary,
            'recent_transactions' => $recentTransactions,
            'today_attendance' => $todayAttendance,
            'attendance_stats' => $attendanceStats,
            'monthly_transactions' => $monthlyTransactions,
            'payroll_stats' => $payrollStats,
            'current_month' => $currentMonth,
            'current_year' => $currentYear
        ]);
    }

    public function getEmployees()
    {
        $this->requireRole('admin');
        
        $filters = [
            'department_id' => $_GET['department_id'] ?? null,
            'designation_id' => $_GET['designation_id'] ?? null,
            'branch_id' => $_GET['branch_id'] ?? null,
            'search' => $_GET['search'] ?? null
        ];
        
        $employees = $this->employeeModel->getAllEmployeesWithDetails($filters);
        $departmentStats = $this->employeeModel->getEmployeeCountByDepartment();
        
        $this->successResponse([
            'employees' => $employees,
            'department_stats' => $departmentStats,
            'filters' => $filters
        ]);
    }

    public function getEmployee($employeeId)
    {
        $this->requireRole('admin');
        
        $employee = $this->employeeModel->getEmployeeWithDetails($employeeId);
        
        if (!$employee) {
            $this->errorResponse('Employee not found', 404);
        }
        
        // Get employee's related data
        $currentYear = date('Y');
        $leaves = $this->leaveModel->getEmployeeLeaves($employeeId, $currentYear);
        $salaryAdvances = $this->salaryAdvanceModel->getEmployeeSalaryAdvances($employeeId, $currentYear);
        $loans = $this->loanModel->getEmployeeLoans($employeeId, $currentYear);
        $payrollHistory = $this->payrollModel->getEmployeePayrollHistory($employeeId, 6);
        $transactions = $this->transactionModel->getEmployeeTransactions($employeeId, ['year' => $currentYear]);
        
        // Get attendance summary for current month
        $currentMonth = date('n');
        $attendanceSummary = $this->attendanceModel->getAttendanceSummary($employeeId, $currentMonth, $currentYear);
        
        $this->successResponse([
            'employee' => $employee,
            'leaves' => $leaves,
            'salary_advances' => $salaryAdvances,
            'loans' => $loans,
            'payroll_history' => $payrollHistory,
            'transactions' => $transactions,
            'attendance_summary' => $attendanceSummary
        ]);
    }

    public function addEmployee()
    {
        $this->requireRole('admin');
        
        $data = $this->getRequestData();
        
        $errors = $this->validateRequired($data, [
            'email', 'password', 'first_name', 'last_name', 
            'department_id', 'designation_id', 'branch_id', 'date_of_joining'
        ]);
        
        if (!empty($errors)) {
            $this->errorResponse('Validation failed', 422, $errors);
        }
        
        if (!$this->validateEmail($data['email'])) {
            $this->errorResponse('Please enter a valid email address', 422);
        }
        
        if ($this->userModel->isEmailExists($data['email'])) {
            $this->errorResponse('Email address already exists', 422);
        }
        
        if (!$this->validateDate($data['date_of_joining'])) {
            $this->errorResponse('Invalid date of joining format', 422);
        }
        
        try {
            $this->db->beginTransaction();
            
            // Create user account
            $userData = [
                'email' => $data['email'],
                'password' => $data['password'],
                'role' => 'employee'
            ];
            
            $user = $this->userModel->createUser($userData);
            
            if (!$user) {
                throw new \Exception('Failed to create user account');
            }
            
            // Generate employee ID
            $employeeId = $this->employeeModel->generateEmployeeId();
            
            // Create employee record
            $employeeData = [
                'user_id' => $user['id'],
                'employee_id' => $employeeId,
                'first_name' => $data['first_name'],
                'last_name' => $data['last_name'],
                'department_id' => $data['department_id'],
                'designation_id' => $data['designation_id'],
                'branch_id' => $data['branch_id'],
                'date_of_birth' => $data['date_of_birth'] ?? null,
                'gender' => $data['gender'] ?? null,
                'phone_number' => $data['phone_number'] ?? null,
                'address' => $data['address'] ?? null,
                'date_of_joining' => $data['date_of_joining']
            ];
            
            $employee = $this->employeeModel->create($employeeData);
            
            if (!$employee) {
                throw new \Exception('Failed to create employee record');
            }
            
            $this->db->commit();
            
            $employeeDetails = $this->employeeModel->getEmployeeWithDetails($employee['id']);
            $this->successResponse($employeeDetails, 'Employee added successfully');
            
        } catch (\Exception $e) {
            $this->db->rollback();
            $this->errorResponse('Failed to add employee: ' . $e->getMessage(), 500);
        }
    }

    public function updateEmployee($employeeId)
    {
        $this->requireRole('admin');
        
        $employee = $this->employeeModel->find($employeeId);
        
        if (!$employee) {
            $this->errorResponse('Employee not found', 404);
        }
        
        $data = $this->getRequestData();
        
        $errors = $this->validateRequired($data, [
            'email', 'first_name', 'last_name', 
            'department_id', 'designation_id', 'branch_id', 'date_of_joining'
        ]);
        
        if (!empty($errors)) {
            $this->errorResponse('Validation failed', 422, $errors);
        }
        
        if (!$this->validateEmail($data['email'])) {
            $this->errorResponse('Please enter a valid email address', 422);
        }
        
        if ($this->userModel->isEmailExists($data['email'], $employee['user_id'])) {
            $this->errorResponse('Email address already exists', 422);
        }
        
        if (!$this->validateDate($data['date_of_joining'])) {
            $this->errorResponse('Invalid date of joining format', 422);
        }
        
        try {
            $this->db->beginTransaction();
            
            // Update user account
            $userData = ['email' => $data['email']];
            if (!empty($data['password'])) {
                $userData['password'] = password_hash($data['password'], PASSWORD_DEFAULT);
            }
            
            $this->userModel->update($employee['user_id'], $userData);
            
            // Update employee record
            $employeeData = [
                'first_name' => $data['first_name'],
                'last_name' => $data['last_name'],
                'department_id' => $data['department_id'],
                'designation_id' => $data['designation_id'],
                'branch_id' => $data['branch_id'],
                'date_of_birth' => $data['date_of_birth'] ?? null,
                'gender' => $data['gender'] ?? null,
                'phone_number' => $data['phone_number'] ?? null,
                'address' => $data['address'] ?? null,
                'date_of_joining' => $data['date_of_joining']
            ];
            
            $this->employeeModel->update($employeeId, $employeeData);
            
            $this->db->commit();
            
            $updatedEmployee = $this->employeeModel->getEmployeeWithDetails($employeeId);
            $this->successResponse($updatedEmployee, 'Employee updated successfully');
            
        } catch (\Exception $e) {
            $this->db->rollback();
            $this->errorResponse('Failed to update employee: ' . $e->getMessage(), 500);
        }
    }

    public function deleteEmployee($employeeId)
    {
        $this->requireRole('admin');
        
        $employee = $this->employeeModel->find($employeeId);
        
        if (!$employee) {
            $this->errorResponse('Employee not found', 404);
        }
        
        try {
            // Soft delete by setting is_active to false
            $result = $this->employeeModel->update($employeeId, ['is_active' => 0]);
            $this->userModel->update($employee['user_id'], ['is_active' => 0]);
            
            if ($result) {
                $this->successResponse(null, 'Employee deactivated successfully');
            } else {
                $this->errorResponse('Failed to deactivate employee', 500);
            }
        } catch (\Exception $e) {
            $this->errorResponse('Failed to deactivate employee: ' . $e->getMessage(), 500);
        }
    }

    public function approvePayroll()
    {
        $this->requireRole('admin');
        
        $data = $this->getRequestData();
        
        $errors = $this->validateRequired($data, ['payroll_id']);
        if (!empty($errors)) {
            $this->errorResponse('Validation failed', 422, $errors);
        }
        
        $payrollId = $data['payroll_id'];
        $action = $data['action'] ?? 'approve'; // approve or reject
        
        $payroll = $this->payrollModel->find($payrollId);
        
        if (!$payroll) {
            $this->errorResponse('Payroll not found', 404);
        }
        
        if ($payroll['status'] !== 'Pending') {
            $this->errorResponse('Only pending payrolls can be approved or rejected', 422);
        }
        
        $approvedBy = $this->getCurrentUserId();
        
        try {
            if ($action === 'approve') {
                $result = $this->payrollModel->approvePayroll($payrollId, $approvedBy);
                $message = 'Payroll approved successfully';
            } else {
                // For rejection, we could add a rejection reason
                $result = $this->payrollModel->update($payrollId, ['status' => 'Rejected']);
                $message = 'Payroll rejected';
            }
            
            if ($result) {
                $this->successResponse(null, $message);
            } else {
                $this->errorResponse('Failed to process payroll approval', 500);
            }
        } catch (\Exception $e) {
            $this->errorResponse('Failed to process payroll: ' . $e->getMessage(), 500);
        }
    }

    public function approveLeave()
    {
        $this->requireRole('admin');
        
        $data = $this->getRequestData();
        
        $errors = $this->validateRequired($data, ['leave_id', 'action']);
        if (!empty($errors)) {
            $this->errorResponse('Validation failed', 422, $errors);
        }
        
        $leaveId = $data['leave_id'];
        $action = $data['action']; // approve or reject
        $rejectionReason = $data['rejection_reason'] ?? null;
        
        $leave = $this->leaveModel->find($leaveId);
        
        if (!$leave) {
            $this->errorResponse('Leave application not found', 404);
        }
        
        if ($leave['status'] !== 'Pending') {
            $this->errorResponse('Only pending leave applications can be processed', 422);
        }
        
        $approvedBy = $this->getCurrentUserId();
        
        try {
            if ($action === 'approve') {
                $result = $this->leaveModel->approveLeave($leaveId, $approvedBy);
                $message = 'Leave application approved successfully';
            } else {
                $result = $this->leaveModel->approveLeave($leaveId, $approvedBy, $rejectionReason);
                $message = 'Leave application rejected';
            }
            
            if ($result) {
                $this->successResponse(null, $message);
            } else {
                $this->errorResponse('Failed to process leave application', 500);
            }
        } catch (\Exception $e) {
            $this->errorResponse('Failed to process leave: ' . $e->getMessage(), 500);
        }
    }

    public function approveSalaryAdvance()
    {
        $this->requireRole('admin');
        
        $data = $this->getRequestData();
        
        $errors = $this->validateRequired($data, ['advance_id', 'action']);
        if (!empty($errors)) {
            $this->errorResponse('Validation failed', 422, $errors);
        }
        
        $advanceId = $data['advance_id'];
        $action = $data['action']; // approve or reject
        $rejectionReason = $data['rejection_reason'] ?? null;
        
        $advance = $this->salaryAdvanceModel->find($advanceId);
        
        if (!$advance) {
            $this->errorResponse('Salary advance application not found', 404);
        }
        
        if ($advance['status'] !== 'Pending') {
            $this->errorResponse('Only pending salary advance applications can be processed', 422);
        }
        
        $approvedBy = $this->getCurrentUserId();
        
        try {
            if ($action === 'approve') {
                $result = $this->salaryAdvanceModel->approveSalaryAdvance($advanceId, $approvedBy);
                $message = 'Salary advance approved successfully';
            } else {
                $result = $this->salaryAdvanceModel->approveSalaryAdvance($advanceId, $approvedBy, $rejectionReason);
                $message = 'Salary advance rejected';
            }
            
            if ($result) {
                $this->successResponse(null, $message);
            } else {
                $this->errorResponse('Failed to process salary advance', 500);
            }
        } catch (\Exception $e) {
            $this->errorResponse('Failed to process salary advance: ' . $e->getMessage(), 500);
        }
    }

    public function approveLoan()
    {
        $this->requireRole('admin');
        
        $data = $this->getRequestData();
        
        $errors = $this->validateRequired($data, ['loan_id', 'action']);
        if (!empty($errors)) {
            $this->errorResponse('Validation failed', 422, $errors);
        }
        
        $loanId = $data['loan_id'];
        $action = $data['action']; // approve or reject
        $rejectionReason = $data['rejection_reason'] ?? null;
        
        $loan = $this->loanModel->find($loanId);
        
        if (!$loan) {
            $this->errorResponse('Loan application not found', 404);
        }
        
        if ($loan['status'] !== 'Pending') {
            $this->errorResponse('Only pending loan applications can be processed', 422);
        }
        
        $approvedBy = $this->getCurrentUserId();
        
        try {
            if ($action === 'approve') {
                $result = $this->loanModel->approveLoan($loanId, $approvedBy);
                $message = 'Loan approved successfully';
            } else {
                $result = $this->loanModel->approveLoan($loanId, $approvedBy, $rejectionReason);
                $message = 'Loan rejected';
            }
            
            if ($result) {
                $this->successResponse(null, $message);
            } else {
                $this->errorResponse('Failed to process loan application', 500);
            }
        } catch (\Exception $e) {
            $this->errorResponse('Failed to process loan: ' . $e->getMessage(), 500);
        }
    }

    public function getApprovals()
    {
        $this->requireRole('admin');
        
        $type = $_GET['type'] ?? 'all';
        
        $data = [];
        
        if ($type === 'all' || $type === 'leaves') {
            $data['pending_leaves'] = $this->leaveModel->getPendingLeaves();
        }
        
        if ($type === 'all' || $type === 'salary_advances') {
            $data['pending_salary_advances'] = $this->salaryAdvanceModel->getPendingSalaryAdvances();
        }
        
        if ($type === 'all' || $type === 'loans') {
            $data['pending_loans'] = $this->loanModel->getPendingLoans();
        }
        
        if ($type === 'all' || $type === 'payrolls') {
            $data['pending_payrolls'] = $this->payrollModel->getAllPayrolls(['status' => 'Pending']);
        }
        
        // Get approval statistics
        $data['statistics'] = [
            'leave_stats' => $this->leaveModel->getLeaveStatistics(),
            'advance_stats' => $this->salaryAdvanceModel->getSalaryAdvanceStatistics(),
            'loan_stats' => $this->loanModel->getLoanStatistics()
        ];
        
        $this->successResponse($data);
    }

    public function disbursePayroll()
    {
        $this->requireRole('admin');
        
        $data = $this->getRequestData();
        
        $errors = $this->validateRequired($data, ['payroll_id']);
        if (!empty($errors)) {
            $this->errorResponse('Validation failed', 422, $errors);
        }
        
        $payrollId = $data['payroll_id'];
        $payroll = $this->payrollModel->find($payrollId);
        
        if (!$payroll) {
            $this->errorResponse('Payroll not found', 404);
        }
        
        if ($payroll['status'] !== 'Approved') {
            $this->errorResponse('Only approved payrolls can be disbursed', 422);
        }
        
        try {
            $result = $this->payrollModel->disbursePayroll($payrollId);
            
            if ($result) {
                $this->successResponse(null, 'Payroll disbursed successfully');
            } else {
                $this->errorResponse('Failed to disburse payroll', 500);
            }
        } catch (\Exception $e) {
            $this->errorResponse('Failed to disburse payroll: ' . $e->getMessage(), 500);
        }
    }
}
