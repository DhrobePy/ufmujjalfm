<?php

namespace App\Controllers;

class DashboardController extends BaseController
{
    public function index()
    {
        $this->requireAuth();
        
        $userRole = $this->getCurrentUserRole();
        
        // Redirect to appropriate dashboard based on user role
        switch ($userRole) {
            case 'admin':
                $this->redirect('/admin/dashboard');
                break;
            case 'accounts':
                $this->redirect('/accounts/dashboard');
                break;
            case 'employee':
                $this->redirect('/employee/dashboard');
                break;
            default:
                $this->setFlashMessage('error', 'Invalid user role');
                $this->redirect('/login');
                break;
        }
    }
}
