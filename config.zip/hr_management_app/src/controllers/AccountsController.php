<?php

namespace App\Controllers;

use App\Models\SalaryStructure;
use App\Models\Payroll;
use App\Models\Transaction;
use App\Models\Attendance;
use App\Models\Employee;

class AccountsController extends BaseController
{
    private $salaryStructureModel;
    private $payrollModel;
    private $transactionModel;
    private $attendanceModel;
    private $employeeModel;

    public function __construct()
    {
        $this->salaryStructureModel = new SalaryStructure();
        $this->payrollModel = new Payroll();
        $this->transactionModel = new Transaction();
        $this->attendanceModel = new Attendance();
        $this->employeeModel = new Employee();
    }

    public function salaryStructures()
    {
        $this->requireRole(['accounts', 'admin']);
        
        $filters = [
            'department_id' => $_GET['department_id'] ?? null,
            'designation_id' => $_GET['designation_id'] ?? null,
            'branch_id' => $_GET['branch_id'] ?? null,
            'search' => $_GET['search'] ?? null
        ];
        
        $salaryStructures = $this->salaryStructureModel->getAllSalaryStructures($filters);
        $statistics = $this->salaryStructureModel->getSalaryStatistics();
        $departmentStats = $this->salaryStructureModel->getDepartmentWiseSalaryStats();
        
        // Get filter options
        $departments = $this->db->fetchAll("SELECT * FROM departments ORDER BY name");
        $designations = $this->db->fetchAll("SELECT * FROM designations ORDER BY name");
        $branches = $this->db->fetchAll("SELECT * FROM branches ORDER BY name");
        
        $this->renderView('accounts/salary-structures', [
            'salary_structures' => $salaryStructures,
            'statistics' => $statistics,
            'department_stats' => $departmentStats,
            'departments' => $departments,
            'designations' => $designations,
            'branches' => $branches,
            'filters' => $filters,
            'title' => 'Salary Structures'
        ]);
    }

    public function attendanceReports()
    {
        $this->requireRole(['accounts', 'admin']);
        
        $filters = [
            'employee_id' => $_GET['employee_id'] ?? null,
            'department_id' => $_GET['department_id'] ?? null,
            'branch_id' => $_GET['branch_id'] ?? null,
            'date_from' => $_GET['date_from'] ?? date('Y-m-01'),
            'date_to' => $_GET['date_to'] ?? date('Y-m-t'),
            'status' => $_GET['status'] ?? null
        ];
        
        $attendanceReport = $this->attendanceModel->getAttendanceReport($filters);
        
        // Get monthly stats if date range is within a month
        $monthlyStats = null;
        if ($filters['date_from'] && $filters['date_to']) {
            $startDate = new \DateTime($filters['date_from']);
            $endDate = new \DateTime($filters['date_to']);
            
            if ($startDate->format('Y-m') === $endDate->format('Y-m')) {
                $monthlyStats = $this->attendanceModel->getMonthlyAttendanceStats(
                    $startDate->format('n'),
                    $startDate->format('Y')
                );
            }
        }
        
        // Get filter options
        $employees = $this->employeeModel->getActiveEmployees();
        $departments = $this->db->fetchAll("SELECT * FROM departments ORDER BY name");
        $branches = $this->db->fetchAll("SELECT * FROM branches ORDER BY name");
        
        $this->renderView('accounts/attendance-reports', [
            'attendance_report' => $attendanceReport,
            'monthly_stats' => $monthlyStats,
            'employees' => $employees,
            'departments' => $departments,
            'branches' => $branches,
            'filters' => $filters,
            'title' => 'Attendance Reports'
        ]);
    }

    public function payroll()
    {
        $this->requireRole(['accounts', 'admin']);
        
        $filters = [
            'year' => $_GET['year'] ?? date('Y'),
            'month' => $_GET['month'] ?? null,
            'status' => $_GET['status'] ?? null
        ];
        
        $payrolls = $this->payrollModel->getAllPayrolls($filters);
        $statistics = $this->payrollModel->getPayrollStatistics($filters['year']);
        $monthlyStats = $this->payrollModel->getMonthlyPayrollStats($filters['year']);
        
        $this->renderView('accounts/payroll', [
            'payrolls' => $payrolls,
            'statistics' => $statistics,
            'monthly_stats' => $monthlyStats,
            'filters' => $filters,
            'title' => 'Payroll Management'
        ]);
    }

    public function transactions()
    {
        $this->requireRole(['accounts', 'admin']);
        
        $filters = [
            'type' => $_GET['type'] ?? null,
            'category' => $_GET['category'] ?? null,
            'employee_id' => $_GET['employee_id'] ?? null,
            'date_from' => $_GET['date_from'] ?? null,
            'date_to' => $_GET['date_to'] ?? null,
            'month' => $_GET['month'] ?? null,
            'year' => $_GET['year'] ?? date('Y'),
            'search' => $_GET['search'] ?? null,
            'limit' => $_GET['limit'] ?? 50
        ];
        
        $transactions = $this->transactionModel->getTransactions($filters);
        $summary = $this->transactionModel->getTransactionSummary($filters);
        $financialSummary = $this->transactionModel->getFinancialSummary($filters['year']);
        $categoryExpenses = $this->transactionModel->getCategoryWiseExpenses(['year' => $filters['year']]);
        
        // Get filter options
        $employees = $this->employeeModel->getActiveEmployees();
        $categories = $this->db->fetchAll("SELECT DISTINCT category FROM transactions WHERE category IS NOT NULL ORDER BY category");
        
        $this->renderView('accounts/transactions', [
            'transactions' => $transactions,
            'summary' => $summary,
            'financial_summary' => $financialSummary,
            'category_expenses' => $categoryExpenses,
            'employees' => $employees,
            'categories' => $categories,
            'filters' => $filters,
            'title' => 'Financial Transactions'
        ]);
    }

    public function dashboard()
    {
        $this->requireRole(['accounts', 'admin']);
        
        $currentMonth = date('n');
        $currentYear = date('Y');
        
        // Get key metrics
        $financialSummary = $this->transactionModel->getFinancialSummary($currentYear);
        $payrollStats = $this->payrollModel->getPayrollStatistics($currentYear);
        $salaryStats = $this->salaryStructureModel->getSalaryStatistics();
        $recentTransactions = $this->transactionModel->getRecentTransactions(10);
        
        // Get monthly trends
        $monthlyTransactions = $this->transactionModel->getMonthlyTransactionStats($currentYear);
        $cashFlowData = $this->transactionModel->getCashFlowData($currentYear);
        
        // Get pending items
        $pendingPayrolls = $this->payrollModel->getAllPayrolls(['status' => 'Pending']);
        
        $this->renderView('accounts/dashboard', [
            'financial_summary' => $financialSummary,
            'payroll_stats' => $payrollStats,
            'salary_stats' => $salaryStats,
            'recent_transactions' => $recentTransactions,
            'monthly_transactions' => $monthlyTransactions,
            'cash_flow_data' => $cashFlowData,
            'pending_payrolls' => $pendingPayrolls,
            'current_month' => $currentMonth,
            'current_year' => $currentYear,
            'title' => 'Accounts Dashboard'
        ]);
    }
}
