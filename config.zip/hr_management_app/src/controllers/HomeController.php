<?php

namespace App\Controllers;

class HomeController extends BaseController
{
    public function index()
    {
        // If user is already authenticated, redirect to dashboard
        if ($this->isAuthenticated()) {
            $this->redirect('/dashboard');
        }
        
        // Otherwise, redirect to login page
        $this->redirect('/login');
    }
}
