<?php

namespace App\Controllers;

use App\Models\Employee;
use App\Models\User;
use App\Models\Leave;
use App\Models\SalaryAdvance;
use App\Models\Loan;
use App\Models\Payroll;
use App\Models\Transaction;
use App\Models\Attendance;

class AdminController extends BaseController
{
    private $employeeModel;
    private $userModel;
    private $leaveModel;
    private $salaryAdvanceModel;
    private $loanModel;
    private $payrollModel;
    private $transactionModel;
    private $attendanceModel;

    public function __construct()
    {
        $this->employeeModel = new Employee();
        $this->userModel = new User();
        $this->leaveModel = new Leave();
        $this->salaryAdvanceModel = new SalaryAdvance();
        $this->loanModel = new Loan();
        $this->payrollModel = new Payroll();
        $this->transactionModel = new Transaction();
        $this->attendanceModel = new Attendance();
    }

    public function dashboard()
    {
        $this->requireRole('admin');
        
        $currentMonth = date('n');
        $currentYear = date('Y');
        
        // Get key metrics
        $totalEmployees = $this->employeeModel->getEmployeeCount();
        $departmentStats = $this->employeeModel->getEmployeeCountByDepartment();
        $recentJoinings = $this->employeeModel->getRecentJoinings(5);
        
        // Get pending approvals
        $pendingLeaves = $this->leaveModel->getPendingLeaves();
        $pendingSalaryAdvances = $this->salaryAdvanceModel->getPendingSalaryAdvances();
        $pendingLoans = $this->loanModel->getPendingLoans();
        $pendingPayrolls = $this->payrollModel->getAllPayrolls(['status' => 'Pending']);
        
        // Get financial summary
        $financialSummary = $this->transactionModel->getFinancialSummary($currentYear);
        $recentTransactions = $this->transactionModel->getRecentTransactions(10);
        
        // Get attendance summary for today
        $todayAttendance = $this->attendanceModel->getTodayAttendance();
        $attendanceStats = $this->attendanceModel->getMonthlyAttendanceStats($currentMonth, $currentYear);
        
        // Get monthly trends
        $monthlyTransactions = $this->transactionModel->getMonthlyTransactionStats($currentYear);
        $payrollStats = $this->payrollModel->getPayrollStatistics($currentYear);
        
        $this->renderView('admin/dashboard', [
            'total_employees' => $totalEmployees,
            'department_stats' => $departmentStats,
            'recent_joinings' => $recentJoinings,
            'pending_leaves' => $pendingLeaves,
            'pending_salary_advances' => $pendingSalaryAdvances,
            'pending_loans' => $pendingLoans,
            'pending_payrolls' => $pendingPayrolls,
            'financial_summary' => $financialSummary,
            'recent_transactions' => $recentTransactions,
            'today_attendance' => $todayAttendance,
            'attendance_stats' => $attendanceStats,
            'monthly_transactions' => $monthlyTransactions,
            'payroll_stats' => $payrollStats,
            'current_month' => $currentMonth,
            'current_year' => $currentYear,
            'title' => 'Admin Dashboard'
        ]);
    }

    public function employees()
    {
        $this->requireRole('admin');
        
        $filters = [
            'department_id' => $_GET['department_id'] ?? null,
            'designation_id' => $_GET['designation_id'] ?? null,
            'branch_id' => $_GET['branch_id'] ?? null,
            'search' => $_GET['search'] ?? null
        ];
        
        $employees = $this->employeeModel->getAllEmployeesWithDetails($filters);
        $departmentStats = $this->employeeModel->getEmployeeCountByDepartment();
        
        // Get filter options
        $departments = $this->db->fetchAll("SELECT * FROM departments ORDER BY name");
        $designations = $this->db->fetchAll("SELECT * FROM designations ORDER BY name");
        $branches = $this->db->fetchAll("SELECT * FROM branches ORDER BY name");
        
        $this->renderView('admin/employees', [
            'employees' => $employees,
            'department_stats' => $departmentStats,
            'departments' => $departments,
            'designations' => $designations,
            'branches' => $branches,
            'filters' => $filters,
            'title' => 'Employee Management'
        ]);
    }

    public function approvals()
    {
        $this->requireRole('admin');
        
        $type = $_GET['type'] ?? 'all';
        
        $pendingLeaves = [];
        $pendingSalaryAdvances = [];
        $pendingLoans = [];
        $pendingPayrolls = [];
        
        switch ($type) {
            case 'leaves':
                $pendingLeaves = $this->leaveModel->getPendingLeaves();
                break;
            case 'salary_advances':
                $pendingSalaryAdvances = $this->salaryAdvanceModel->getPendingSalaryAdvances();
                break;
            case 'loans':
                $pendingLoans = $this->loanModel->getPendingLoans();
                break;
            case 'payrolls':
                $pendingPayrolls = $this->payrollModel->getAllPayrolls(['status' => 'Pending']);
                break;
            default:
                $pendingLeaves = $this->leaveModel->getPendingLeaves();
                $pendingSalaryAdvances = $this->salaryAdvanceModel->getPendingSalaryAdvances();
                $pendingLoans = $this->loanModel->getPendingLoans();
                $pendingPayrolls = $this->payrollModel->getAllPayrolls(['status' => 'Pending']);
                break;
        }
        
        // Get approval statistics
        $leaveStats = $this->leaveModel->getLeaveStatistics();
        $advanceStats = $this->salaryAdvanceModel->getSalaryAdvanceStatistics();
        $loanStats = $this->loanModel->getLoanStatistics();
        
        $this->renderView('admin/approvals', [
            'pending_leaves' => $pendingLeaves,
            'pending_salary_advances' => $pendingSalaryAdvances,
            'pending_loans' => $pendingLoans,
            'pending_payrolls' => $pendingPayrolls,
            'leave_stats' => $leaveStats,
            'advance_stats' => $advanceStats,
            'loan_stats' => $loanStats,
            'type' => $type,
            'title' => 'Pending Approvals'
        ]);
    }

    public function reports()
    {
        $this->requireRole('admin');
        
        $reportType = $_GET['type'] ?? 'overview';
        $year = $_GET['year'] ?? date('Y');
        $month = $_GET['month'] ?? null;
        
        $data = [];
        
        switch ($reportType) {
            case 'attendance':
                $filters = [
                    'year' => $year,
                    'month' => $month
                ];
                $data['attendance_report'] = $this->attendanceModel->getAttendanceReport($filters);
                $data['monthly_stats'] = $this->attendanceModel->getMonthlyAttendanceStats($month ?: date('n'), $year);
                break;
                
            case 'leaves':
                $data['leave_report'] = $this->leaveModel->getLeaveReport(['year' => $year]);
                $data['leave_stats'] = $this->leaveModel->getLeaveStatistics($year);
                break;
                
            case 'payroll':
                $data['payroll_report'] = $this->payrollModel->getAllPayrolls(['year' => $year]);
                $data['payroll_stats'] = $this->payrollModel->getPayrollStatistics($year);
                $data['monthly_stats'] = $this->payrollModel->getMonthlyPayrollStats($year);
                break;
                
            case 'financial':
                $data['financial_summary'] = $this->transactionModel->getFinancialSummary($year);
                $data['monthly_transactions'] = $this->transactionModel->getMonthlyTransactionStats($year);
                $data['category_expenses'] = $this->transactionModel->getCategoryWiseExpenses(['year' => $year]);
                $data['cash_flow'] = $this->transactionModel->getCashFlowData($year);
                break;
                
            default: // overview
                $data['employee_count'] = $this->employeeModel->getEmployeeCount();
                $data['department_stats'] = $this->employeeModel->getEmployeeCountByDepartment();
                $data['financial_summary'] = $this->transactionModel->getFinancialSummary($year);
                $data['payroll_stats'] = $this->payrollModel->getPayrollStatistics($year);
                $data['leave_stats'] = $this->leaveModel->getLeaveStatistics($year);
                break;
        }
        
        $this->renderView('admin/reports', [
            'report_type' => $reportType,
            'year' => $year,
            'month' => $month,
            'data' => $data,
            'title' => 'Reports & Analytics'
        ]);
    }

    public function employeeProfile($employeeId)
    {
        $this->requireRole('admin');
        
        $employee = $this->employeeModel->getEmployeeWithDetails($employeeId);
        
        if (!$employee) {
            $this->setFlashMessage('error', 'Employee not found');
            $this->redirect('/admin/employees');
        }
        
        // Get employee's related data
        $currentYear = date('Y');
        $leaves = $this->leaveModel->getEmployeeLeaves($employeeId, $currentYear);
        $salaryAdvances = $this->salaryAdvanceModel->getEmployeeSalaryAdvances($employeeId, $currentYear);
        $loans = $this->loanModel->getEmployeeLoans($employeeId, $currentYear);
        $payrollHistory = $this->payrollModel->getEmployeePayrollHistory($employeeId, 6);
        $transactions = $this->transactionModel->getEmployeeTransactions($employeeId, ['year' => $currentYear]);
        
        // Get attendance summary for current month
        $currentMonth = date('n');
        $attendanceSummary = $this->attendanceModel->getAttendanceSummary($employeeId, $currentMonth, $currentYear);
        
        $this->renderView('admin/employee-profile', [
            'employee' => $employee,
            'leaves' => $leaves,
            'salary_advances' => $salaryAdvances,
            'loans' => $loans,
            'payroll_history' => $payrollHistory,
            'transactions' => $transactions,
            'attendance_summary' => $attendanceSummary,
            'current_year' => $currentYear,
            'current_month' => $currentMonth,
            'title' => 'Employee Profile - ' . $employee['first_name'] . ' ' . $employee['last_name']
        ]);
    }

    public function addEmployee()
    {
        $this->requireRole('admin');
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = $this->getRequestData();
            
            $errors = $this->validateRequired($data, [
                'email', 'password', 'first_name', 'last_name', 
                'department_id', 'designation_id', 'branch_id', 'date_of_joining'
            ]);
            
            if (!empty($errors)) {
                $this->setFlashMessage('error', 'Please fill in all required fields');
                $this->redirect('/admin/employees/add');
            }
            
            if (!$this->validateEmail($data['email'])) {
                $this->setFlashMessage('error', 'Please enter a valid email address');
                $this->redirect('/admin/employees/add');
            }
            
            if ($this->userModel->isEmailExists($data['email'])) {
                $this->setFlashMessage('error', 'Email address already exists');
                $this->redirect('/admin/employees/add');
            }
            
            try {
                $this->db->beginTransaction();
                
                // Create user account
                $userData = [
                    'email' => $data['email'],
                    'password' => $data['password'],
                    'role' => 'employee'
                ];
                
                $user = $this->userModel->createUser($userData);
                
                if (!$user) {
                    throw new \Exception('Failed to create user account');
                }
                
                // Generate employee ID
                $employeeId = $this->employeeModel->generateEmployeeId();
                
                // Create employee record
                $employeeData = [
                    'user_id' => $user['id'],
                    'employee_id' => $employeeId,
                    'first_name' => $data['first_name'],
                    'last_name' => $data['last_name'],
                    'department_id' => $data['department_id'],
                    'designation_id' => $data['designation_id'],
                    'branch_id' => $data['branch_id'],
                    'date_of_birth' => $data['date_of_birth'] ?? null,
                    'gender' => $data['gender'] ?? null,
                    'phone_number' => $data['phone_number'] ?? null,
                    'address' => $data['address'] ?? null,
                    'date_of_joining' => $data['date_of_joining']
                ];
                
                $employee = $this->employeeModel->create($employeeData);
                
                if (!$employee) {
                    throw new \Exception('Failed to create employee record');
                }
                
                $this->db->commit();
                
                $this->setFlashMessage('success', 'Employee added successfully');
                $this->redirect('/admin/employees');
                
            } catch (\Exception $e) {
                $this->db->rollback();
                $this->setFlashMessage('error', 'Failed to add employee: ' . $e->getMessage());
                $this->redirect('/admin/employees/add');
            }
        }
        
        // Get form options
        $departments = $this->db->fetchAll("SELECT * FROM departments ORDER BY name");
        $designations = $this->db->fetchAll("SELECT * FROM designations ORDER BY name");
        $branches = $this->db->fetchAll("SELECT * FROM branches ORDER BY name");
        
        $this->renderView('admin/add-employee', [
            'departments' => $departments,
            'designations' => $designations,
            'branches' => $branches,
            'title' => 'Add New Employee'
        ]);
    }

    public function editEmployee($employeeId)
    {
        $this->requireRole('admin');
        
        $employee = $this->employeeModel->getEmployeeWithDetails($employeeId);
        
        if (!$employee) {
            $this->setFlashMessage('error', 'Employee not found');
            $this->redirect('/admin/employees');
        }
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = $this->getRequestData();
            
            $errors = $this->validateRequired($data, [
                'email', 'first_name', 'last_name', 
                'department_id', 'designation_id', 'branch_id', 'date_of_joining'
            ]);
            
            if (!empty($errors)) {
                $this->setFlashMessage('error', 'Please fill in all required fields');
                $this->redirect("/admin/employees/edit/{$employeeId}");
            }
            
            if (!$this->validateEmail($data['email'])) {
                $this->setFlashMessage('error', 'Please enter a valid email address');
                $this->redirect("/admin/employees/edit/{$employeeId}");
            }
            
            if ($this->userModel->isEmailExists($data['email'], $employee['user_id'])) {
                $this->setFlashMessage('error', 'Email address already exists');
                $this->redirect("/admin/employees/edit/{$employeeId}");
            }
            
            try {
                $this->db->beginTransaction();
                
                // Update user account
                $userData = ['email' => $data['email']];
                if (!empty($data['password'])) {
                    $userData['password'] = password_hash($data['password'], PASSWORD_DEFAULT);
                }
                
                $this->userModel->update($employee['user_id'], $userData);
                
                // Update employee record
                $employeeData = [
                    'first_name' => $data['first_name'],
                    'last_name' => $data['last_name'],
                    'department_id' => $data['department_id'],
                    'designation_id' => $data['designation_id'],
                    'branch_id' => $data['branch_id'],
                    'date_of_birth' => $data['date_of_birth'] ?? null,
                    'gender' => $data['gender'] ?? null,
                    'phone_number' => $data['phone_number'] ?? null,
                    'address' => $data['address'] ?? null,
                    'date_of_joining' => $data['date_of_joining']
                ];
                
                $this->employeeModel->update($employeeId, $employeeData);
                
                $this->db->commit();
                
                $this->setFlashMessage('success', 'Employee updated successfully');
                $this->redirect('/admin/employees');
                
            } catch (\Exception $e) {
                $this->db->rollback();
                $this->setFlashMessage('error', 'Failed to update employee: ' . $e->getMessage());
                $this->redirect("/admin/employees/edit/{$employeeId}");
            }
        }
        
        // Get form options
        $departments = $this->db->fetchAll("SELECT * FROM departments ORDER BY name");
        $designations = $this->db->fetchAll("SELECT * FROM designations ORDER BY name");
        $branches = $this->db->fetchAll("SELECT * FROM branches ORDER BY name");
        
        $this->renderView('admin/edit-employee', [
            'employee' => $employee,
            'departments' => $departments,
            'designations' => $designations,
            'branches' => $branches,
            'title' => 'Edit Employee - ' . $employee['first_name'] . ' ' . $employee['last_name']
        ]);
    }
}
