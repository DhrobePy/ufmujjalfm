<?php

namespace App\Controllers;

use App\Models\Employee;
use App\Models\Attendance;
use App\Models\Leave;
use App\Models\SalaryAdvance;
use App\Models\Loan;

class EmployeeController extends BaseController
{
    private $employeeModel;
    private $attendanceModel;
    private $leaveModel;
    private $salaryAdvanceModel;
    private $loanModel;

    public function __construct()
    {
        $this->employeeModel = new Employee();
        $this->attendanceModel = new Attendance();
        $this->leaveModel = new Leave();
        $this->salaryAdvanceModel = new SalaryAdvance();
        $this->loanModel = new Loan();
    }

    public function profile()
    {
        $this->requireRole('employee');
        
        $userId = $this->getCurrentUserId();
        $employee = $this->employeeModel->getEmployeeByUserId($userId);
        
        if (!$employee) {
            $this->setFlashMessage('error', 'Employee profile not found');
            $this->redirect('/dashboard');
        }
        
        $employeeDetails = $this->employeeModel->getEmployeeWithDetails($employee['id']);
        
        $this->renderView('employee/profile', [
            'employee' => $employeeDetails,
            'title' => 'My Profile'
        ]);
    }

    public function attendance()
    {
        $this->requireRole('employee');
        
        $userId = $this->getCurrentUserId();
        $employee = $this->employeeModel->getEmployeeByUserId($userId);
        
        if (!$employee) {
            $this->setFlashMessage('error', 'Employee profile not found');
            $this->redirect('/dashboard');
        }
        
        $month = $_GET['month'] ?? date('n');
        $year = $_GET['year'] ?? date('Y');
        
        $attendance = $this->attendanceModel->getEmployeeAttendance($employee['id'], $month, $year);
        $summary = $this->attendanceModel->getAttendanceSummary($employee['id'], $month, $year);
        $workingDays = $this->attendanceModel->getWorkingDaysInMonth($month, $year);
        
        $this->renderView('employee/attendance', [
            'attendance' => $attendance,
            'summary' => $summary,
            'working_days' => $workingDays,
            'month' => $month,
            'year' => $year,
            'title' => 'My Attendance'
        ]);
    }

    public function leaves()
    {
        $this->requireRole('employee');
        
        $userId = $this->getCurrentUserId();
        $employee = $this->employeeModel->getEmployeeByUserId($userId);
        
        if (!$employee) {
            $this->setFlashMessage('error', 'Employee profile not found');
            $this->redirect('/dashboard');
        }
        
        $year = $_GET['year'] ?? date('Y');
        $leaves = $this->leaveModel->getEmployeeLeaves($employee['id'], $year);
        
        // Get leave types and balances
        $leaveTypes = $this->db->fetchAll("SELECT * FROM leave_types ORDER BY name");
        $leaveBalances = [];
        
        foreach ($leaveTypes as $leaveType) {
            $leaveBalances[$leaveType['id']] = $this->leaveModel->getLeaveBalance(
                $employee['id'], 
                $leaveType['id'], 
                $year
            );
        }
        
        $this->renderView('employee/leaves', [
            'leaves' => $leaves,
            'leave_types' => $leaveTypes,
            'leave_balances' => $leaveBalances,
            'year' => $year,
            'title' => 'My Leaves'
        ]);
    }

    public function salaryAdvance()
    {
        $this->requireRole('employee');
        
        $userId = $this->getCurrentUserId();
        $employee = $this->employeeModel->getEmployeeByUserId($userId);
        
        if (!$employee) {
            $this->setFlashMessage('error', 'Employee profile not found');
            $this->redirect('/dashboard');
        }
        
        $year = $_GET['year'] ?? date('Y');
        $advances = $this->salaryAdvanceModel->getEmployeeSalaryAdvances($employee['id'], $year);
        $statistics = $this->salaryAdvanceModel->getTotalAdvanceByEmployee($employee['id'], $year);
        
        $this->renderView('employee/salary-advance', [
            'advances' => $advances,
            'statistics' => $statistics,
            'year' => $year,
            'title' => 'Salary Advances'
        ]);
    }

    public function loans()
    {
        $this->requireRole('employee');
        
        $userId = $this->getCurrentUserId();
        $employee = $this->employeeModel->getEmployeeByUserId($userId);
        
        if (!$employee) {
            $this->setFlashMessage('error', 'Employee profile not found');
            $this->redirect('/dashboard');
        }
        
        $year = $_GET['year'] ?? date('Y');
        $loans = $this->loanModel->getEmployeeLoans($employee['id'], $year);
        $activeLoans = $this->loanModel->getActiveLoansForEmployee($employee['id']);
        
        // Get loan details with payments
        foreach ($loans as &$loan) {
            $loanDetails = $this->loanModel->getLoanWithPayments($loan['id']);
            $loan['total_paid'] = $loanDetails['total_paid'] ?? 0;
            $loan['remaining_amount'] = $loanDetails['remaining_amount'] ?? $loan['amount'];
        }
        
        $this->renderView('employee/loans', [
            'loans' => $loans,
            'active_loans' => $activeLoans,
            'year' => $year,
            'title' => 'My Loans'
        ]);
    }

    public function certificates()
    {
        $this->requireRole('employee');
        
        $userId = $this->getCurrentUserId();
        $employee = $this->employeeModel->getEmployeeByUserId($userId);
        
        if (!$employee) {
            $this->setFlashMessage('error', 'Employee profile not found');
            $this->redirect('/dashboard');
        }
        
        $employeeDetails = $this->employeeModel->getEmployeeWithDetails($employee['id']);
        
        $this->renderView('employee/certificates', [
            'employee' => $employeeDetails,
            'title' => 'Certificates'
        ]);
    }

    public function payslips()
    {
        $this->requireRole('employee');
        
        $userId = $this->getCurrentUserId();
        $employee = $this->employeeModel->getEmployeeByUserId($userId);
        
        if (!$employee) {
            $this->setFlashMessage('error', 'Employee profile not found');
            $this->redirect('/dashboard');
        }
        
        // Get payslips for the employee
        $sql = "
            SELECT p.month, p.year, p.status, pi.net_salary, pi.salary_details
            FROM payrolls p
            JOIN payroll_items pi ON p.id = pi.payroll_id
            WHERE pi.employee_id = :employee_id
            ORDER BY p.year DESC, p.month DESC
        ";
        
        $payslips = $this->db->fetchAll($sql, ['employee_id' => $employee['id']]);
        
        $this->renderView('employee/payslips', [
            'payslips' => $payslips,
            'employee' => $employee,
            'title' => 'My Payslips'
        ]);
    }
}
